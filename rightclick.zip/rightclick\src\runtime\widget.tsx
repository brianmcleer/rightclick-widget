﻿/* eslint-disable eslint-comments/no-unlimited-disable */
/* eslint-disable */
/** @jsx jsx */
import { React, ReactDOM, jsx, css, AllWidgetProps, ReactRedux, MutableStoreManager, getAppStore, appActions } from 'jimu-core';
import { JimuMapViewComponent, JimuMapView, loadArcGISJSAPIModules } from 'jimu-arcgis';
import { CalciteIcon } from 'calcite-components';
import { useTokens } from './theme';
import { Button } from 'jimu-ui';
import HelpPopup from './components/HelpPopup';
import { buildHelpSections, HelpFeatures } from './helpSections';
import defaultMessages from './translations/default';

// Hoisted Esri module imports (JS API 5.x ESM pattern). Modules used on every
// right-click or routinely throughout the widget are imported statically here
// so they're tree-shaken into the bundle and don't pay a lazy-load cost on
// each invocation. Heavy / rarely-used modules (DistanceMeasurement2D,
// AreaMeasurement2D, length/area math) are loaded lazily at their call sites
// via loadArcGISJSAPIModules so they don't bloat the initial widget bundle.
import Point from 'esri/geometry/Point';
import SpatialReference from 'esri/geometry/SpatialReference';
import * as projectOperator from 'esri/geometry/operators/projectOperator';
import * as geometryJsonUtils from 'esri/geometry/support/jsonUtils';
import * as locator from 'esri/rest/locator';
import * as reactiveUtils from 'esri/core/reactiveUtils';
import Graphic from 'esri/Graphic';
import TextSymbol from 'esri/symbols/TextSymbol';
import SimpleMarkerSymbol from 'esri/symbols/SimpleMarkerSymbol';

import { IMConfig, FeatureLayerConfig, CoordinateMarker, SimpleMarker, TextGraphic, PopupOverrideConfig, ArcadeExpressionInfo, WhatsHereHighlightConfig, computeLayerSelectionKey } from '../config';

// Ambient declarations for the `__esri` global namespace. Esri's TypeScript
// definitions normally expose this globally via @types/arcgis-js-api, but
// some Experience Builder build configurations don't have that on the
// type-resolution path. Declaring the few members we reference as `any`
// here is enough to satisfy the type checker without changing runtime
// behaviour. All values that come through these types are real Esri
// objects at runtime; we just lose IDE autocomplete inside this file.
declare global {
    // eslint-disable-next-line @typescript-eslint/no-namespace
    namespace __esri {
        // Declared as interfaces (not type aliases) so they MERGE with the
        // real @arcgis/core global __esri declarations when those are on
        // the type-resolution path (EB 1.21 / JS API 5.x), instead of
        // colliding as duplicate identifiers. On builds where the real
        // types are absent (some EB 1.20 configurations), these stand
        // alone and keep the annotations compiling. The index signature
        // makes every member access legal either way.
        /* eslint-disable @typescript-eslint/no-empty-interface */
        interface MapView { [key: string]: any }
        interface SceneView { [key: string]: any }
        interface Point { [key: string]: any }
        interface Geometry { [key: string]: any }
        interface Polyline { [key: string]: any }
        interface Polygon { [key: string]: any }
        interface Multipoint { [key: string]: any }
        interface Extent { [key: string]: any }
        interface Graphic { [key: string]: any }
        interface GraphicsLayer { [key: string]: any }
        interface WatchHandle { [key: string]: any }
        interface DistanceMeasurement2D { [key: string]: any }
        interface AreaMeasurement2D { [key: string]: any }
        interface Measurement { [key: string]: any }
        interface Popup { [key: string]: any }
        interface PopupTemplate { [key: string]: any }
        interface Symbol { [key: string]: any }
        interface SimpleMarkerSymbol { [key: string]: any }
        interface SimpleLineSymbol { [key: string]: any }
        interface SimpleFillSymbol { [key: string]: any }
        interface TextSymbol { [key: string]: any }
        interface FeatureLayer { [key: string]: any }
        interface MapImageLayer { [key: string]: any }
        interface GroupLayer { [key: string]: any }
        interface Sublayer { [key: string]: any }
        interface Layer { [key: string]: any }
        interface Field { [key: string]: any }
        /* eslint-enable @typescript-eslint/no-empty-interface */
    }
}

// Module-level cache for projectOperator.load(). The operator is a process
// singleton — once loaded, isLoaded() returns true forever. We still cache the
// in-flight promise so concurrent right-clicks don't trigger duplicate loads,
// and we null it on rejection so a transient CSP/WASM failure (common in local
// dev) doesn't permanently disable projection for the session.
let _projectOperatorReady: Promise<void> | null = null;
const ensureProjectOperator = (): Promise<void> => {
    if (projectOperator.isLoaded && projectOperator.isLoaded()) return Promise.resolve();
    if (!_projectOperatorReady) {
        _projectOperatorReady = projectOperator.load().catch((err: unknown) => {
            _projectOperatorReady = null; // allow retry on next call
            throw err;
        });
    }
    return _projectOperatorReady;
};

// Lazy-load the Arcade module. Arcade is only needed when a popup override
// with expressionInfos fires, so it doesn't belong in the initial widget
// bundle. Cached at module scope so concurrent calls share one load.
// Loaded through jimu-arcgis loadArcGISJSAPIModules, which works under both
// the AMD loader (EB 1.20 / JS API 4.x) and the ESM build (EB 1.21 /
// JS API 5.x) where window.require may not exist.
let _arcadeModulePromise: Promise<any> | null = null;
const loadArcadeModule = (): Promise<any> => {
    if (!_arcadeModulePromise) {
        _arcadeModulePromise = loadArcGISJSAPIModules(['esri/arcade'])
            .then((mods: any[]) => mods[0])
            .catch((err: any) => {
                _arcadeModulePromise = null; // allow retry next click
                throw err;
            });
    }
    return _arcadeModulePromise;
};

// Length / area math for the measurement label overlays. geometryEngine is
// deprecated in JS API 5.x in favor of the individual geometry operators
// and is slated for removal. Load geometryEngine when it exists (EB 1.20
// and current 1.21 builds) and fall back to the operator modules with a
// geometryEngine-shaped shim when it doesn't, so the widget keeps working
// the day Esri drops the module. Cached at module scope.
let _lengthAreaMathPromise: Promise<any> | null = null;
const loadLengthAreaMath = (): Promise<any> => {
    if (_lengthAreaMathPromise) return _lengthAreaMathPromise;
    _lengthAreaMathPromise = (async () => {
        try {
            const [ge] = await loadArcGISJSAPIModules(['esri/geometry/geometryEngine']);
            if (ge && typeof ge.geodesicLength === 'function') return ge;
        } catch (e) {
            // Module removed in this JS API build. Fall through to operators.
        }
        const [geodeticLengthOperator, lengthOperator, geodeticAreaOperator, areaOperator] =
            await loadArcGISJSAPIModules([
                'esri/geometry/operators/geodeticLengthOperator',
                'esri/geometry/operators/lengthOperator',
                'esri/geometry/operators/geodeticAreaOperator',
                'esri/geometry/operators/areaOperator'
            ]);
        // Some operators require an async load() before first execute().
        for (const op of [geodeticLengthOperator, lengthOperator, geodeticAreaOperator, areaOperator]) {
            try {
                if (op && typeof op.load === 'function' && typeof op.isLoaded === 'function' && !op.isLoaded()) {
                    await op.load();
                }
            } catch (e) { /* operator load is best-effort */ }
        }
        return {
            geodesicLength: (g: any, unit: any) => geodeticLengthOperator.execute(g, { unit }),
            planarLength: (g: any, unit: any) => lengthOperator.execute(g, { unit }),
            geodesicArea: (g: any, unit: any) => geodeticAreaOperator.execute(g, { unit }),
            planarArea: (g: any, unit: any) => areaOperator.execute(g, { unit })
        };
    })().catch((err) => {
        _lengthAreaMathPromise = null; // allow retry
        throw err;
    });
    return _lengthAreaMathPromise;
};

interface State {
    contextMenu: {
        visible: boolean;
        x: number;
        y: number;
        mapPoint?: __esri.Point;
        coordinateLabel?: string;
        projectedLatLon?: { lat: number; lon: number };
        // Reverse-geocoded address for the header. undefined = not requested,
        // null = loading, '' = lookup failed, string = address.
        addressText?: string | null;
        // Pre-computed alternate coordinate strings for the "More formats"
        // submenu. Computed at menu-open time so copying stays synchronous
        // (clipboard access requires an unbroken user-gesture chain).
        coordAlternates?: {
            dd?: string;
            dms?: string;
            native?: string;
            utm?: string;
            custom?: string;
            geojson?: string;
        };
        copyFormatsExpanded?: boolean;
    };
    showingContextMenu: boolean;
    isMeasuring: boolean;
    measurementWidget: __esri.DistanceMeasurement2D | null;
    isMeasuringArea: boolean;
    areaMeasurementWidget: __esri.Measurement | null;
    layerFieldMetadata: { [layerUrl: string]: { [fieldName: string]: { alias: string; type: string } } };
    // Coordinate plotting state
    coordinateMarkers: CoordinateMarker[];
    nextMarkerNumber: number;
    plotModeActive: boolean;
    // Simple marker state
    simpleMarkers: SimpleMarker[];
    // Text graphics state
    textGraphics: TextGraphic[];
    showTextDialog: boolean;
    pendingTextLocation: __esri.Point | null;
    // Mailing Labels buffer-choice dialog state.
    // mailingLabelsBufferEnabled drives a checkbox inside the dialog — when on,
    // the user provides a distance and unit; when off, no buffer is applied.
    showMailingLabelsBufferDialog: boolean;
    pendingMailingLabelsLocation: __esri.Point | null;
    mailingLabelsBufferEnabled: boolean;
    mailingLabelsBufferDistance: string;
    mailingLabelsBufferUnit: 'feet' | 'meters' | 'kilometers' | 'miles';
    mailingLabelsBufferError: string;
    // Accessibility state
    announceMessage: string;
    focusedMenuIndex: number;
}

// Enhanced unit and button cleanup function with MutationObserver for instant "New Measurement" suppression.
// Returns a disconnect function to stop the observer when the measurement widget is destroyed.
// CSS for the What's Here popup content (master rows, Back / Zoom-to
// buttons, links). This is injected in TWO places:
//   1. document.head, which reaches the popup in EB 1.20 and earlier,
//      where the popup renders in the light DOM of the page.
//   2. Inside the popup root element itself, required in EB 1.21 /
//      JS API 5.x, where popup content renders inside a shadow root
//      that document-level stylesheets cannot penetrate. A <style>
//      element carried inside the content applies wherever the
//      content lands, light DOM or shadow DOM.
const RC_WH_CONTENT_CSS = `
.rc-wh-row { display: flex; align-items: center; gap: 8px; padding: 8px 10px; margin-bottom: 4px; border-radius: 4px; box-sizing: border-box; }
.rc-wh-row--clickable { background: #f4f8fb; border: 1px solid #d9e6ef; cursor: pointer; transition: background 0.15s, border-color 0.15s; }
.rc-wh-row--clickable:hover, .rc-wh-row--clickable:focus { background: #e3eef6; border-color: #0079c1; outline: none; }
.rc-wh-row--clickable:focus-visible { box-shadow: 0 0 0 2px rgba(0, 121, 193, 0.35); }
.rc-wh-row--disabled { background: #fafafa; border: 1px solid #e0e0e0; color: #6e6e6e; }
.rc-wh-row__label { flex: 1; color: #0079c1; font-weight: 500; }
.rc-wh-row--disabled .rc-wh-row__label { color: #6e6e6e; font-weight: 400; }
.rc-wh-row__chevron { color: #0079c1; font-size: 16px; line-height: 1; font-weight: 600; }
.rc-wh-row__hint { font-size: 11px; color: #999; font-style: italic; }
.rc-wh-back { display: inline-flex; align-items: center; gap: 4px; padding: 5px 10px; background: #fff; border: 1px solid #0079c1; color: #0079c1; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 600; font-family: inherit; line-height: 1.2; transition: background 0.15s, color 0.15s; flex-shrink: 0; }
.rc-wh-back:hover, .rc-wh-back:focus { background: #0079c1; color: #fff; outline: none; }
.rc-wh-back:focus-visible { box-shadow: 0 0 0 2px rgba(0, 121, 193, 0.35); }
.rc-wh-zoom-to { display: inline-flex; align-items: center; gap: 4px; padding: 5px 10px; background: #fff; border: 1px solid #0079c1; color: #0079c1; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 600; font-family: inherit; line-height: 1.2; transition: background 0.15s, color 0.15s; flex-shrink: 0; }
.rc-wh-zoom-to:hover, .rc-wh-zoom-to:focus { background: #0079c1; color: #fff; outline: none; }
.rc-wh-zoom-to:focus-visible { box-shadow: 0 0 0 2px rgba(0, 121, 193, 0.35); }
.rc-wh-popup-root a { color: #0079c1; }
.rc-wh-popup-root a:hover, .rc-wh-popup-root a:focus { color: #005a92; }
.rc-wh-popup-root { box-sizing: border-box; }
`.trim();

// Apply the What's Here look as INLINE styles plus JS hover handlers.
// This is the belt-and-suspenders path for EB 1.21: it needs no
// stylesheet to reach the content at all, so it works even if the popup
// sanitizes or relocates our embedded <style>. Hover effects that CSS
// pseudo-classes would normally provide are wired as mouseenter/leave
// listeners. Idempotent per element via a dataset flag.
const applyRcWhInlineStyles = (root: HTMLElement) => {
    try {
        const mark = (el: HTMLElement): boolean => {
            if (el.dataset.rcStyled) return false;
            el.dataset.rcStyled = '1';
            return true;
        };

        root.querySelectorAll<HTMLElement>('.rc-wh-row').forEach((el) => {
            if (!mark(el)) return;
            el.style.cssText += ';display:flex;align-items:center;gap:8px;padding:8px 10px;margin-bottom:4px;border-radius:4px;box-sizing:border-box;';
            if (el.classList.contains('rc-wh-row--clickable')) {
                el.style.cssText += ';background:#f4f8fb;border:1px solid #d9e6ef;cursor:pointer;';
                el.addEventListener('mouseenter', () => { el.style.background = '#e3eef6'; el.style.borderColor = '#0079c1'; });
                el.addEventListener('mouseleave', () => { el.style.background = '#f4f8fb'; el.style.borderColor = '#d9e6ef'; });
            } else if (el.classList.contains('rc-wh-row--disabled')) {
                el.style.cssText += ';background:#fafafa;border:1px solid #e0e0e0;color:#6e6e6e;';
            }
        });

        root.querySelectorAll<HTMLElement>('.rc-wh-row__label').forEach((el) => {
            if (!mark(el)) return;
            const disabled = !!el.closest('.rc-wh-row--disabled');
            el.style.cssText += `;flex:1;color:${disabled ? '#6e6e6e' : '#0079c1'};font-weight:${disabled ? '400' : '500'};`;
        });
        root.querySelectorAll<HTMLElement>('.rc-wh-row__chevron').forEach((el) => {
            if (!mark(el)) return;
            el.style.cssText += ';color:#0079c1;font-size:16px;line-height:1;font-weight:600;';
        });
        root.querySelectorAll<HTMLElement>('.rc-wh-row__hint').forEach((el) => {
            if (!mark(el)) return;
            el.style.cssText += ';font-size:11px;color:#999;font-style:italic;';
        });

        root.querySelectorAll<HTMLElement>('.rc-wh-back, .rc-wh-zoom-to').forEach((el) => {
            if (!mark(el)) return;
            el.style.cssText += ';display:inline-flex;align-items:center;gap:4px;padding:5px 10px;background:#fff;border:1px solid #0079c1;color:#0079c1;border-radius:4px;cursor:pointer;font-size:12px;font-weight:600;font-family:inherit;line-height:1.2;flex-shrink:0;';
            el.addEventListener('mouseenter', () => { el.style.background = '#0079c1'; el.style.color = '#fff'; });
            el.addEventListener('mouseleave', () => { el.style.background = '#fff'; el.style.color = '#0079c1'; });
        });

        root.querySelectorAll<HTMLElement>('a').forEach((el) => {
            if (!mark(el)) return;
            el.style.color = '#0079c1';
        });
    } catch (e) { /* styling is best-effort */ }
};

// Walk to the parent element, crossing shadow DOM boundaries. In JS API
// 5.x (EB 1.21) the popup content is rendered inside a shadow root;
// parentElement returns null at the shadow boundary, so hop out to the
// shadow host and keep climbing.
const rcParentAcrossShadow = (el: HTMLElement | null): HTMLElement | null => {
    if (!el) return null;
    if (el.parentElement) return el.parentElement;
    try {
        const rn = el.getRootNode();
        if (rn && (rn as any).host && rn instanceof ShadowRoot) {
            return rn.host as HTMLElement;
        }
    } catch (e) { /* ignore */ }
    return null;
};

// Restore the 1.20-style stacked layout inside the Esri measurement panel
// WITHOUT depending on Esri class names, which changed in EB 1.21 /
// JS API 5.x and left the panel unstyled ("Distance328.91 ft" on one
// line). Elements are identified by their CONTENT: a leaf element whose
// text is exactly a known label gets label styling; the value next to it
// gets value styling. Every rule is guarded so it only fires when the
// element is visibly unstyled (inline display), making this a no-op on
// EB 1.20 where Esri's own stylesheet still applies.
const beautifyMeasurePanel = (rootEl: Element | null) => {
    if (!rootEl) return;
    try {
        const allEls = Array.from(rootEl.querySelectorAll<HTMLElement>('*'));

        // Pass 1: leaf label elements ("Distance", "Area", "Perimeter",
        // "Unit") and their sibling values.
        for (const el of allEls) {
            if (el.childElementCount !== 0) continue;
            const t = (el.textContent || '').trim();
            if (/^(Distance|Area|Perimeter)$/i.test(t)) {
                if (getComputedStyle(el).display === 'inline') {
                    el.style.cssText += ';display:block;font-size:12px;color:#6e6e6e;margin:8px 0 2px;';
                    const sib = el.nextElementSibling as HTMLElement | null;
                    if (sib && /\d/.test(sib.textContent || '') && getComputedStyle(sib).display === 'inline') {
                        sib.style.cssText += ';display:block;font-size:18px;font-weight:600;color:#151515;margin:0 0 8px;';
                    }
                }
            } else if (/^Unit$/i.test(t)) {
                if (getComputedStyle(el).display === 'inline') {
                    el.style.cssText += ';display:block;font-size:12px;color:#6e6e6e;margin:0 0 4px;';
                }
            }
        }

        // Pass 2: a parent holding exactly [label, value] as its two
        // children (the 4.x span-pair pattern) where both render inline.
        for (const el of allEls) {
            if (el.childElementCount !== 2) continue;
            const c0 = el.children[0] as HTMLElement;
            const c1 = el.children[1] as HTMLElement;
            const t0 = (c0.textContent || '').trim();
            const t1 = (c1.textContent || '').trim();
            if (/^(Distance|Area|Perimeter)$/i.test(t0) && /\d/.test(t1)) {
                if (getComputedStyle(c0).display === 'inline') {
                    c0.style.cssText += ';display:block;font-size:12px;color:#6e6e6e;margin:8px 0 2px;';
                }
                if (getComputedStyle(c1).display === 'inline') {
                    c1.style.cssText += ';display:block;font-size:18px;font-weight:600;color:#151515;margin:0 0 8px;';
                }
            }
        }

        // Unit dropdowns fill the panel width.
        rootEl.querySelectorAll<HTMLElement>('select, calcite-select').forEach((s) => {
            if (!s.dataset.rcWidthApplied) {
                s.dataset.rcWidthApplied = '1';
                s.style.cssText += ';width:100%;box-sizing:border-box;margin-bottom:6px;';
            }
        });

        // If the panel itself lost its padding (1.21 unstyled state), give
        // it breathing room. Skip when Esri's own padding is in effect.
        const panel = rootEl as HTMLElement;
        if (panel.style && !panel.dataset.rcPadApplied) {
            const cs = getComputedStyle(panel);
            if (parseFloat(cs.paddingLeft || '0') < 4) {
                panel.dataset.rcPadApplied = '1';
                panel.style.cssText += ';padding:12px 14px;';
            }
        }
    } catch (e) { /* styling is best-effort */ }
};

const hideUnwantedUnits = (widget: any, widgetType: 'distance' | 'area' = 'distance'): (() => void) => {
    const unwantedUnits = {
        distance: [
            'imperial', 'metric', 'inches', 'nautical miles', 'nautical-miles',
            'feet (us)', 'feet-us', 'us feet', 'us-feet'
        ],
        area: [
            'imperial', 'metric', 'square inches', 'square-inches',
            'square nautical miles', 'square-nautical-miles',
            'square feet (us)', 'square-feet-us', 'square us feet', 'square-us-feet',
            'ares'
        ]
    };

    const targetUnits = unwantedUnits[widgetType];
    let observer: MutationObserver | null = null;
    let styleEl: HTMLStyleElement | null = null;

    // Inject CSS to instantly hide known "New Measurement" / clear button classes before paint
    const injectHideCSS = () => {
        try {
            styleEl = document.createElement('style');
            styleEl.textContent = `
                .esri-distance-measurement-2d__clear-button,
                .esri-area-measurement-2d__clear-button,
                .esri-direct-line-measurement-3d__clear-button,
                .esri-measurement__clear-button {
                    display: none !important;
                    visibility: hidden !important;
                    height: 0 !important;
                    overflow: hidden !important;
                    pointer-events: none !important;
                }

                /* Layout restore for JS API 5.x (EB 1.21). The measurement
                   widget's Calcite rework can collapse the label and value
                   onto one line with no separation ("Distance378.15 ft")
                   and shrink the panel. Force the 1.20-style stacked
                   layout: label on its own line, value below it in a
                   larger bold face, with breathing room. These rules are
                   additive and match the widget's own 1.20 styling, so
                   they are harmless on older versions. */
                .esri-distance-measurement-2d__measurement-item-title,
                .esri-area-measurement-2d__measurement-item-title {
                    display: block !important;
                    margin-bottom: 4px;
                }
                .esri-distance-measurement-2d__measurement-item-value,
                .esri-area-measurement-2d__measurement-item-value {
                    display: block !important;
                    font-size: 16px;
                    font-weight: 600;
                }
                .esri-distance-measurement-2d__measurement-item,
                .esri-area-measurement-2d__measurement-item {
                    display: block !important;
                    margin: 8px 0;
                }
                .esri-distance-measurement-2d__measurement,
                .esri-area-measurement-2d__measurement {
                    display: block !important;
                    padding: 6px 0;
                }
                .esri-distance-measurement-2d,
                .esri-area-measurement-2d {
                    min-width: 220px;
                    box-sizing: border-box;
                }
            `;
            document.head.appendChild(styleEl);
        } catch (e) {
            // Silent fail
        }
    };

    // Remove "New Measurement" buttons and hint elements from a container
    const removeNewMeasurementButtons = (container: Element) => {
        try {
            const buttons = container.querySelectorAll('button, calcite-button');
            buttons.forEach((button: any) => {
                const text = (button.textContent || '').toLowerCase().trim();
                // Exact-match only, and never remove an element that also
                // contains a digit. In JS API 5.x (EB 1.21) the widget DOM
                // moved to Calcite components where a parent's textContent
                // includes all child text; a substring match could remove a
                // wrapper that holds the live measurement value.
                const isExactNewMeasurement = text === 'new measurement';
                const hasNumericContent = /\d/.test(text);
                if (isExactNewMeasurement && !hasNumericContent) {
                    button.style.display = 'none';
                    button.style.visibility = 'hidden';
                    button.hidden = true;
                    try { button.remove(); } catch (e) { /* silent */ }
                }
            });

            const hints = container.querySelectorAll(
                '.esri-distance-measurement-2d__hint, .esri-area-measurement-2d__hint, .esri-measurement__hint'
            );
            hints.forEach((hint: any) => {
                // Only remove a hint that carries no numeric content. If a
                // future JS API build repurposes or wraps the value in an
                // element matching these selectors, leave it alone.
                if (!/\d/.test(hint.textContent || '')) {
                    hint.style.display = 'none';
                    try { hint.remove(); } catch (e) { /* silent */ }
                }
            });
        } catch (e) {
            // Silent fail
        }
    };

    // Remove unwanted unit options from dropdowns
    const removeUnwantedOptions = (container: Element) => {
        try {
            const selectors = [
                'calcite-select calcite-option',
                'select option',
                '[role="option"]',
                'calcite-option'
            ];

            selectors.forEach(selector => {
                const options = container.querySelectorAll(selector);
                options.forEach((option: any) => {
                    const value = (option.value || '').toLowerCase().trim();
                    const text = (option.textContent || option.innerText || '').toLowerCase().trim();
                    const label = (option.label || '').toLowerCase().trim();

                    // Exact matches only. Substring matching (includes)
                    // is dangerous against Calcite DOM in JS API 5.x where
                    // wrapper elements can surface child text; an exact
                    // match can only hit a leaf option element.
                    const shouldRemove = targetUnits.some(unwantedUnit => {
                        const unwanted = unwantedUnit.toLowerCase();
                        return value === unwanted ||
                            text === unwanted ||
                            label === unwanted;
                    });

                    if (shouldRemove) {
                        option.style.display = 'none';
                        option.style.visibility = 'hidden';
                        option.hidden = true;
                        option.disabled = true;
                        try { option.remove(); } catch (e) { /* silent */ }
                    }
                });
            });
        } catch (e) {
            // Silent fail
        }
    };

    // Full cleanup pass on the container
    const fullCleanup = () => {
        try {
            const container = widget.container;
            if (!container) return;
            removeNewMeasurementButtons(container);
            removeUnwantedOptions(container);
            // Re-apply the label/value layout on every pass; the observer
            // and timed retries make this track Esri re-renders as the
            // measurement value updates.
            beautifyMeasurePanel(container);
        } catch (e) {
            // Silent fail
        }
    };

    // Inject CSS immediately
    injectHideCSS();

    // Run initial cleanup passes
    fullCleanup();
    setTimeout(fullCleanup, 10);
    setTimeout(fullCleanup, 50);
    setTimeout(fullCleanup, 100);

    // Timed cleanup for unit options that may render later
    let attempts = 0;
    const timedCleanup = () => {
        if (attempts++ > 15) return;
        fullCleanup();
        const delays = [50, 100, 150, 200, 300, 500, 750, 1000, 1500, 2000, 3000, 4000, 5000, 7000, 10000];
        if (attempts <= delays.length) {
            setTimeout(timedCleanup, delays[attempts - 1] || 1000);
        }
    };
    timedCleanup();

    // Set up MutationObserver to catch "New Measurement" button the instant it appears in DOM
    try {
        const container = widget.container;
        if (container) {
            observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        removeNewMeasurementButtons(container);
                        beautifyMeasurePanel(container);
                    }
                }
            });
            observer.observe(container, { childList: true, subtree: true });
        }
    } catch (e) {
        // Silent fail
    }

    // Return a disconnect function to clean up the observer and injected CSS
    return () => {
        try {
            if (observer) {
                observer.disconnect();
                observer = null;
            }
            if (styleEl && styleEl.parentNode) {
                styleEl.parentNode.removeChild(styleEl);
                styleEl = null;
            }
        } catch (e) {
            // Silent fail
        }
    };
};

/**
 * Suppress the ESRI measurement widget's built-in on-map text labels.
 * Each instance is scoped to only the layers added by its specific widget.
 */
const createLabelSuppressor = (mapView: any) => {
    let layerSnapshot: Set<any> = new Set();

    const isTextGraphic = (g: any): boolean => {
        if (!g?.symbol) return false;
        const t = g.symbol.type || '';
        if (t !== 'text' && t !== 'esriTS') return false;
        // Never suppress our own custom labels - only ESRI's built-in measurement labels
        const ownTypes = [
            'segment-label', 'total-label', 'area-label', 'perimeter-label',
            'coordinate-marker', 'coordinate-text', 'coordinate-label',
            'simple-marker', 'text-graphic', 'measurement-graphic'
        ];
        const attrType = g.attributes?.type;
        const isOwn = ownTypes.includes(attrType);
        if (isOwn) return false;
        return true;
    };

    const snapshotLayers = () => {
        try {
            layerSnapshot = new Set(mapView.map?.allLayers?.items || []);
        } catch (e) { /* silent */ }
    };

    const startSuppression = (): (() => void) => {
        let active = true;
        const restorations: Array<() => void> = [];
        const patchedCollections = new WeakSet<any>();

        const patchCollection = (graphics: any) => {
            if (!graphics || patchedCollections.has(graphics)) return;
            patchedCollections.add(graphics);

            const origAdd = graphics.add?.bind(graphics);
            if (origAdd) {
                graphics.add = (item: any, ...a: any[]) => {
                    if (active && isTextGraphic(item)) return;
                    return origAdd(item, ...a);
                };
                restorations.push(() => { graphics.add = origAdd; });
            }
            const origAddMany = graphics.addMany?.bind(graphics);
            if (origAddMany) {
                graphics.addMany = (items: any[], ...a: any[]) => {
                    if (!active) return origAddMany(items, ...a);
                    const f = (items || []).filter((g: any) => !isTextGraphic(g));
                    return f.length ? origAddMany(f, ...a) : undefined;
                };
                restorations.push(() => { graphics.addMany = origAddMany; });
            }
            const origPush = graphics.push?.bind(graphics);
            if (origPush) {
                graphics.push = (...items: any[]) => {
                    if (!active) return origPush(...items);
                    const f = items.filter((g: any) => !isTextGraphic(g));
                    return f.length ? origPush(...f) : graphics.length;
                };
                restorations.push(() => { graphics.push = origPush; });
            }
            const origSplice = graphics.splice?.bind(graphics);
            if (origSplice) {
                graphics.splice = (start: number, del: number, ...items: any[]) => {
                    if (!active) return origSplice(start, del, ...items);
                    const f = items.filter((g: any) => !isTextGraphic(g));
                    return origSplice(start, del, ...f);
                };
                restorations.push(() => { graphics.splice = origSplice; });
            }

            // Scrub any text graphics already present
            try {
                const existing = (graphics.items || []).filter(isTextGraphic);
                if (existing.length > 0) {
                    graphics.removeMany?.(existing) ||
                        existing.forEach((g: any) => graphics.remove?.(g));
                }
            } catch (e) { /* silent */ }
        };

        const patchNewLayers = () => {
            try {
                const all = mapView.map?.allLayers?.items || [];
                for (const layer of all) {
                    if (!layerSnapshot.has(layer) && layer.graphics) {
                        patchCollection(layer.graphics);
                    }
                }
            } catch (e) { /* silent */ }
        };

        let afterAddHandle: any = null;
        try {
            afterAddHandle = mapView.map?.allLayers?.on?.('after-add', (evt: any) => {
                if (active && evt.item && !layerSnapshot.has(evt.item) && evt.item.graphics) {
                    patchCollection(evt.item.graphics);
                }
            });
        } catch (e) { /* silent */ }

        patchNewLayers();
        const timers = [0, 50, 100, 200, 500, 1000, 2000].map(d =>
            setTimeout(patchNewLayers, d)
        );

        return () => {
            active = false;
            afterAddHandle?.remove?.();
            timers.forEach(t => clearTimeout(t));
            restorations.forEach(fn => { try { fn(); } catch (e) { /* silent */ } });
            restorations.length = 0;
        };
    };

    return { snapshotLayers, startSuppression };
};

const Widget = (props: AllWidgetProps<IMConfig>) => {
    // Get theme from Redux store (more reliable than props.theme)
    const storeTheme = ReactRedux.useSelector((state: any) => state?.appStateInBuilder?.theme || state?.appConfig?.theme);

    // Default font stack for Experience Builder
    const DEFAULT_FONT = 'Avenir Next, Avenir, Helvetica Neue, Helvetica, Arial, sans-serif';

    // Get theme font family from Experience Builder theme - try multiple paths
    const getThemeFont = React.useCallback((): string => {
        const theme = (props.theme || storeTheme) as any;

        if (theme) {
            // ExB 1.14+ / theme2 paths (check first for newer versions)
            if (theme.sys?.typography?.body?.fontFamily) return theme.sys.typography.body.fontFamily;
            if (theme.ref?.typeface?.brand) return theme.ref.typeface.brand;

            // ExB 1.x standard paths
            if (theme.typography?.fontFamilyBase) return theme.typography.fontFamilyBase;
            if (theme.body?.fontFamily) return theme.body.fontFamily;
            if (theme.fontFamilyBase) return theme.fontFamilyBase;

            // Shared theme paths
            if (theme.sharedTheme?.body?.fontFamily) return theme.sharedTheme.body.fontFamily;
            if (theme.surfaces?.[0]?.body?.fontFamily) return theme.surfaces[0].body.fontFamily;
            if (theme.header?.fontFamily) return theme.header.fontFamily;
        }

        return DEFAULT_FONT;
    }, [props.theme, storeTheme]);

    const themeFont = getThemeFont() || DEFAULT_FONT;

    // Theme tokens for the menu (colors, radii, shadows follow the Experience's theme).
    const tokens = useTokens();

    // Help guide (handoff Section 10). Strings come from translations/default.ts;
    // {token} placeholders are filled from `values`.
    const t = React.useCallback((id: string, values?: Record<string, string>): string => {
        let msg: string = (defaultMessages as any)[id] ?? id;
        if (values) {
            Object.keys(values).forEach((k) => { msg = msg.split(`{${k}}`).join(values[k]); });
        }
        return msg;
    }, []);
    const [helpOpen, setHelpOpen] = React.useState(false);

    const mapWidgetIds = props.config?.useMapWidgetIds || (props as any).useMapWidgetIds;

    const [state, setState] = React.useState<State>({
        contextMenu: { visible: false, x: 0, y: 0 },
        showingContextMenu: false,
        isMeasuring: false,
        measurementWidget: null,
        isMeasuringArea: false,
        areaMeasurementWidget: null,
        layerFieldMetadata: {},
        // Initialize coordinate plotting state
        coordinateMarkers: [],
        nextMarkerNumber: 1,
        plotModeActive: false,
        // Initialize simple marker state
        simpleMarkers: [],
        // Initialize text graphics state
        textGraphics: [],
        showTextDialog: false,
        pendingTextLocation: null,
        // Initialize mailing labels buffer-choice dialog state
        showMailingLabelsBufferDialog: false,
        pendingMailingLabelsLocation: null,
        mailingLabelsBufferEnabled: true,
        mailingLabelsBufferDistance: '100',
        mailingLabelsBufferUnit: 'feet',
        mailingLabelsBufferError: '',
        // Initialize accessibility state
        announceMessage: '',
        focusedMenuIndex: -1
    });

    const mapViewRef = React.useRef<__esri.MapView | null>(null);
    // Ordered history of user-placed graphics (coordinate markers, simple
    // markers, text) so "Undo last graphic" can remove the most recent one
    // regardless of type. Cleared by the clear-* actions.
    const graphicHistoryRef = React.useRef<Array<{ kind: 'coord' | 'marker' | 'text'; id: string }>>([]);
    // Identifies the current menu-open so late async results (address,
    // UTM projection) from a previous right-click are discarded.
    const menuOpenTokenRef = React.useRef<number>(0);
    const menuRef = React.useRef<HTMLDivElement | null>(null);
    const dialogRef = React.useRef<HTMLDivElement | null>(null);
    const textInputRef = React.useRef<HTMLInputElement | null>(null);
    const mailingLabelsDialogRef = React.useRef<HTMLDivElement | null>(null);
    const mailingLabelsApplyBufferBtnRef = React.useRef<HTMLInputElement | null>(null);
    const previousActiveElement = React.useRef<HTMLElement | null>(null);
    // Track event handlers to prevent duplicates
    const handlersAttachedRef = React.useRef<boolean>(false);
    const lastMapViewRef = React.useRef<__esri.MapView | null>(null);
    // Holds the current "What's Here" session so master/detail navigation
    // (the click handlers on the popup's clickable rows and the Back button)
    // can re-render without re-running the underlying queries.
    const whatsHereSessionRef = React.useRef<{
        mapPoint: __esri.Point;
        addressText: string;
        results: Array<{ layerName: string; features: any[]; layerUrl: string; popupEnabled: boolean; mapLayer?: any }>;
    } | null>(null);
    // Remembers the user-chosen popup size across master↔detail navigation
    // (and across subsequent right-clicks). Updated by a ResizeObserver on
    // every popup body; applied as an explicit width/height on the next
    // popup body that's built. Null means "use defaults".
    const whatsHerePopupSizeRef = React.useRef<{ width: number | null; height: number | null }>({
        width: null,
        height: null
    });
    // Live highlight graphic drawn over the feature whose detail view is
    // currently open. Set when renderFeature opens; cleared on renderMaster
    // (Back), on next renderFeature (so we don't stack highlights), and when
    // the popup closes entirely.
    const whatsHereHighlightRef = React.useRef<__esri.Graphic | null>(null);
    // WatchHandle for `popup.visible` that fires when the user dismisses the
    // popup (X button, click elsewhere, right-click again). Used to clear
    // the highlight graphic so it doesn't outlive the popup. Reassigned on
    // each new What's Here session.
    const whatsHerePopupCloseHandleRef = React.useRef<{ remove: () => void } | null>(null);
    // True while the master "What's Here" list is the active popup view,
    // false once the user has drilled into a feature detail. Used by the
    // hover-to-highlight handlers on master rows: a mouseleave that fires
    // *after* a click has transitioned us to detail must NOT wipe out the
    // detail-view highlight that renderFeature just set.
    const whatsHereMasterIsActiveRef = React.useRef<boolean>(false);

    // Announce message to screen readers
    const announce = React.useCallback((message: string) => {
        setState(prev => ({ ...prev, announceMessage: '' }));
        setTimeout(() => {
            setState(prev => ({ ...prev, announceMessage: message }));
        }, 50);
    }, []);

    // Prevent browser context menu
    React.useEffect(() => {
        const root = document.querySelector('.widget-right-click-map');
        const handler = (e: MouseEvent) => {
            if (e.target instanceof Node && root?.contains(e.target)) {
                e.preventDefault();
                e.stopImmediatePropagation();
            }
        };

        document.addEventListener('contextmenu', handler, { capture: true, passive: false });
        return () => {
            document.removeEventListener('contextmenu', handler, { capture: true });
        };
    }, []);

    const hideContextMenu = React.useCallback(() => {
        setState(prevState => ({
            ...prevState,
            showingContextMenu: false,
            contextMenu: { ...prevState.contextMenu, visible: false },
            focusedMenuIndex: -1
        }));
    }, []);

    // Document-level click handler to dismiss context menu
    React.useEffect(() => {
        const handleDocumentClick = (e: MouseEvent) => {
            // If context menu is visible and click is outside the menu, close it
            if (state.contextMenu.visible && menuRef.current) {
                if (!menuRef.current.contains(e.target as Node)) {
                    hideContextMenu();
                }
            }
        };

        // Use mousedown for faster response
        document.addEventListener('mousedown', handleDocumentClick);
        return () => {
            document.removeEventListener('mousedown', handleDocumentClick);
        };
    }, [state.contextMenu.visible, hideContextMenu]);

    // Reset handler tracking on unmount
    React.useEffect(() => {
        return () => {
            handlersAttachedRef.current = false;
            lastMapViewRef.current = null;
        };
    }, []);

    // Load field metadata for all configured layers
    React.useEffect(() => {
        const loadFieldMetadata = async () => {
            if (!props.config?.featureLayers?.length) return;

            const metadata: { [layerUrl: string]: { [fieldName: string]: { alias: string; type: string } } } = {};

            for (const layer of props.config.featureLayers) {
                if (!layer.url) continue;

                try {
                    const response = await fetch(`${layer.url}?f=json`);
                    const layerInfo = await response.json();

                    if (layerInfo.fields) {
                        metadata[layer.url] = {};
                        layerInfo.fields.forEach((field: any) => {
                            metadata[layer.url][field.name] = {
                                alias: field.alias || field.name,
                                type: field.type
                            };
                        });
                    }
                } catch (error) {
                }
            }

            setState(prev => ({ ...prev, layerFieldMetadata: metadata }));
        };

        loadFieldMetadata();
    }, [props.config?.featureLayers]);

    const copyWithPrompt = React.useCallback((coords: string) => {
        try {
            const textArea = document.createElement('textarea');
            textArea.value = coords;
            textArea.style.cssText = 'position:fixed;left:-999999px;top:-999999px;';
            document.body.appendChild(textArea);
            textArea.select();

            const successful = document.execCommand('copy');
            document.body.removeChild(textArea);

            if (!successful) {
                prompt('Please copy these coordinates manually:', coords);
            }
        } catch {
            prompt('Please copy these coordinates manually:', coords);
        }
    }, []);

    const projectToLatLon = React.useCallback(async (point: __esri.Point): Promise<__esri.Point> => {
        try {
            await ensureProjectOperator();
            const wgs84SR = new SpatialReference({ wkid: 4326 });
            const sourcePoint = new Point({
                x: point.x,
                y: point.y,
                spatialReference: point.spatialReference
            });
            const projected = projectOperator.execute(sourcePoint, wgs84SR) as __esri.Point;
            if (projected?.x !== undefined && projected?.y !== undefined &&
                Math.abs(projected.y) <= 90 && Math.abs(projected.x) <= 180) {
                return projected;
            }
        } catch {
            // Fall through to original point — manualProjectToLatLon will be used
            // by callers as the synchronous fallback.
        }
        return point;
    }, []);

    const projectToSpatialReference = React.useCallback(async (point: __esri.Point, wkid: number): Promise<__esri.Point> => {
        try {
            await ensureProjectOperator();
            const spatialRef = new SpatialReference({ wkid });
            const sourcePoint = new Point({
                x: point.x,
                y: point.y,
                spatialReference: point.spatialReference
            });
            const projected = projectOperator.execute(sourcePoint, spatialRef) as __esri.Point;
            return projected || point;
        } catch {
            return point;
        }
    }, []);

    const manualProjectToLatLon = React.useCallback((point: __esri.Point): { lat: number, lon: number } => {
        try {
            const wkid = point.spatialReference?.wkid;

            // Already geographic
            if (wkid === 4326 || wkid === 4269 || wkid === 4267) {
                return { lat: point.y, lon: point.x };
            }

            // Web Mercator — exact inverse Mercator formula
            if (wkid === 3857 || wkid === 102100 || wkid === 102113) {
                const lon = point.x / 20037508.342 * 180;
                const lat = (2 * Math.atan(Math.exp(point.y / 20037508.342 * Math.PI)) - Math.PI / 2) * 180 / Math.PI;
                return { lat, lon };
            }

            // UTM zones — full Transverse Mercator inverse (geodetically accurate)
            let zone: number | null = null;
            let isSouth = false;
            if (wkid >= 32601 && wkid <= 32660) { zone = wkid - 32600; isSouth = false; }
            else if (wkid >= 32701 && wkid <= 32760) { zone = wkid - 32700; isSouth = true; }
            else if (wkid >= 26901 && wkid <= 26923) { zone = wkid - 26900; isSouth = false; }

            if (zone !== null) {
                const a = 6378137.0;           // WGS84 semi-major axis
                const e2 = 0.00669437999014;    // WGS84 eccentricity squared
                const k0 = 0.9996;              // UTM scale factor
                const e1 = (1 - Math.sqrt(1 - e2)) / (1 + Math.sqrt(1 - e2));

                const x = point.x - 500000;
                const y = isSouth ? point.y - 10000000 : point.y;

                const M = y / k0;
                const mu = M / (a * (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256));

                const phi1 = mu
                    + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * Math.sin(2 * mu)
                    + (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * Math.sin(4 * mu)
                    + (151 * e1 * e1 * e1 / 96) * Math.sin(6 * mu)
                    + (1097 * e1 * e1 * e1 * e1 / 512) * Math.sin(8 * mu);

                const sinPhi1 = Math.sin(phi1);
                const cosPhi1 = Math.cos(phi1);
                const tanPhi1 = Math.tan(phi1);

                const N1 = a / Math.sqrt(1 - e2 * sinPhi1 * sinPhi1);
                const T1 = tanPhi1 * tanPhi1;
                const C1 = (e2 / (1 - e2)) * cosPhi1 * cosPhi1;
                const R1 = a * (1 - e2) / Math.pow(1 - e2 * sinPhi1 * sinPhi1, 1.5);
                const D = x / (N1 * k0);
                const D2 = D * D;

                const latRad = phi1
                    - (N1 * tanPhi1 / R1) * (
                        D2 / 2
                        - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * (e2 / (1 - e2))) * D2 * D2 / 24
                        + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * (e2 / (1 - e2)) - 3 * C1 * C1) * D2 * D2 * D2 / 720
                    );

                const lonRad = (
                    D
                    - (1 + 2 * T1 + C1) * D2 * D / 6
                    + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * (e2 / (1 - e2)) + 24 * T1 * T1) * D2 * D2 * D / 120
                ) / cosPhi1;

                const centralMeridian = (zone - 1) * 6 - 180 + 3;
                return {
                    lat: Math.max(-90, Math.min(90, latRad * 180 / Math.PI)),
                    lon: Math.max(-180, Math.min(180, centralMeridian + lonRad * 180 / Math.PI))
                };
            }

            // Unknown SR — return raw values
            return { lat: point.y, lon: point.x };
        } catch {
            return { lat: point.y, lon: point.x };
        }
    }, []);

    // Convert decimal degrees to degrees, minutes, seconds
    const convertToDMS = React.useCallback((decimal: number, type: 'lat' | 'lon'): string => {
        const isNegative = decimal < 0;
        const absolute = Math.abs(decimal);
        const degrees = Math.floor(absolute);
        const minutesFloat = (absolute - degrees) * 60;
        const minutes = Math.floor(minutesFloat);
        const seconds = (minutesFloat - minutes) * 60;

        let direction = '';
        if (type === 'lat') {
            direction = isNegative ? 'S' : 'N';
        } else {
            direction = isNegative ? 'W' : 'E';
        }

        return `${degrees}° ${minutes}' ${seconds.toFixed(2)}" ${direction}`;
    }, []);

    const copyCoordinates = React.useCallback(() => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        if (!mapViewRef.current || !mapPoint) return;

        // Must be fully synchronous — clipboard.writeText and execCommand both
        // require an unbroken user-gesture chain. Any await kills clipboard access.
        // projectedLatLon is pre-computed async on right-click (accurate Transverse
        // Mercator math), so it's ready by the time the user picks this menu item.
        try {
            const copySettings = props.config?.copySettings || {
                coordinateSystem: 'map',
                customWkid: undefined,
                coordinateFormat: 'decimal',
                decimalPlaces: 2
            };

            let coords: string;

            if (copySettings.coordinateSystem === 'webMercator') {
                const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);
                if (copySettings.coordinateFormat === 'dms') {
                    coords = `${convertToDMS(lat, 'lat')}, ${convertToDMS(lon, 'lon')}`;
                } else {
                    coords = `${lat.toFixed(copySettings.decimalPlaces || 6)}, ${lon.toFixed(copySettings.decimalPlaces || 6)}`;
                }
            } else if (copySettings.coordinateSystem === 'custom' && copySettings.customWkid) {
                // Custom SR: use raw map coords as fallback (accurate projection was async)
                coords = `${mapPoint.x.toFixed(copySettings.decimalPlaces || 2)}, ${mapPoint.y.toFixed(copySettings.decimalPlaces || 2)}`;
            } else {
                coords = `${mapPoint.x.toFixed(copySettings.decimalPlaces || 2)}, ${mapPoint.y.toFixed(copySettings.decimalPlaces || 2)}`;
            }

            // Synchronous clipboard write — preserves user gesture
            copyWithPrompt(coords);
            announce(`Coordinates copied: ${coords}`);
        } catch (error) {
            announce(`Error copying coordinates`);
        }
    }, [state.contextMenu, props.config?.copySettings, manualProjectToLatLon, convertToDMS, copyWithPrompt, announce]);

    // Show text input dialog
    const showTextInputDialog = React.useCallback(() => {
        const { mapPoint } = state.contextMenu;
        if (!mapPoint) return;

        // Save current focus for restoration when dialog closes
        previousActiveElement.current = document.activeElement as HTMLElement;

        setState(prev => ({
            ...prev,
            showTextDialog: true,
            pendingTextLocation: mapPoint
        }));
    }, [state.contextMenu]);

    // Add text to map
    const addTextToMap = React.useCallback((text: string) => {
        const mapView = mapViewRef.current;
        const location = state.pendingTextLocation;

        if (!mapView || !location || !text.trim()) {
            setState(prev => ({
                ...prev,
                showTextDialog: false,
                pendingTextLocation: null
            }));
            // Restore focus to previous element
            previousActiveElement.current?.focus();
            return;
        }

        try {
            const configTextSettings = props.config?.textSettings || {};
            const textSettings = {
                fontSize: configTextSettings.fontSize || 14,
                fontColor: configTextSettings.fontColor || '#000000',
                fontFamily: configTextSettings.fontFamily || themeFont,
                fontWeight: configTextSettings.fontWeight || 'bold',
                haloColor: configTextSettings.haloColor || '#ffffff',
                haloSize: configTextSettings.haloSize ?? 2,
                backgroundColor: configTextSettings.backgroundColor || 'transparent',
                backgroundOpacity: configTextSettings.backgroundOpacity ?? 0.8
            };

            // Always use themeFont if fontFamily is 'Arial' (the old default)
            const effectiveFontFamily = textSettings.fontFamily === 'Arial' ? themeFont : textSettings.fontFamily;

            try {
                // Create text symbol
                const textSymbol = new TextSymbol({
                    text: text.trim(),
                    color: textSettings.fontColor,
                    haloColor: textSettings.haloColor,
                    haloSize: textSettings.haloSize,
                    font: {
                        size: textSettings.fontSize,
                        weight: textSettings.fontWeight,
                        family: effectiveFontFamily
                    },
                    verticalAlignment: 'middle',
                    horizontalAlignment: 'center'
                });

                // Add background if specified
                if (textSettings.backgroundColor && textSettings.backgroundColor !== 'transparent') {
                    textSymbol.backgroundColor = textSettings.backgroundColor;
                    textSymbol.borderLineColor = textSettings.haloColor;
                    textSymbol.borderLineSize = 1;
                }

                const point = new Point({
                    x: location.x,
                    y: location.y,
                    spatialReference: location.spatialReference
                });

                // Create the text graphic
                const textGraphic = new Graphic({
                    geometry: point,
                    symbol: textSymbol,
                    attributes: {
                        type: 'text-graphic',
                        text: text.trim()
                    }
                });

                mapView.graphics.add(textGraphic);

                // Create text graphic object
                const newTextGraphic: TextGraphic = {
                    id: `text-graphic-${Date.now()}`,
                    point: location.clone(),
                    graphic: textGraphic,
                    text: text.trim()
                };

                // Update state
                setState(prev => ({
                    ...prev,
                    textGraphics: [...prev.textGraphics, newTextGraphic],
                    showTextDialog: false,
                    pendingTextLocation: null
                }));
                graphicHistoryRef.current.push({ kind: 'text', id: newTextGraphic.id });

                // Announce success and restore focus
                announce(`Text "${text.trim()}" added to map`);
                previousActiveElement.current?.focus();

            } catch (error) {
                alert('Error creating text graphic: ' + error.message);
                setState(prev => ({
                    ...prev,
                    showTextDialog: false,
                    pendingTextLocation: null
                }));
            }

        } catch (error) {
            alert(`Error adding text to map: ${error.message}`);
            setState(prev => ({
                ...prev,
                showTextDialog: false,
                pendingTextLocation: null
            }));
        }
    }, [state.pendingTextLocation, props.config?.textSettings, announce, themeFont]);

    // Cancel text input dialog
    const cancelTextInput = React.useCallback(() => {
        setState(prev => ({
            ...prev,
            showTextDialog: false,
            pendingTextLocation: null
        }));
        // Restore focus to previous element
        previousActiveElement.current?.focus();
        announce('Text input cancelled');
    }, [announce]);

    // Open the buffer-choice dialog for Mailing Labels. Mirrors showTextInputDialog:
    // captures the right-clicked point and shows a modal asking the user whether
    // they want a buffer applied — and if so, how big and in what unit. The
    // actual widget launch happens in launchMailingLabels after the user
    // confirms. We reset the error message but keep the user's last
    // distance/unit/enabled choice as defaults across right-clicks in this
    // session (light persistence, no config plumbing needed).
    const showMailingLabelsBufferDialog = React.useCallback(() => {
        const { mapPoint } = state.contextMenu;
        if (!mapPoint) return;

        // Save current focus for restoration when dialog closes
        previousActiveElement.current = document.activeElement as HTMLElement;

        setState(prev => ({
            ...prev,
            showMailingLabelsBufferDialog: true,
            pendingMailingLabelsLocation: mapPoint,
            mailingLabelsBufferError: ''
        }));
    }, [state.contextMenu]);

    // Cancel the mailing labels buffer-choice dialog without launching the widget.
    const cancelMailingLabelsBufferDialog = React.useCallback(() => {
        setState(prev => ({
            ...prev,
            showMailingLabelsBufferDialog: false,
            pendingMailingLabelsLocation: null,
            mailingLabelsBufferError: ''
        }));
        previousActiveElement.current?.focus();
        announce('Mailing Labels cancelled');
    }, [announce]);

    // Open the target widget, handling the parent-container's type correctly:
    //   • 'controller' — close any other open widgets in the controller, then
    //                    open the target (existing widget-controller flow).
    //   • 'accordion'  — open the target so Esri marks it active, then find
    //                    its accordion section header in the DOM and click
    //                    it so the section expands. The DOM-click approach is
    //                    used because Esri's AccordionLayoutViewer manages
    //                    section state internally and `expandedItems` in the
    //                    saved config is only the initial state, not a live
    //                    runtime API.
    //   • 'none'       — just open the target widget (top-level, no parent).
    //
    // Errors are swallowed silently inside try/catch so a misconfigured parent
    // never blocks the actual action from firing.
    // Open the target widget, handling the parent-container's type correctly:
    //   • 'controller'           — close any other open widgets in the
    //                              controller, then open the target (existing
    //                              widget-controller flow).
    //   • 'accordion'            — open the target so Esri marks it active,
    //                              then find its accordion section header in
    //                              the DOM and click it so the section
    //                              expands. The DOM-click approach is used
    //                              because Esri's AccordionLayoutViewer
    //                              manages section state internally and
    //                              `expandedItems` in the saved config is
    //                              only the initial state, not a live
    //                              runtime API.
    //   • 'controller+accordion' — accordion is itself inside a widget
    //                              controller. Open the controller panel
    //                              for the accordion widget first, then
    //                              expand the accordion section that owns
    //                              the target widget.
    //   • 'none'                 — just open the target widget (top-level,
    //                              no parent).
    //
    // Errors are swallowed silently inside try/catch so a misconfigured parent
    // never blocks the actual action from firing.
    const openContainerAndTarget = React.useCallback((
        targetWidgetId: string,
        containerType?: 'controller' | 'accordion' | 'controller+accordion' | 'none',
        accordionWidgetIdOverride?: string
    ) => {
        const type = containerType || 'controller';

        // Open a widget through the widget-controller panel flow: close any
        // currently-open widgets so the controller releases its existing
        // panel, then open the target. The asMutable / state-shape
        // inspection is defensive — `widgetsRuntimeInfo`'s shape varies
        // across ExB versions.
        const openInController = (widgetId: string, openDelay: number) => {
            try {
                const appState = getAppStore().getState();
                const runtimeInfo = appState?.widgetsRuntimeInfo;
                if (runtimeInfo) {
                    const ri = typeof runtimeInfo.asMutable === 'function'
                        ? runtimeInfo.asMutable({ deep: true })
                        : runtimeInfo;
                    const openIds = Object.keys(ri).filter(id => {
                        const info: any = ri[id];
                        return info?.state === 'OPENED' || info?.isOpened;
                    });
                    if (openIds.length > 0) {
                        getAppStore().dispatch(appActions.closeWidgets(openIds));
                    }
                }
            } catch { /* silent */ }

            try {
                getAppStore().dispatch((appActions as any).closeWidget(widgetId));
            } catch { /* silent */ }

            setTimeout(() => {
                try {
                    getAppStore().dispatch(appActions.openWidgets([widgetId]));
                } catch { /* silent */ }
            }, openDelay);
        };

        // Walk the accordion DOM and click the header whose section contains
        // (or whose label matches) the target widget. Returns true if a
        // header was found and clicked (or was already expanded).
        const expandAccordionSection = (accordionId: string): boolean => {
            try {
                let accordionRoot: Element | null = null;
                if (accordionId) {
                    const accordionSelectors = [
                        `[data-widgetid="${accordionId}"]`,
                        `[data-widget-id="${accordionId}"]`,
                        `[data-id="${accordionId}"]`,
                        `#${accordionId}`
                    ];
                    for (const s of accordionSelectors) {
                        try { accordionRoot = document.querySelector(s); } catch { /* ignore */ }
                        if (accordionRoot) break;
                    }
                }
                const searchRoot: Element | Document = accordionRoot || document;

                // Find the target widget's DOM. Esri may have unmounted it
                // (collapsed accordion sections detach their content), so
                // fall back to a document-wide search if needed.
                const targetSelectors = [
                    `[data-widgetid="${targetWidgetId}"]`,
                    `[data-widget-id="${targetWidgetId}"]`,
                    `[data-id="${targetWidgetId}"]`,
                    `#${targetWidgetId}`
                ];
                let widgetEl: Element | null = null;
                for (const s of targetSelectors) {
                    try { widgetEl = (searchRoot as any).querySelector(s); } catch { /* ignore */ }
                    if (widgetEl) break;
                }
                if (!widgetEl && accordionRoot) {
                    for (const s of targetSelectors) {
                        try { widgetEl = document.querySelector(s); } catch { /* ignore */ }
                        if (widgetEl) break;
                    }
                }

                // Enumerate candidate section headers via aria-expanded —
                // canonical ARIA attribute for a collapsible.
                const headerCandidates: HTMLElement[] = [];
                const queryRoot = accordionRoot || document;
                queryRoot.querySelectorAll('[aria-expanded]').forEach(el => {
                    headerCandidates.push(el as HTMLElement);
                });

                // Strategy A: target widget DOM exists — find the header
                // whose section contains it.
                if (widgetEl && headerCandidates.length > 0) {
                    for (const h of headerCandidates) {
                        let p: Element | null = h.parentElement;
                        while (p && p !== document.body) {
                            if (p.contains(widgetEl)) {
                                if (h.getAttribute('aria-expanded') === 'true') return true;
                                h.click();
                                return true;
                            }
                            p = p.parentElement;
                        }
                    }
                }

                // Strategy B: widget hasn't mounted yet (section is
                // collapsed). Match header by label text against the
                // widget's configured label.
                if (!widgetEl && accordionRoot && headerCandidates.length > 0) {
                    let targetLabel = '';
                    try {
                        const appState: any = getAppStore().getState();
                        const cfg = appState?.appStateInBuilder?.appConfig || appState?.appConfig;
                        targetLabel = String(cfg?.widgets?.[targetWidgetId]?.label || '');
                    } catch { /* ignore */ }
                    if (targetLabel) {
                        const norm = (s: string) => s.toLowerCase().trim();
                        const target = norm(targetLabel);
                        for (const h of headerCandidates) {
                            const txt = norm(h.textContent || '');
                            if (txt && (txt === target || txt.indexOf(target) >= 0 || target.indexOf(txt) >= 0)) {
                                if (h.getAttribute('aria-expanded') !== 'true') h.click();
                                return true;
                            }
                        }
                    }
                }

                return false;
            } catch {
                return false;
            }
        };

        // Retry-on-a-schedule wrapper for expandAccordionSection — Esri
        // can lazy-mount accordion sections only after they've been
        // requested, so we keep trying until the section actually exists.
        // baseDelay shifts the schedule when the accordion itself is
        // inside a controller that has to open first.
        const scheduleAccordionExpansion = (accordionId: string, baseDelay: number) => {
            setTimeout(() => {
                if (!expandAccordionSection(accordionId)) {
                    setTimeout(() => expandAccordionSection(accordionId), 400);
                }
            }, baseDelay + 150);
            setTimeout(() => expandAccordionSection(accordionId), baseDelay + 900);
            setTimeout(() => expandAccordionSection(accordionId), baseDelay + 1700);
        };

        // Resolve the accordion widget id from the override or from saved
        // settings (mirrors what the launcher passes — works for both the
        // property report and mailing labels code paths).
        const resolvedAccordionId =
            accordionWidgetIdOverride
            || (props.config?.propertyReportSettings?.targetWidgetId === targetWidgetId
                ? props.config?.propertyReportSettings?.accordionWidgetId
                : props.config?.mailingLabelsSettings?.accordionWidgetId)
            || '';

        if (type === 'controller') {
            openInController(targetWidgetId, 100);
            return;
        }

        if (type === 'accordion') {
            // No outer controller — just open the target so it's marked
            // active, then expand its accordion section.
            try {
                getAppStore().dispatch(appActions.openWidgets([targetWidgetId]));
            } catch { /* silent */ }

            // The accordion id for the plain-accordion case comes from
            // parentControllerId (kept for backwards compatibility — when
            // there's no outer controller, that field holds the accordion
            // widget id directly).
            const accordionIdForFlat =
                resolvedAccordionId
                || (props.config?.propertyReportSettings?.targetWidgetId === targetWidgetId
                    ? props.config?.propertyReportSettings?.parentControllerId
                    : props.config?.mailingLabelsSettings?.parentControllerId)
                || '';
            scheduleAccordionExpansion(accordionIdForFlat, 0);
            return;
        }

        if (type === 'controller+accordion') {
            // The accordion lives inside a widget controller. We need to:
            //   1. Open the controller's panel for the accordion widget (the
            //      controller treats the accordion as its content); this
            //      mounts the accordion's DOM.
            //   2. Mark the target widget as opened in Redux.
            //   3. Find the target's foldable-panel inside the accordion DOM
            //      and click its header so the accordion expands that
            //      section. Esri's accordion section is one <foldable-panel>
            //      element containing a "panel d-flex flex-column" wrapper,
            //      which in turn holds a "panel-header" and the body — we
            //      walk down to the header and click it.
            if (!resolvedAccordionId) {
                // Misconfigured — fall back to plain controller mode on the
                // target so something still opens.
                openInController(targetWidgetId, 100);
                return;
            }

            // Step 1: open the accordion widget through its controller.
            openInController(resolvedAccordionId, 100);

            // Step 2: dispatch openWidgets on the target so Redux marks it
            // as active — some Esri code paths rely on this for the
            // accordion's initial section selection.
            setTimeout(() => {
                try {
                    getAppStore().dispatch(appActions.openWidgets([targetWidgetId]));
                } catch { /* silent */ }
            }, 400);

            // Step 3: expand the section containing the target widget.
            const tryExpand = (): boolean => {
                try {
                    let accordionRoot: Element | null = null;
                    const accordionSelectors = [
                        `[data-widgetid="${resolvedAccordionId}"]`,
                        `[data-widget-id="${resolvedAccordionId}"]`,
                        `[data-id="${resolvedAccordionId}"]`,
                        `#${resolvedAccordionId}`
                    ];
                    for (const s of accordionSelectors) {
                        try { accordionRoot = document.querySelector(s); } catch { /* ignore */ }
                        if (accordionRoot) break;
                    }
                    if (!accordionRoot) return false;

                    let widgetEl: Element | null = null;
                    const targetSelectors = [
                        `[data-widgetid="${targetWidgetId}"]`,
                        `[data-widget-id="${targetWidgetId}"]`,
                        `[data-id="${targetWidgetId}"]`,
                        `#${targetWidgetId}`
                    ];
                    for (const s of targetSelectors) {
                        try { widgetEl = document.querySelector(s); } catch { /* ignore */ }
                        if (widgetEl) break;
                    }
                    if (!widgetEl) return false;

                    // Walk up from the widget to its containing foldable-panel.
                    let foldablePanel: Element | null = null;
                    let cur: Element | null = widgetEl;
                    let depth = 0;
                    while (cur && depth < 15) {
                        const cls = cur.getAttribute('class') || '';
                        if (cls.indexOf('foldable-panel') >= 0) {
                            foldablePanel = cur;
                            break;
                        }
                        cur = cur.parentElement;
                        depth++;
                    }
                    if (!foldablePanel) return false;

                    // Already expanded? we're done.
                    if ((foldablePanel.getAttribute('class') || '').indexOf('collapsed') < 0) {
                        return true;
                    }

                    // Recursively descend the panel looking for the FIRST
                    // descendant that does NOT contain the widget — that's
                    // the section header (typically a "panel-header" div
                    // with the section title and an expand button).
                    const findHeader = (node: Element, d: number): Element | null => {
                        if (d > 6) return null;
                        for (const c of Array.from(node.children)) {
                            if (!widgetEl || !c.contains(widgetEl)) {
                                if ((c.textContent || '').trim().length > 0) return c;
                            }
                        }
                        for (const c of Array.from(node.children)) {
                            if (widgetEl && c.contains(widgetEl)) {
                                const found = findHeader(c, d + 1);
                                if (found) return found;
                            }
                        }
                        return null;
                    };
                    const header = findHeader(foldablePanel, 0);

                    if (header) {
                        const btn = header.querySelector('button, [role="button"]') as HTMLElement | null;
                        if (btn) {
                            btn.click();
                            return true;
                        }
                        (header as HTMLElement).click();
                        return true;
                    }

                    // Last resort — click the panel itself.
                    (foldablePanel as HTMLElement).click();
                    return true;
                } catch {
                    return false;
                }
            };

            // Schedule retries: the accordion's DOM may not be mounted on
            // the first frame after the controller dispatches its open.
            setTimeout(tryExpand, 650);
            setTimeout(tryExpand, 1400);
            setTimeout(tryExpand, 2200);
            return;
        }

        // type === 'none' — just open the target. No parent container to
        // coordinate with.
        try {
            getAppStore().dispatch(appActions.openWidgets([targetWidgetId]));
        } catch { /* silent */ }
    }, [
        props.config?.propertyReportSettings?.targetWidgetId,
        props.config?.propertyReportSettings?.parentControllerId,
        props.config?.propertyReportSettings?.accordionWidgetId,
        props.config?.mailingLabelsSettings?.targetWidgetId,
        props.config?.mailingLabelsSettings?.parentControllerId,
        props.config?.mailingLabelsSettings?.accordionWidgetId
    ]);

    // Launch the Mailing Labels widget at the captured right-click location.
    // Follows the same controller-aware open/close pattern used by the Property
    // Report action: close any open widgets in the controller, open the target,
    // and push the action payload through MutableStoreManager.
    //
    // Buffer handling: the dialog has a checkbox + distance input + unit
    // dropdown. When the checkbox is on, we validate the typed distance and
    // include it in the payload as { applyBuffer: true, bufferDistance, bufferUnit }.
    // When off, we send { applyBuffer: false } and the receiving widget zeros
    // out its buffer for this selection.
    const launchMailingLabels = React.useCallback(() => {
        const pendingPoint = state.pendingMailingLabelsLocation;
        const targetWidgetId = props.config?.mailingLabelsSettings?.targetWidgetId;
        const applyBuffer = state.mailingLabelsBufferEnabled;
        const bufferUnit = state.mailingLabelsBufferUnit;

        // Resolve distance only if the user wants a buffer. Otherwise the value
        // is ignored on the receiving side, so we don't need to validate.
        let bufferDistance: number | null = null;
        if (applyBuffer) {
            const raw = state.mailingLabelsBufferDistance.trim();
            const parsed = Number(raw);
            if (raw === '' || !isFinite(parsed) || parsed <= 0) {
                // Inline validation — keep the dialog open and surface the error.
                setState(prev => ({
                    ...prev,
                    mailingLabelsBufferError: 'Please enter a buffer distance greater than 0.'
                }));
                return;
            }
            bufferDistance = parsed;
        }

        // All checks passed — close the dialog before opening the widget.
        setState(prev => ({
            ...prev,
            showMailingLabelsBufferDialog: false,
            pendingMailingLabelsLocation: null,
            mailingLabelsBufferError: ''
        }));
        previousActiveElement.current?.focus();

        if (!pendingPoint || !targetWidgetId) return;

        try {
            const pointData = {
                x: pendingPoint.x,
                y: pendingPoint.y,
                spatialReference: pendingPoint.spatialReference?.toJSON?.() || pendingPoint.spatialReference || { wkid: 4326 }
            };

            // Open the target (and expand the accordion section, or open in
            // the widget controller, depending on what the dev configured).
            const containerType = props.config?.mailingLabelsSettings?.parentContainerType;
            openContainerAndTarget(targetWidgetId, containerType);

            // Push the action payload through MutableStoreManager with the
            // same staggered retries the property-report path uses, so we
            // catch cases where the target widget is still mid-mount when
            // the first message goes out.
            const sendPoint = (delay: number) => {
                setTimeout(() => {
                    try {
                        MutableStoreManager.getInstance().updateStateValue(targetWidgetId, 'actionPoint', {
                            point: pointData,
                            address: null,
                            autoOpenSection: null,
                            applyBuffer,
                            bufferDistance,
                            bufferUnit,
                            timestamp: Date.now()
                        });
                        getAppStore().dispatch(
                            appActions.widgetStatePropChange(targetWidgetId, 'actionTriggered', true)
                        );
                    } catch { /* silent */ }
                }, delay);
            };

            // First send goes a bit after the open is dispatched (the helper
            // already waits ~100ms for controllers); subsequent sends are
            // belt-and-suspenders against slow mounts.
            sendPoint(350);
            sendPoint(1000);
            sendPoint(1800);
        } catch (err) {
            console.error('Right-Click: Error triggering Mailing Labels widget', err);
        }
    }, [
        state.pendingMailingLabelsLocation,
        state.mailingLabelsBufferEnabled,
        state.mailingLabelsBufferDistance,
        state.mailingLabelsBufferUnit,
        props.config?.mailingLabelsSettings?.targetWidgetId,
        props.config?.mailingLabelsSettings?.parentContainerType,
        openContainerAndTarget
    ]);

    // Clear all text graphics
    const clearTextGraphics = React.useCallback(() => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        // Remove all text graphics from map
        const textGraphics = mapView.graphics.filter((graphic: any) => {
            return graphic.attributes?.type === 'text-graphic';
        });

        const count = textGraphics.length;
        mapView.graphics.removeMany(textGraphics.toArray());

        // Reset state
        setState(prev => ({
            ...prev,
            textGraphics: []
        }));

        graphicHistoryRef.current = graphicHistoryRef.current.filter(h => h.kind !== 'text');
        announce(`${count} text graphics cleared`);
    }, [announce]);

    // Plot coordinate marker function
    const plotCoordinate = React.useCallback(() => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        const mapView = mapViewRef.current;
        if (!mapView || !mapPoint) return;

        try {
            const plotSettings = props.config?.plotSettings || {
                markerSize: 12,
                markerColor: '#ff6b6b',
                markerStyle: 'circle',
                markerOutlineColor: '#ffffff',
                markerOutlineWidth: 1,
                markerOpacity: 1,
                markerAngle: 0,
                markerXOffset: 0,
                markerYOffset: 0,
                textColor: '#ffffff',
                textSize: 10,
                showCoordinateText: true,
                showCoordinateLabels: true,
                coordinateSystem: 'map',
                customWkid: undefined,
                coordinateFormat: 'decimal',
                decimalPlaces: 6,
                labelOffset: 20,
                labelTextSize: 10,
                labelTextColor: '#000000'
            };

            let coordinateText: string;
            let coordinateLabel: string;

            // Use pre-computed projectedLatLon from state (set async on right-click)
            // for webMercator mode. Falls back to accurate Transverse Mercator math.
            if (plotSettings.coordinateSystem === 'webMercator') {
                const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);
                if (plotSettings.coordinateFormat === 'dms') {
                    coordinateText = `${convertToDMS(lat, 'lat')}\n${convertToDMS(lon, 'lon')}`;
                    coordinateLabel = coordinateText;
                } else {
                    const latDir = lat >= 0 ? 'N' : 'S';
                    const lonDir = lon >= 0 ? 'E' : 'W';
                    coordinateText = `Lat: ${Math.abs(lat).toFixed(plotSettings.decimalPlaces || 6)}° ${latDir}\nLon: ${Math.abs(lon).toFixed(plotSettings.decimalPlaces || 6)}° ${lonDir}`;
                    coordinateLabel = `${Math.abs(lat).toFixed(plotSettings.decimalPlaces || 6)}° ${latDir}\n${Math.abs(lon).toFixed(plotSettings.decimalPlaces || 6)}° ${lonDir}`;
                }
            } else if (plotSettings.coordinateSystem === 'custom' && plotSettings.customWkid) {
                coordinateText = `X: ${mapPoint.x.toFixed(plotSettings.decimalPlaces || 2)}\nY: ${mapPoint.y.toFixed(plotSettings.decimalPlaces || 2)}\nWKID: ${plotSettings.customWkid}`;
                coordinateLabel = `${mapPoint.x.toFixed(plotSettings.decimalPlaces || 2)}, ${mapPoint.y.toFixed(plotSettings.decimalPlaces || 2)}`;
            } else {
                // Use map's native coordinate system
                coordinateText = `X: ${mapPoint.x.toFixed(plotSettings.decimalPlaces || 2)}\nY: ${mapPoint.y.toFixed(plotSettings.decimalPlaces || 2)}\nWKID: ${mapPoint.spatialReference?.wkid || 'Unknown'}`;
                coordinateLabel = `${mapPoint.x.toFixed(plotSettings.decimalPlaces || 2)}, ${mapPoint.y.toFixed(plotSettings.decimalPlaces || 2)}`;
            }

            try {
                const markerNumber = state.nextMarkerNumber;

                // NEW: Create enhanced marker symbol with all style options
                const markerSymbol = new SimpleMarkerSymbol({
                    color: plotSettings.markerColor,
                    outline: {
                        color: plotSettings.markerOutlineColor || '#ffffff',
                        width: plotSettings.markerOutlineWidth || 1
                    },
                    size: plotSettings.markerSize,
                    style: (plotSettings.markerStyle || 'circle') as any,
                    // Add rotation, offsets, and opacity
                    angle: plotSettings.markerAngle || 0,
                    xoffset: plotSettings.markerXOffset || 0,
                    yoffset: plotSettings.markerYOffset || 0
                });

                // Apply opacity if supported
                if (plotSettings.markerOpacity !== undefined && plotSettings.markerOpacity !== 1) {
                    markerSymbol.color = [
                        ...markerSymbol.color.toRgb(),
                        plotSettings.markerOpacity
                    ] as any;
                }

                // Create the number text symbol
                const numberSymbol = new TextSymbol({
                    text: markerNumber.toString(),
                    color: plotSettings.textColor,
                    font: {
                        size: plotSettings.textSize,
                        weight: 'bold',
                        family: themeFont
                    },
                    verticalAlignment: 'middle',
                    horizontalAlignment: 'center',
                    // Apply same offsets to text as marker
                    xoffset: plotSettings.markerXOffset || 0,
                    yoffset: plotSettings.markerYOffset || 0
                });

                const point = new Point({
                    x: mapPoint.x,
                    y: mapPoint.y,
                    spatialReference: mapPoint.spatialReference
                });

                // Create popup content
                let popupContent = `<div style="font-family: ${themeFont}; font-size: 12px; line-height: 1.6; padding: 8px;">`;
                popupContent += `<div style="font-weight: bold; margin-bottom: 8px;">Marker ${markerNumber}</div>`;

                if (plotSettings.showCoordinateText) {
                    popupContent += `<div style="background-color: #f5f5f5; padding: 6px; border-radius: 3px; white-space: pre-line;">${coordinateText}</div>`;
                }

                popupContent += `</div>`;

                // Create the marker graphic
                const markerGraphic = new Graphic({
                    geometry: point,
                    symbol: markerSymbol,
                    attributes: {
                        type: 'coordinate-marker',
                        number: markerNumber,
                        coordinates: coordinateText,
                        originalX: mapPoint.x,
                        originalY: mapPoint.y,
                        wkid: mapPoint.spatialReference?.wkid
                    },
                    popupTemplate: {
                        title: `📍 Coordinate Marker ${markerNumber}`,
                        content: popupContent
                    } as any
                });

                // Create the number text graphic
                const textGraphic = new Graphic({
                    geometry: point,
                    symbol: numberSymbol,
                    attributes: {
                        type: 'coordinate-text',
                        parentMarker: markerNumber
                    }
                });

                // Add the main graphics first
                mapView.graphics.addMany([markerGraphic, textGraphic]);

                // Create coordinate label graphic (if enabled)
                if (plotSettings.showCoordinateLabels !== false) { // Default to true if undefined

                    // Calculate offset position for label - use a simple pixel-based offset
                    const offsetPixels = plotSettings.labelOffset || 20;
                    const currentScale = mapView.scale;
                    const mapUnitsPerPixel = currentScale / 96 / 39.37; // Convert to map units
                    const offsetMapUnits = offsetPixels * mapUnitsPerPixel;

                    const labelPoint = new Point({
                        x: mapPoint.x + offsetMapUnits,
                        y: mapPoint.y - offsetMapUnits, // Offset down and right
                        spatialReference: mapPoint.spatialReference
                    });

                    // Create label symbol
                    const labelSymbol = new TextSymbol({
                        text: coordinateLabel,
                        color: plotSettings.labelTextColor || '#000000',
                        haloColor: '#ffffff',
                        haloSize: 2,
                        font: {
                            size: plotSettings.labelTextSize || 10,
                            weight: 'normal',
                            family: themeFont
                        },
                        verticalAlignment: 'top',
                        horizontalAlignment: 'left'
                    });

                    const labelGraphic = new Graphic({
                        geometry: labelPoint,
                        symbol: labelSymbol,
                        attributes: {
                            type: 'coordinate-label',
                            parentMarker: markerNumber
                        }
                    });

                    mapView.graphics.add(labelGraphic);
                }

                // Create coordinate marker object
                const newMarker: CoordinateMarker = {
                    id: `marker-${markerNumber}`,
                    number: markerNumber,
                    point: mapPoint.clone(),
                    graphic: markerGraphic,
                    coordinateText: coordinateText
                };

                // Update state
                setState(prev => ({
                    ...prev,
                    coordinateMarkers: [...prev.coordinateMarkers, newMarker],
                    nextMarkerNumber: prev.nextMarkerNumber + 1
                }));
                graphicHistoryRef.current.push({ kind: 'coord', id: newMarker.id });

                // Announce success
                announce(`Coordinate marker ${markerNumber} placed on map`);

            } catch (error) {
                alert('Error creating coordinate marker: ' + error.message);
            }

        } catch (error) {
            alert(`Error plotting coordinate: ${error.message}`);
        }
    }, [state.contextMenu, state.nextMarkerNumber, props.config?.plotSettings, manualProjectToLatLon, convertToDMS, announce, themeFont]);

    // Plot simple marker function
    const plotSimpleMarker = React.useCallback(() => {
        const { mapPoint } = state.contextMenu;
        const mapView = mapViewRef.current;
        if (!mapView || !mapPoint) return;

        try {
            const markerSettings = props.config?.markerSettings || {
                markerSize: 8,
                markerColor: '#0078ff',
                markerStyle: 'circle',
                markerOutlineColor: '#ffffff',
                markerOutlineWidth: 1,
                markerOpacity: 1,
                markerAngle: 0,
                markerXOffset: 0,
                markerYOffset: 0
            };

            try {
                // NEW: Create enhanced simple marker symbol with all style options
                const markerSymbol = new SimpleMarkerSymbol({
                    color: markerSettings.markerColor,
                    outline: {
                        color: markerSettings.markerOutlineColor || '#ffffff',
                        width: markerSettings.markerOutlineWidth || 1
                    },
                    size: markerSettings.markerSize,
                    style: (markerSettings.markerStyle || 'circle') as any,
                    // Add rotation, offsets
                    angle: markerSettings.markerAngle || 0,
                    xoffset: markerSettings.markerXOffset || 0,
                    yoffset: markerSettings.markerYOffset || 0
                });

                // Apply opacity if supported
                if (markerSettings.markerOpacity !== undefined && markerSettings.markerOpacity !== 1) {
                    markerSymbol.color = [
                        ...markerSymbol.color.toRgb(),
                        markerSettings.markerOpacity
                    ] as any;
                }

                const point = new Point({
                    x: mapPoint.x,
                    y: mapPoint.y,
                    spatialReference: mapPoint.spatialReference
                });

                // Create the marker graphic
                const markerGraphic = new Graphic({
                    geometry: point,
                    symbol: markerSymbol,
                    attributes: {
                        type: 'simple-marker'
                    }
                    // No popup template - just a simple marker
                });

                mapView.graphics.add(markerGraphic);

                // Create simple marker object
                const newMarker: SimpleMarker = {
                    id: `simple-marker-${Date.now()}`,
                    point: mapPoint.clone(),
                    graphic: markerGraphic
                };

                // Update state
                setState(prev => ({
                    ...prev,
                    simpleMarkers: [...prev.simpleMarkers, newMarker]
                }));
                graphicHistoryRef.current.push({ kind: 'marker', id: newMarker.id });

                // Announce success
                announce('Marker placed on map');

            } catch (error) {
                alert('Error creating simple marker: ' + error.message);
            }

        } catch (error) {
            alert(`Error plotting simple marker: ${error.message}`);
        }
    }, [state.contextMenu, props.config?.markerSettings, announce]);

    // Clear all coordinate markers
    const clearCoordinateMarkers = React.useCallback(() => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        // Remove all coordinate graphics from map
        const coordinateGraphics = mapView.graphics.filter((graphic: any) => {
            return graphic.attributes?.type === 'coordinate-marker' ||
                graphic.attributes?.type === 'coordinate-text' ||
                graphic.attributes?.type === 'coordinate-label';
        });

        const count = coordinateGraphics.length;
        mapView.graphics.removeMany(coordinateGraphics.toArray());

        // Reset state
        setState(prev => ({
            ...prev,
            coordinateMarkers: [],
            nextMarkerNumber: 1
        }));

        graphicHistoryRef.current = graphicHistoryRef.current.filter(h => h.kind !== 'coord');
        announce(`${count} coordinate markers cleared`);
    }, [announce]);

    // Clear all simple markers
    const clearSimpleMarkers = React.useCallback(() => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        // Remove all simple marker graphics from map
        const simpleMarkerGraphics = mapView.graphics.filter((graphic: any) => {
            return graphic.attributes?.type === 'simple-marker';
        });

        const count = simpleMarkerGraphics.length;
        mapView.graphics.removeMany(simpleMarkerGraphics.toArray());

        // Reset state
        setState(prev => ({
            ...prev,
            simpleMarkers: []
        }));

        graphicHistoryRef.current = graphicHistoryRef.current.filter(h => h.kind !== 'marker');
        announce(`${count} markers cleared`);
    }, [announce]);

    // Clear all graphics
    const clearAllGraphics = React.useCallback(() => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        // Remove ALL graphics from map (markers + text + measurement labels)
        const allGraphics = mapView.graphics.filter((graphic: any) => {
            return graphic.attributes?.type === 'coordinate-marker' ||
                graphic.attributes?.type === 'coordinate-text' ||
                graphic.attributes?.type === 'coordinate-label' ||
                graphic.attributes?.type === 'simple-marker' ||
                graphic.attributes?.type === 'text-graphic' ||
                graphic.attributes?.type === 'segment-label' ||
                graphic.attributes?.type === 'total-label' ||
                graphic.attributes?.type === 'area-label' ||
                graphic.attributes?.type === 'perimeter-label' ||
                graphic.attributes?.type === 'measurement-graphic';
        });

        const count = allGraphics.length;
        mapView.graphics.removeMany(allGraphics.toArray());

        // Reset all states
        setState(prev => ({
            ...prev,
            coordinateMarkers: [],
            nextMarkerNumber: 1,
            simpleMarkers: [],
            textGraphics: []
        }));
        graphicHistoryRef.current = [];

        announce(`${count} graphics cleared from map`);
    }, [announce]);

    // Undo the most recently placed graphic (coordinate marker, simple
    // marker, or text), whichever type it was. Coordinate markers carry
    // companion graphics (number text and coordinate label) tagged with
    // parentMarker, so those are removed with the marker.
    const undoLastGraphic = React.useCallback(() => {
        const mapView = mapViewRef.current;
        if (!mapView) return;
        const last = graphicHistoryRef.current.pop();
        if (!last) { announce('Nothing to undo'); return; }

        setState(prev => {
            const next = { ...prev };
            try {
                if (last.kind === 'text') {
                    const item = prev.textGraphics.find(t => t.id === last.id);
                    if (item) {
                        try { mapView.graphics.remove(item.graphic); } catch (e) { /* ignore */ }
                        next.textGraphics = prev.textGraphics.filter(t => t.id !== last.id);
                    }
                } else if (last.kind === 'marker') {
                    const item = prev.simpleMarkers.find(m => m.id === last.id);
                    if (item) {
                        try { mapView.graphics.remove(item.graphic); } catch (e) { /* ignore */ }
                        next.simpleMarkers = prev.simpleMarkers.filter(m => m.id !== last.id);
                    }
                } else if (last.kind === 'coord') {
                    const item = prev.coordinateMarkers.find(m => m.id === last.id);
                    if (item) {
                        const related = mapView.graphics.filter((g: any) =>
                            g === item.graphic || g.attributes?.parentMarker === item.number
                        );
                        try { mapView.graphics.removeMany(related.toArray()); } catch (e) { /* ignore */ }
                        next.coordinateMarkers = prev.coordinateMarkers.filter(m => m.id !== last.id);
                        // If the undone marker was the highest-numbered one, give the
                        // number back so the sequence stays contiguous.
                        if (item.number === prev.nextMarkerNumber - 1) {
                            next.nextMarkerNumber = item.number;
                        }
                    }
                }
            } catch (e) { /* ignore */ }
            return next;
        });
        announce('Last graphic removed');
    }, [announce]);

    // Open the right-click location in Google Maps (satellite context, pin
    // at the point). Uses the same accurate lat/lon that Street View uses.
    const openGoogleMaps = React.useCallback(() => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        if (!mapViewRef.current || !mapPoint) return;
        const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);
        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) {
            announce('Unable to open Google Maps for this location');
            return;
        }
        const url = `https://www.google.com/maps/search/?api=1&query=${lat.toFixed(7)},${lon.toFixed(7)}`;
        window.open(url, '_blank', 'noopener,noreferrer');
        announce('Opened location in Google Maps');
    }, [state.contextMenu, manualProjectToLatLon, announce]);

    const openStreetView = React.useCallback(() => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        if (!mapViewRef.current || !mapPoint) return;

        // Use pre-computed projectedLatLon (set async on right-click, accurate by the time
        // user clicks the menu item). Fall back to manual math if not yet available.
        const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);

        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) {
            alert('Invalid coordinates - cannot open Street View');
            return;
        }

        const streetViewUrl = `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${lat},${lon}`;
        window.open(streetViewUrl, '_blank');
    }, [state.contextMenu, manualProjectToLatLon]);

    const openPictometryView = React.useCallback(() => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        if (!mapViewRef.current || !mapPoint || !props.config?.pictometryUrl) return;

        // Use pre-computed projectedLatLon (set async on right-click, accurate by the time
        // user clicks the menu item). Fall back to manual math if not yet available.
        const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);

        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) {
            alert('Invalid coordinates - cannot open Pictometry');
            return;
        }

        const pictometryUrl = `${props.config.pictometryUrl}?x=${lon.toFixed(14)}&y=${lat.toFixed(14)}`;
        window.open(pictometryUrl, '_blank');
    }, [state.contextMenu, manualProjectToLatLon, props.config?.pictometryUrl]);

    const startMeasurement = React.useCallback(async () => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        try {
            if (state.measurementWidget) {
                if ((state.measurementWidget as any).__disconnectObserver) {
                    (state.measurementWidget as any).__disconnectObserver();
                }
                state.measurementWidget.destroy();
            }

            // Only remove DISTANCE measurement labels, preserve area labels
            const measurementGraphics = mapView.graphics.filter((graphic: any) => {
                return graphic.attributes?.type === 'segment-label' ||
                    graphic.attributes?.type === 'total-label' ||
                    graphic.attributes?.type === 'measurement-graphic';
            });
            mapView.graphics.removeMany(measurementGraphics.toArray());

            const validUnits = ['feet', 'yards', 'miles', 'meters', 'kilometers'];
            const measurementSettings = props.config?.measurementSettings || {
                defaultUnits: 'feet',
                unitDisplay: 'single'
            };

            // Snapshot layers BEFORE widget creation
            const labelSuppressor = createLabelSuppressor(mapView);
            labelSuppressor.snapshotLayers();

            Promise.all([
                loadArcGISJSAPIModules([
                    'esri/widgets/DistanceMeasurement2D',
                    'esri/Graphic',
                    'esri/symbols/TextSymbol',
                    'esri/geometry/Point',
                    'esri/geometry/Polyline'
                ]),
                loadLengthAreaMath()
            ]).then(([[DistanceMeasurement2D, Graphic, TextSymbol, Point, Polyline], geometryEngine]: [any[], any]) => {
                try {
                    const distanceMeasurement2D = new DistanceMeasurement2D({
                        view: mapView,
                        unitOptions: validUnits as any
                    });

                    // Suppress ESRI's built-in on-map text labels
                    const cancelLabelSuppression = labelSuppressor.startSuppression();

                    let primaryUnit: string = 'feet';
                    let secondaryUnit: string | null = null;

                    if (validUnits.includes(measurementSettings.defaultUnits)) {
                        primaryUnit = measurementSettings.defaultUnits;
                    }

                    if (measurementSettings.unitDisplay === 'both') {
                        switch (primaryUnit) {
                            case 'feet': secondaryUnit = 'meters'; break;
                            case 'meters': secondaryUnit = 'feet'; break;
                            case 'miles': secondaryUnit = 'kilometers'; break;
                            case 'kilometers': secondaryUnit = 'miles'; break;
                            case 'yards': secondaryUnit = 'meters'; break;
                        }
                    }

                    const initializeDistanceUnit = () => {
                        try {
                            distanceMeasurement2D.unit = primaryUnit;
                            if (distanceMeasurement2D.viewModel) {
                                distanceMeasurement2D.viewModel.unit = primaryUnit;
                            }
                        } catch (e) {
                        }
                    };

                    mapView.ui.add(distanceMeasurement2D, 'top-right');
                    initializeDistanceUnit();

                    distanceMeasurement2D.when(() => {
                        const disconnectObserver = hideUnwantedUnits(distanceMeasurement2D, 'distance');
                        // Store disconnect so cleanup can call it
                        (distanceMeasurement2D as any).__disconnectObserver = disconnectObserver;
                        setTimeout(() => initializeDistanceUnit(), 100);
                        setTimeout(() => initializeDistanceUnit(), 300);
                        setTimeout(() => initializeDistanceUnit(), 500);
                    });

                    setTimeout(() => {
                        distanceMeasurement2D.viewModel.start();
                        initializeDistanceUnit();
                    }, 200);

                    const formatDistance = (distance: number, unit: string): string => {
                        let formatted = `${distance.toFixed(2)} ${unit}`;
                        if (secondaryUnit && measurementSettings.unitDisplay === 'both') {
                            const conversions: Record<string, number> = {
                                'feet->meters': 0.3048, 'meters->feet': 3.28084,
                                'miles->kilometers': 1.60934, 'kilometers->miles': 0.621371,
                                'yards->meters': 0.9144, 'meters->yards': 1.09361
                            };
                            const key = `${unit}->${secondaryUnit}`;
                            const factor = conversions[key] ?? 1;
                            const converted = distance * factor;
                            formatted += ` (${converted.toFixed(2)} ${secondaryUnit})`;
                        }
                        return formatted;
                    };

                    const createLabel = (pt: __esri.Point, text: string, attrType: string) => {
                        const label = new Graphic({
                            geometry: pt,
                            symbol: new TextSymbol({
                                text,
                                color: [255, 255, 255],
                                haloColor: [0, 0, 0],
                                haloSize: 2,
                                font: { size: 12, family: themeFont, weight: 'bold' },
                                verticalAlignment: 'middle',
                                horizontalAlignment: 'center'
                            }),
                            attributes: { type: attrType }
                        });
                        mapView.graphics.add(label);
                    };

                    const drawLabels = (geometry: __esri.Geometry, unit: string) => {
                        const polyline = geometry as __esri.Polyline;
                        const path = polyline.paths?.[0];
                        if (!path) return;

                        const points = path.map(([x, y]) => new Point({
                            x, y,
                            spatialReference: mapView.spatialReference
                        }));

                        let total = 0;

                        // Synchronous distance calculation — no nested require needed.
                        // geometryEngine and Polyline are already loaded from the outer require.
                        // Strategy: geodesicLength (needs WASM, works on Portal) →
                        //           planarLength (no WASM, handles any projected SR) →
                        //           Euclidean math fallback.
                        const calculateAccurateDistance = (point1: any, point2: any, unit: string): number => {
                            try {
                                const line = new Polyline({
                                    paths: [[[point1.x, point1.y], [point2.x, point2.y]]],
                                    spatialReference: point1.spatialReference
                                });

                                // Primary: geodesic (correct for any SR, needs WASM - works on Portal)
                                try {
                                    const geodesic = geometryEngine.geodesicLength(line, unit);
                                    if (geodesic > 0) {
                                        return geodesic;
                                    }
                                } catch (e) {
                                }

                                // Fallback: planar (no WASM, converts units via JSAPI, any projected SR)
                                try {
                                    const planar = geometryEngine.planarLength(line, unit);
                                    if (planar > 0) {
                                        return planar;
                                    }
                                } catch (e) {
                                }

                                // Last resort: Euclidean math
                                const dx = point2.x - point1.x;
                                const dy = point2.y - point1.y;
                                const rawDist = Math.sqrt(dx * dx + dy * dy);
                                const unitConversions: Record<string, number> = {
                                    'feet': 3.28084, 'yards': 1.09361, 'miles': 0.000621371,
                                    'kilometers': 0.001, 'meters': 1
                                };
                                const euclidean = rawDist * (unitConversions[unit] ?? 1);
                                return euclidean;
                            } catch (e) {
                                return 0;
                            }
                        };

                        // Calculate distances for each segment (sync - no await needed)
                        for (let i = 0; i < points.length - 1; i++) {
                            const seg = calculateAccurateDistance(points[i], points[i + 1], unit);
                            total += seg;

                            const mid = new Point({
                                x: (points[i].x + points[i + 1].x) / 2,
                                y: (points[i].y + points[i + 1].y) / 2,
                                spatialReference: mapView.spatialReference
                            });
                            createLabel(mid, formatDistance(seg, unit), 'segment-label');
                        }

                        if (points.length > 1) {
                            const lastPoint = points[points.length - 1];
                            const offset = new Point({
                                x: lastPoint.x,
                                y: lastPoint.y + (mapView.extent.height * 0.01),
                                spatialReference: mapView.spatialReference
                            });
                            createLabel(offset, `Total: ${formatDistance(total, unit)}`, 'total-label');
                        }
                    };

                    const clearLabels = () => {
                        const labels = mapView.graphics.filter((g: any) =>
                            ['segment-label', 'total-label'].includes(g.attributes?.type)
                        );
                        mapView.graphics.removeMany(labels.toArray());
                    };

                    const watchHandles: __esri.WatchHandle[] = [];

                    watchHandles.push(reactiveUtils.watch(() => distanceMeasurement2D.viewModel.measurement, (m: any) => {
                        if (!m?.geometry) return;
                        clearLabels();
                        drawLabels(m.geometry, distanceMeasurement2D.unit);
                    }));

                    watchHandles.push(reactiveUtils.watch(() => distanceMeasurement2D.unit, (newUnit: string) => {
                        if (!validUnits.includes(newUnit)) {
                            setTimeout(() => {
                                distanceMeasurement2D.unit = primaryUnit;
                            }, 50);
                            return;
                        }
                        const m = distanceMeasurement2D.viewModel.measurement;
                        if (!m?.geometry) return;
                        clearLabels();
                        // Handle async drawLabels function
                        drawLabels(m.geometry, newUnit);
                    }));

                    watchHandles.push(reactiveUtils.watch(() => distanceMeasurement2D.viewModel.state, (s: string) => {
                        if (s === 'ready') {
                            clearLabels();
                        } else if (s === 'measured') {
                            // JSAPI 5.x: geometry may only be available on state='measured'
                            // (during 'measuring' state, m.geometry can be null)
                            const m = distanceMeasurement2D.viewModel.measurement as any;
                            if (!m) return;
                            clearLabels();
                            if (m.geometry) {
                                drawLabels(m.geometry, distanceMeasurement2D.unit);
                            } else if (m.length > 0) {
                                // Final fallback: show total from m.length at view center
                                try {
                                    createLabel(
                                        mapView.center,
                                        `Total: ${formatDistance(m.length, distanceMeasurement2D.unit)}`,
                                        'total-label'
                                    );
                                } catch (_) { /* silent */ }
                            }
                        }
                    }));

                    const cleanup = () => {
                        clearLabels();
                        cancelLabelSuppression();
                        if ((distanceMeasurement2D as any).__disconnectObserver) {
                            (distanceMeasurement2D as any).__disconnectObserver();
                        }
                        watchHandles.forEach(h => h.remove());
                        mapView.ui.remove(distanceMeasurement2D);
                        distanceMeasurement2D.destroy();
                        setState(prev => ({ ...prev, isMeasuring: false, measurementWidget: null }));
                    };

                    const handleKey = (e: KeyboardEvent) => {
                        if (e.key === 'Escape') {
                            cleanup();
                            document.removeEventListener('keydown', handleKey);
                        }
                    };
                    document.addEventListener('keydown', handleKey);

                    distanceMeasurement2D.when(() => {
                        const widget = distanceMeasurement2D.container;
                        if (!widget) return;

                        setTimeout(() => {
                            const container = document.createElement('div');
                            container.style.cssText = 'display:flex;justify-content:center;gap:8px;margin-top:12px;padding:0 12px 12px;';

                            const closeBtn = document.createElement('button');
                            closeBtn.textContent = 'Close';
                            closeBtn.style.cssText = `background:#6c757d;color:white;border:none;padding:10px 20px;border-radius:4px;cursor:pointer;font-size:13px;font-weight:500;font-family:${themeFont};`;
                            closeBtn.onmouseenter = () => closeBtn.style.background = '#545b62';
                            closeBtn.onmouseleave = () => closeBtn.style.background = '#6c757d';
                            closeBtn.onclick = (e) => {
                                e.preventDefault(); e.stopPropagation();
                                cleanup();
                                document.removeEventListener('keydown', handleKey);
                            };

                            container.appendChild(closeBtn);
                            widget.appendChild(container);

                            widget.style.cssText += `background:rgba(255,255,255,0.95);backdrop-filter:blur(10px);border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);border:1px solid rgba(0,0,0,0.1);min-width:260px;font-family:${themeFont};`;
                        }, 300);
                    });

                    setState(prev => ({
                        ...prev,
                        isMeasuring: true,
                        measurementWidget: distanceMeasurement2D
                    }));
                } catch (err: any) {
                }
            }).catch((err: any) => {
                console.warn('[rightclick] Failed to load distance measurement modules:', err);
            });
        } catch (err: any) {
        }
    }, [state.measurementWidget, props.config?.measurementSettings]);

    const startAreaMeasurement = React.useCallback(async () => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        try {
            if (state.areaMeasurementWidget) {
                if ((state.areaMeasurementWidget as any).__disconnectObserver) {
                    (state.areaMeasurementWidget as any).__disconnectObserver();
                }
                state.areaMeasurementWidget.destroy();
            }

            // Only remove AREA measurement labels, preserve distance labels
            const areaGraphics = mapView.graphics.filter((graphic: any) => {
                return graphic.attributes?.type === 'area-label' ||
                    graphic.attributes?.type === 'perimeter-label';
            });
            mapView.graphics.removeMany(areaGraphics.toArray());

            const measurementSettings = props.config?.measurementSettings || {
                defaultUnits: 'feet',
                unitDisplay: 'single'
            };

            // Snapshot layers BEFORE widget creation
            const labelSuppressor = createLabelSuppressor(mapView);
            labelSuppressor.snapshotLayers();

            Promise.all([
                loadArcGISJSAPIModules([
                    'esri/widgets/AreaMeasurement2D',
                    'esri/Graphic',
                    'esri/symbols/TextSymbol',
                    'esri/geometry/Point'
                ]),
                loadLengthAreaMath()
            ]).then(([[AreaMeasurement2D, Graphic, TextSymbol, Point], geometryEngine]: [any[], any]) => {
                try {
                    const validAreaUnits = ['square-feet', 'square-yards', 'square-miles', 'square-meters', 'square-kilometers', 'acres'];
                    const areaMeasurement2D = new AreaMeasurement2D({
                        view: mapView,
                        unitOptions: validAreaUnits as any
                    });
                    const measurement = areaMeasurement2D;

                    // Suppress ESRI's built-in on-map text labels
                    const cancelLabelSuppression = labelSuppressor.startSuppression();

                    let primaryUnit: string;
                    let secondaryUnit: string | null = null;

                    switch (measurementSettings.defaultUnits) {
                        case 'feet': primaryUnit = 'square-feet'; break;
                        case 'meters': primaryUnit = 'square-meters'; break;
                        case 'miles': primaryUnit = 'square-miles'; break;
                        case 'kilometers': primaryUnit = 'square-kilometers'; break;
                        case 'yards': primaryUnit = 'square-yards'; break;
                        default: primaryUnit = 'square-feet';
                    }

                    if (measurementSettings.unitDisplay === 'both') {
                        switch (measurementSettings.defaultUnits) {
                            case 'feet': secondaryUnit = 'square-meters'; break;
                            case 'meters': secondaryUnit = 'square-feet'; break;
                            case 'miles': secondaryUnit = 'square-kilometers'; break;
                            case 'kilometers': secondaryUnit = 'square-miles'; break;
                            case 'yards': secondaryUnit = 'square-meters'; break;
                        }
                    }

                    const initializeUnit = () => {
                        try {
                            measurement.unit = primaryUnit;
                            if (measurement.viewModel) {
                                measurement.viewModel.unit = primaryUnit;
                            }
                        } catch (e) {
                        }
                    };

                    // --- Custom area label helpers ---
                    const unitDisplayNames: Record<string, string> = {
                        'square-feet': 'sq ft', 'square-meters': 'sq m',
                        'square-miles': 'sq mi', 'square-kilometers': 'sq km',
                        'square-yards': 'sq yd', 'acres': 'acres'
                    };

                    const areaConversions: Record<string, number> = {
                        'square-feet->square-meters': 0.092903,
                        'square-meters->square-feet': 10.7639,
                        'square-miles->square-kilometers': 2.58999,
                        'square-kilometers->square-miles': 0.386102,
                        'square-yards->square-meters': 0.836127,
                        'square-meters->square-yards': 1.19599
                    };

                    const formatArea = (area: number, unit: string): string => {
                        const displayUnit = unitDisplayNames[unit] || unit;
                        let formatted = `${area.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${displayUnit}`;
                        if (secondaryUnit && measurementSettings.unitDisplay === 'both') {
                            const key = `${unit}->${secondaryUnit}`;
                            const factor = areaConversions[key] ?? 1;
                            const converted = area * factor;
                            const secDisplay = unitDisplayNames[secondaryUnit] || secondaryUnit;
                            formatted += ` (${converted.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${secDisplay})`;
                        }
                        return formatted;
                    };

                    const formatPerimeter = (perim: number, unit: string): string => {
                        const linearUnitMap: Record<string, string> = {
                            'square-feet': 'feet', 'square-meters': 'meters',
                            'square-miles': 'miles', 'square-kilometers': 'kilometers',
                            'square-yards': 'yards', 'acres': 'feet'
                        };
                        const linearUnit = linearUnitMap[unit] || 'feet';
                        return `Perimeter: ${perim.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${linearUnit}`;
                    };

                    const createAreaLabel = (pt: __esri.Point, text: string, attrType: string) => {
                        const label = new Graphic({
                            geometry: pt,
                            symbol: new TextSymbol({
                                text,
                                color: [255, 255, 255],
                                haloColor: [0, 0, 0],
                                haloSize: 2,
                                font: { size: 12, family: themeFont, weight: 'bold' },
                                verticalAlignment: 'middle',
                                horizontalAlignment: 'center'
                            }),
                            attributes: { type: attrType }
                        });
                        mapView.graphics.add(label);
                    };

                    const clearAreaLabels = () => {
                        const labels = mapView.graphics.filter((g: any) =>
                            ['area-label', 'perimeter-label'].includes(g.attributes?.type)
                        );
                        mapView.graphics.removeMany(labels.toArray());
                    };

                    const drawAreaLabels = (m: any, unit: string) => {
                        clearAreaLabels();
                        try {
                            const geometry = m?.geometry;
                            if (!geometry) return;

                            // Compute area directly from geometry using geometryEngine
                            // so we get the correct value in the requested unit.
                            // m.area is in the map's native SR units (sq meters for UTM)
                            // regardless of the widget's unit setting.
                            // Strategy: geodesicArea (needs WASM, works on Portal) →
                            //           planarArea (no WASM, any projected SR)
                            let area = 0;
                            try {
                                area = Math.abs(geometryEngine.geodesicArea(geometry, unit as any));
                            } catch (_) { /* WASM not available in local dev */ }
                            if (!area) {
                                try {
                                    area = Math.abs(geometryEngine.planarArea(geometry, unit as any));
                                } catch (_) { /* silent */ }
                            }
                            if (!area) return;

                            // Perimeter: use planarLength on the polygon's rings as a polyline
                            let perimeterLength = 0;
                            try {
                                const linearUnitMap: Record<string, string> = {
                                    'square-feet': 'feet', 'square-meters': 'meters',
                                    'square-miles': 'miles', 'square-kilometers': 'kilometers',
                                    'square-yards': 'yards', 'acres': 'feet'
                                };
                                const linearUnit = linearUnitMap[unit] || 'feet';
                                try {
                                    perimeterLength = geometryEngine.geodesicLength(geometry, linearUnit as any);
                                } catch (_) {
                                    perimeterLength = geometryEngine.planarLength(geometry, linearUnit as any);
                                }
                            } catch (_) { /* silent */ }

                            let centroid: __esri.Point | null = null;
                            if (geometry.centroid) {
                                centroid = geometry.centroid;
                            } else if (geometry.extent) {
                                centroid = geometry.extent.center;
                            }
                            if (!centroid) return;

                            createAreaLabel(centroid, `Area: ${formatArea(area, unit)}`, 'area-label');

                            if (perimeterLength > 0) {
                                const offset = new Point({
                                    x: centroid.x,
                                    y: centroid.y - (mapView.extent.height * 0.02),
                                    spatialReference: mapView.spatialReference
                                });
                                createAreaLabel(offset, formatPerimeter(perimeterLength, unit), 'perimeter-label');
                            }
                        } catch (e) {
                        }
                    };
                    // --- End custom area label helpers ---

                    mapView.ui.add(measurement, 'top-right');
                    initializeUnit();

                    measurement.when(() => {
                        const disconnectObserver = hideUnwantedUnits(measurement, 'area');
                        // Store disconnect so cleanup can call it
                        (measurement as any).__disconnectObserver = disconnectObserver;
                        setTimeout(() => initializeUnit(), 100);
                        setTimeout(() => initializeUnit(), 300);
                        setTimeout(() => initializeUnit(), 500);

                        const widget = measurement.container;
                        if (!widget) return;

                        setTimeout(() => {
                            const container = document.createElement('div');
                            container.style.cssText = 'display:flex;justify-content:center;gap:8px;margin-top:12px;padding:0 12px 12px;';

                            const closeBtn = document.createElement('button');
                            closeBtn.textContent = 'Close';
                            closeBtn.style.cssText = `background:#6c757d;color:white;border:none;padding:10px 20px;border-radius:4px;cursor:pointer;font-size:13px;font-weight:500;font-family:${themeFont};`;
                            closeBtn.onmouseenter = () => closeBtn.style.background = '#545b62';
                            closeBtn.onmouseleave = () => closeBtn.style.background = '#6c757d';
                            closeBtn.onclick = (e) => {
                                e.preventDefault(); e.stopPropagation();
                                cleanup();
                                document.removeEventListener('keydown', handleKeyPress);
                            };

                            container.appendChild(closeBtn);
                            widget.appendChild(container);

                            widget.style.cssText += `background:rgba(255,255,255,0.95);backdrop-filter:blur(10px);border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);border:1px solid rgba(0,0,0,0.1);min-width:260px;font-family:${themeFont};`;
                        }, 300);
                    });

                    setTimeout(() => {
                        measurement.viewModel.start();
                        initializeUnit();
                    }, 200);

                    // Watch for measurement updates to draw custom labels
                    const areaWatchHandles: __esri.WatchHandle[] = [];

                    areaWatchHandles.push(reactiveUtils.watch(() => measurement.viewModel.measurement, (m: any) => {
                        if (!m) return;
                        drawAreaLabels(m, measurement.unit);
                    }));

                    areaWatchHandles.push(reactiveUtils.watch(() => measurement.unit, (newUnit: string) => {
                        if (!validAreaUnits.includes(newUnit)) {
                            setTimeout(() => {
                                measurement.unit = primaryUnit;
                            }, 50);
                            return;
                        }
                        const m = measurement.viewModel.measurement;
                        if (m) drawAreaLabels(m, newUnit);
                    }));

                    areaWatchHandles.push(reactiveUtils.watch(() => measurement.viewModel.state, (s: string) => {
                        if (s === 'ready') clearAreaLabels();
                    }));

                    setState(prevState => ({
                        ...prevState,
                        isMeasuringArea: true,
                        areaMeasurementWidget: measurement as any
                    }));

                    const cleanup = () => {
                        clearAreaLabels();
                        cancelLabelSuppression();
                        if ((measurement as any).__disconnectObserver) {
                            (measurement as any).__disconnectObserver();
                        }
                        areaWatchHandles.forEach(h => h.remove());
                        if (measurement) {
                            mapView.ui.remove(measurement);
                            measurement.destroy();
                        }
                        setState(prevState => ({
                            ...prevState,
                            isMeasuringArea: false,
                            areaMeasurementWidget: null
                        }));
                    };

                    const handleKeyPress = (event: KeyboardEvent) => {
                        if (event.key === 'Escape') {
                            cleanup();
                            document.removeEventListener('keydown', handleKeyPress);
                        }
                    };
                    document.addEventListener('keydown', handleKeyPress);

                } catch (error) {
                }
            }).catch((error: any) => {
                console.warn('[rightclick] Failed to load area measurement modules:', error);
            });

        } catch (error) {
        }
    }, [state.areaMeasurementWidget, props.config?.measurementSettings]);

    const queryFeatureLayer = React.useCallback(async (
        layer: FeatureLayerConfig,
        mapPoint: __esri.Point
    ): Promise<{ layerName: string; features: any[]; layerUrl: string }> => {
        try {
            const whatsHereSettings = props.config?.whatsHereSettings || {};

            // Use the original map point coordinate system for the query
            let queryPoint = mapPoint;

            // Only project if a specific target WKID is configured
            if (props.config?.reverseGeocodeWkid && props.config.reverseGeocodeWkid !== mapPoint.spatialReference?.wkid) {
                try {
                    queryPoint = await projectToSpatialReference(mapPoint, props.config.reverseGeocodeWkid);
                } catch (projectionError) {
                    queryPoint = mapPoint;
                }
            }

            const queryUrl = `${layer.url}/query`;

            // Create geometry object properly
            const geometryObj = {
                x: queryPoint.x,
                y: queryPoint.y,
                spatialReference: {
                    wkid: queryPoint.spatialReference?.wkid || 4326
                }
            };

            // Ensure proper spatial relationship values
            const defaultSpatialRel = whatsHereSettings.spatialRelationship || 'esriSpatialRelIntersects';

            // Validate and fix spatial relationship values
            const validSpatialRel = defaultSpatialRel.startsWith('esriSpatialRel')
                ? defaultSpatialRel
                : `esriSpatialRel${defaultSpatialRel.charAt(0).toUpperCase()}${defaultSpatialRel.slice(1)}`;

            const spatialRelationships = [
                validSpatialRel,
                'esriSpatialRelIntersects',
                'esriSpatialRelContains',
                'esriSpatialRelWithin'
            ];

            // Try without distance first, then with distance, then with simplified parameters
            const queryAttempts = [];

            // Attempt 1: Basic query
            queryAttempts.push({
                geometry: JSON.stringify(geometryObj),
                geometryType: 'esriGeometryPoint',
                spatialRel: spatialRelationships[0],
                outFields: (layer.fields && layer.fields.length > 0) ? layer.fields.join(',') : '*',
                // Always return geometry — needed for highlight + Zoom-to.
                // The whatsHereSettings.includeGeometry flag is now ignored
                // for these queries (it predates those features).
                returnGeometry: 'true',
                resultRecordCount: (whatsHereSettings.maxResults || 10).toString(),
                f: 'json'
            });

            // Attempt 2: With buffer if configured
            if (whatsHereSettings.searchRadius && whatsHereSettings.searchRadius > 0) {
                queryAttempts.push({
                    geometry: JSON.stringify(geometryObj),
                    geometryType: 'esriGeometryPoint',
                    spatialRel: spatialRelationships[0],
                    outFields: (layer.fields && layer.fields.length > 0) ? layer.fields.join(',') : '*',
                    returnGeometry: 'true',
                    resultRecordCount: (whatsHereSettings.maxResults || 10).toString(),
                    distance: whatsHereSettings.searchRadius.toString(),
                    units: 'esriSRUnit_Meter',
                    f: 'json'
                });
            }

            // Attempt 3: Simplified query with just coordinates
            queryAttempts.push({
                geometry: `${queryPoint.x},${queryPoint.y}`,
                geometryType: 'esriGeometryPoint',
                spatialRel: 'esriSpatialRelIntersects',
                outFields: '*',
                returnGeometry: 'false',
                f: 'json'
            });

            // Attempt 4: Using envelope instead of point
            const tolerance = 1; // 1 meter tolerance
            const envelope = {
                xmin: queryPoint.x - tolerance,
                ymin: queryPoint.y - tolerance,
                xmax: queryPoint.x + tolerance,
                ymax: queryPoint.y + tolerance,
                spatialReference: { wkid: queryPoint.spatialReference?.wkid || 4326 }
            };

            queryAttempts.push({
                geometry: JSON.stringify(envelope),
                geometryType: 'esriGeometryEnvelope',
                spatialRel: 'esriSpatialRelIntersects',
                outFields: (layer.fields && layer.fields.length > 0) ? layer.fields.join(',') : '*',
                returnGeometry: 'false',
                f: 'json'
            });

            let lastError = null;

            for (let attemptIndex = 0; attemptIndex < queryAttempts.length; attemptIndex++) {
                const queryParams = queryAttempts[attemptIndex];
                const params = new URLSearchParams(queryParams);
                // Add ordering if specified
                if (whatsHereSettings.orderBy) {
                    params.append('orderByFields', whatsHereSettings.orderBy);
                }
                try {
                    const response = await fetch(`${queryUrl}?${params.toString()}`, {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    });
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    const json = await response.json();
                    if (json.error) {
                        lastError = new Error(`[${json.error.code || 'Unknown'}] ${json.error.message || `Query failed for layer ${layer.name}`}`);
                        continue; // Try next attempt
                    }
                    return {
                        layerName: layer.name,
                        features: (json.features || []).map((f: any) => {
                            // REST responses give plain JSON for geometry —
                            // hydrate to a real Esri Geometry instance so
                            // highlight + zoom-to can use it directly. The
                            // top-level json.spatialReference is the shared
                            // SR for the response when individual features
                            // omit it (very common).
                            let geom: any = null;
                            if (f?.geometry) {
                                try {
                                    const withSr = (f.geometry.spatialReference || json.spatialReference)
                                        ? { ...f.geometry, spatialReference: f.geometry.spatialReference || json.spatialReference }
                                        : f.geometry;
                                    geom = (geometryJsonUtils as any).fromJSON(withSr);
                                } catch (_) { geom = null; }
                            }
                            return {
                                attributes: f.attributes || {},
                                geometry: geom
                            };
                        }),
                        layerUrl: layer.url
                    };
                } catch (error) {
                    lastError = error;
                }
            }

            // If we get here, all attempts failed
            throw lastError || new Error(`All query attempts failed for layer ${layer.name}`);

        } catch (error) {
            // Return empty result instead of throwing to prevent breaking other layers
            return { layerName: layer.name, features: [], layerUrl: layer.url };
        }
    }, [projectToSpatialReference, props.config]);

    const generatePopupContent = React.useCallback((results: Array<{ layerName: string; features: any[]; layerUrl: string }>): string => {
        const uiSettings = props.config?.uiSettings || {};
        const showLayerNames = uiSettings.showLayerNames !== false;
        const groupByLayer = uiSettings.groupByLayer !== false;
        const showFieldAliases = uiSettings.showFieldAliases !== false;

        let content = '';

        results.forEach(({ layerName, features, layerUrl }, layerIndex) => {
            if (features.length === 0) return;

            if (showLayerNames && groupByLayer) {
                content += `
                    <div style="
                        font-weight: 600; 
                        color: #323232; 
                        margin: ${layerIndex > 0 ? '20px' : '0px'} 0 12px 0; 
                        padding-bottom: 6px;
                        border-bottom: 2px solid #0079c1;
                        font-size: 15px;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    ">
                        ${layerName}
                    </div>
                `;
            }

            features.forEach((feature, featureIndex) => {
                const attributes = feature.attributes;

                if (!groupByLayer && showLayerNames) {
                    content += `
                        <div style="
                            display: flex;
                            align-items: flex-start;
                            margin-bottom: 8px;
                            padding: 6px 0;
                            border-bottom: 1px solid #e0e0e0;
                        ">
                            <div style="
                                font-weight: 600;
                                color: #0079c1;
                                white-space: nowrap;
                                flex-shrink: 0;
                                min-width: 60px;
                                font-size: 13px;
                            ">
                                Layer:
                            </div>
                            <div style="
                                color: #323232;
                                word-wrap: break-word;
                                flex: 1;
                                margin-left: 8px;
                                font-size: 13px;
                            ">
                                ${layerName}
                            </div>
                        </div>
                    `;
                }

                const filteredAttributes = Object.entries(attributes).filter(([fieldName, value]) => {
                    if (['OBJECTID', 'FID', 'SHAPE', 'Shape', 'GlobalID', 'GLOBALID'].includes(fieldName)) {
                        return false;
                    }
                    return value !== null && value !== undefined && value !== '';
                });

                filteredAttributes.forEach(([fieldName, value]) => {
                    const displayName = getFieldDisplayName(fieldName, layerUrl, showFieldAliases);
                    const formattedValue = formatFieldValue(value, fieldName);

                    content += `
                        <div style="
                            display: flex;
                            align-items: flex-start;
                            margin-bottom: 6px;
                            padding: 2px 0;
                            min-height: 20px;
                        ">
                            <div style="
                                font-weight: 600;
                                color: #0079c1;
                                white-space: nowrap;
                                flex-shrink: 0;
                                min-width: 120px;
                                font-size: 13px;
                                line-height: 1.4;
                            ">
                                ${displayName}:
                            </div>
                            <div style="
                                color: #323232;
                                word-wrap: break-word;
                                flex: 1;
                                margin-left: 8px;
                                font-size: 13px;
                                line-height: 1.4;
                            ">
                                ${formattedValue}
                            </div>
                        </div>
                    `;
                });

                if (featureIndex < features.length - 1) {
                    content += '<div style="margin: 16px 0; border-bottom: 1px solid #e8e8e8;"></div>';
                }
            });
        });

        return content || '<div style="color: #6e6e6e; font-style: italic; text-align: center; padding: 20px;">No features found at this location.</div>';
    }, [props.config?.uiSettings, state.layerFieldMetadata]);

    const getFieldDisplayName = React.useCallback((fieldName: string, layerUrl: string, useAliases: boolean): string => {
        if (!useAliases) return fieldName;

        const fieldMetadata = state.layerFieldMetadata[layerUrl]?.[fieldName];
        if (fieldMetadata?.alias && fieldMetadata.alias !== fieldName) {
            return fieldMetadata.alias;
        }

        const layer = props.config?.featureLayers?.find(l => l.url === layerUrl);
        if (layer?.aliasFields?.[fieldName]) {
            return layer.aliasFields[fieldName];
        }

        const commonAliases: Record<string, string> = {
            'OBJECTID': 'Object ID',
            'ObjectID': 'Object ID',
            'FID': 'Feature ID',
            'SHAPE': 'Geometry',
            'Shape': 'Geometry',
            'SHAPE_Area': 'Area',
            'SHAPE_Length': 'Length',
            'Shape_Area': 'Area',
            'Shape_Length': 'Length',
            'CREATED_DATE': 'Created Date',
            'LAST_EDITED_DATE': 'Last Modified',
            'CreationDate': 'Created Date',
            'EditDate': 'Last Modified',
            'GlobalID': 'Global ID',
            'GLOBALID': 'Global ID',
            'NAME': 'Name',
            'Name': 'Name',
            'TYPE': 'Type',
            'Type': 'Type',
            'STATUS': 'Status',
            'Status': 'Status',
            'DESCRIPTION': 'Description',
            'Description': 'Description',
            'ADDRESS': 'Address',
            'Address': 'Address',
            'CITY': 'City',
            'City': 'City',
            'STATE': 'State',
            'State': 'State',
            'ZIP': 'ZIP Code',
            'ZIPCODE': 'ZIP Code',
            'ZIP_CODE': 'ZIP Code',
            'PHONE': 'Phone',
            'Phone': 'Phone',
            'EMAIL': 'Email',
            'Email': 'Email',
            'URL': 'Website',
            'WEBSITE': 'Website',
            'Website': 'Website',
            'TRACTCE20': 'Census Tract',
            'NAMELSAD20': 'Census Tract Name',
            'TOTALPOP': 'Total Population',
            'GEOID20': 'Geographic ID'
        };

        if (commonAliases[fieldName]) {
            return commonAliases[fieldName];
        }

        const lowerFieldName = fieldName.toLowerCase();
        const matchingKey = Object.keys(commonAliases).find(key => key.toLowerCase() === lowerFieldName);
        if (matchingKey) {
            return commonAliases[matchingKey];
        }

        return fieldName
            .replace(/_/g, ' ')
            .replace(/([A-Z])/g, ' $1')
            .replace(/\s+/g, ' ')
            .trim()
            .replace(/\b\w/g, l => l.toUpperCase());
    }, [props.config?.featureLayers, state.layerFieldMetadata]);

    const formatFieldValue = React.useCallback((value: any, fieldName: string): string => {
        if (value === null || value === undefined) return '';

        if (fieldName.toLowerCase().includes('date') || fieldName.toLowerCase().includes('time')) {
            try {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
                }
            } catch (e) {
                // Fall through to default formatting
            }
        }

        if (typeof value === 'number') {
            if (fieldName.toLowerCase().includes('area')) {
                return value.toLocaleString() + ' sq units';
            } else if (fieldName.toLowerCase().includes('length') || fieldName.toLowerCase().includes('distance')) {
                return value.toLocaleString() + ' units';
            } else if (value % 1 !== 0) {
                return value.toFixed(2);
            } else {
                return value.toLocaleString();
            }
        }

        return String(value);
    }, []);

    // ─── What's Here: auto-discovery of queryable map layers ────────────────
    // Walks the live map and returns every queryable feature-like layer
    // (FeatureLayer, GeoJSONLayer, CSVLayer, OGCFeatureLayer, WFSLayer, and
    // every Sublayer inside a MapImageLayer / TileLayer) — including those
    // nested arbitrarily deep inside GroupLayers and map service group
    // sublayers. Visibility and scale dependencies are honored so we don't
    // query layers the user has toggled off or that aren't drawn at the
    // current zoom. This is the bedrock that lets "What's Here" work without
    // any per-layer configuration in widget settings.
    const collectQueryableLayersFromMap = React.useCallback((): Array<{
        name: string;
        mapLayer: any;
        layerUrl: string;
        popupEnabled: boolean;
    }> => {
        const mv = mapViewRef.current;
        if (!mv?.map) return [];

        const currentScale = mv.scale || 0;
        const entries: Array<{ name: string; mapLayer: any; layerUrl: string; popupEnabled: boolean }> = [];
        const seenKeys = new Set<string>();

        // The Layer Selection setting drives which layers are *eligible* —
        // and on top of that, a layer must also be currently turned on in
        // the map (visible up the entire parent chain) and within its
        // scale-dependency window. "What's Here" reflects what the user can
        // actually see at this moment, so toggling a layer off in the
        // legend or zooming past its scale range hides it from results.
        const ROOT_CLASSES = new Set([
            'esri.Map',
            'esri.WebMap',
            'esri.WebScene',
            'esri.Basemap'
        ]);

        const effectivelyVisible = (lyr: any): boolean => {
            // A layer is effectively visible only if its own `visible` flag
            // AND every ancestor (parent sublayer, GroupLayer, MapImageLayer)
            // up the chain has visible !== false. The walk terminates at the
            // map/basemap container.
            let cur = lyr;
            let hops = 0;
            while (cur && hops < 50) {
                if (cur.visible === false) return false;
                const next = cur.parent;
                if (!next || next === cur) break;
                const cls = String((next as any)?.declaredClass || '');
                // Exact-equality only — previously `cls.includes('Map')` also
                // matched MapImageLayer / MapNotesLayer and terminated the
                // walk early, letting hidden parents slip through.
                if (ROOT_CLASSES.has(cls)) break;
                cur = next;
                hops++;
            }
            return true;
        };

        const inScaleRange = (lyr: any): boolean => {
            // Esri scale convention: minScale is the more-zoomed-OUT limit
            // (numerically larger); maxScale is the more-zoomed-IN limit
            // (numerically smaller). 0 means unconstrained on that end.
            // currentScale === 0 falls through and is treated as in-range.
            if (!currentScale) return true;
            const min = Number(lyr?.minScale ?? 0);
            const max = Number(lyr?.maxScale ?? 0);
            if (min > 0 && currentScale > min) return false;
            if (max > 0 && currentScale < max) return false;
            return true;
        };

        const tryAdd = (lyr: any, fallbackName: string) => {
            if (!lyr || typeof lyr.queryFeatures !== 'function') return;

            // Only query layers the user has currently turned on in the map.
            // Both helpers are deliberately permissive — undefined / null /
            // missing visibility or scale fields are treated as "in range"
            // rather than excluded, because a brand-new layer can briefly
            // have those fields unset between when it's added and when
            // Esri's reactive system finishes initializing it.
            if (!effectivelyVisible(lyr)) return;
            if (!inScaleRange(lyr)) return;

            // Developer-controlled layer selection. If the dev configured an
            // explicit selection list in widget settings, only layers whose
            // selection key — OR the key of any ancestor in the layer tree —
            // appears in that list are eligible.
            //
            // Fast path: if any ancestor's key (or, for sublayers, the owning
            // MapImageLayer's key) is in `trustedGroupKeys`, the layer is
            // included immediately regardless of selectedKeys. This is the
            // "trust this group" feature — it makes new layers added to the
            // service / group at runtime appear automatically without any
            // settings change.
            //
            // Otherwise, the match below is intentionally permissive: it
            // tries the computed selection key, the raw layer id, and the
            // layer's title against the allowed set. Any match counts as a
            // hit. This rescues stale configs from before this code shipped
            // (which may have stored just leaf ids) AND configs that store
            // group ancestors (which catch newly-added group children).
            //
            // Default (no selection configured, mode === 'all', or an
            // empty selectedKeys list) = include every queryable layer.
            const sel = props.config?.whatsHereLayerSelection;
            const allowedKeys = Array.isArray(sel?.selectedKeys) ? sel!.selectedKeys! : [];
            const trustedKeys = Array.isArray((sel as any)?.trustedGroupKeys) ? (sel as any).trustedGroupKeys as string[] : [];
            const selectionInForce = !!sel && sel.mode === 'selected' && allowedKeys.length > 0;

            // Trust fast-path runs even when selectionInForce is false, on the
            // off-chance someone has trusted groups but mode === 'all'. In
            // that case the layer would have been included anyway, so this
            // is a no-op.
            const trustedSet = new Set(trustedKeys);
            const isInTrustedSubtree = (start: any): boolean => {
                if (trustedSet.size === 0) return false;
                let cur: any = start;
                let hops = 0;
                while (cur && hops < 30) {
                    // Check this node's selection key, its raw id, and title
                    // against the trusted set — any one of them counts.
                    const k = computeLayerSelectionKey(cur);
                    if (k && trustedSet.has(k)) return true;
                    const idStr = cur.id != null ? String(cur.id) : '';
                    if (idStr && trustedSet.has(idStr)) return true;
                    const title = cur.title || '';
                    if (title && trustedSet.has(title)) return true;
                    const next = cur.parent;
                    if (!next || next === cur) break;
                    const cls = String((next as any)?.declaredClass || '');
                    if (ROOT_CLASSES.has(cls)) break;
                    cur = next;
                    hops++;
                }
                return false;
            };

            if (selectionInForce) {
                // If the layer (or any ancestor) is trusted, skip all other
                // selection checks and include immediately.
                if (isInTrustedSubtree(lyr)) {
                    // matched — fall through to URL dedupe below
                } else {
                    const allowedSet = new Set(allowedKeys);

                    // Extract the set of MapImageLayer / TileLayer service ids
                    // referenced by composite "<serviceId>::sub::<subId>" keys.
                    // If a sublayer's owning service id matches one of these,
                    // we accept it regardless of which specific sub-id pairs
                    // are in the saved selection. This is what lets sublayers
                    // added to a map service later be auto-included.
                    const allowedServiceIds = new Set<string>();
                    for (const k of allowedKeys) {
                        const idx = k.indexOf('::sub::');
                        if (idx > 0) allowedServiceIds.add(k.substring(0, idx));
                    }

                    const matchesAllowed = (node: any): boolean => {
                        if (!node) return false;
                        const k = computeLayerSelectionKey(node);
                        if (k && allowedSet.has(k)) return true;
                        const idStr = node.id != null ? String(node.id) : '';
                        if (idStr && allowedSet.has(idStr)) return true;
                        const title = node.title || '';
                        if (title && allowedSet.has(title)) return true;
                        return false;
                    };

                    // First-pass match: walk own + ancestor keys.
                    let matched = false;
                    let cur: any = lyr;
                    let hops = 0;
                    while (cur && hops < 30) {
                        if (matchesAllowed(cur)) { matched = true; break; }
                        const next = cur.parent;
                        if (!next || next === cur) break;
                        const cls = String((next as any)?.declaredClass || '');
                        if (ROOT_CLASSES.has(cls)) break;
                        cur = next;
                        hops++;
                    }

                    // Service-prefix fallback: if this layer is a sublayer of a
                    // MapImageLayer / TileLayer and that service's id appears as
                    // the prefix of any "<serviceId>::sub::<subId>" key in the
                    // saved selection, treat it as matched. This catches sublayers
                    // added to a service after the selection was saved.
                    if (!matched && allowedServiceIds.size > 0) {
                        let owner: any = lyr.parent;
                        let oHops = 0;
                        while (owner && oHops < 30) {
                            const oCls = String(owner?.declaredClass || '');
                            const oType = String(owner?.type || '');
                            const isService =
                                oType === 'map-image' || oType === 'tile' || oType === 'imagery-tile' ||
                                oCls.indexOf('MapImageLayer') >= 0 || oCls.indexOf('TileLayer') >= 0;
                            if (isService) {
                                const ownerIdStr = owner.id != null ? String(owner.id) : '';
                                if (ownerIdStr && allowedServiceIds.has(ownerIdStr)) {
                                    matched = true;
                                }
                                break;
                            }
                            const nxt = owner.parent;
                            if (!nxt || nxt === owner) break;
                            owner = nxt;
                            oHops++;
                        }
                    }

                    if (!matched) return;
                }
            }

            // Derive a URL (used both for dedupe and for downstream metadata
            // lookups). FeatureLayers expose `url` directly; Sublayers of a
            // MapImageLayer derive their URL from parent.url + id.
            let url: string = lyr.url || '';
            if (!url && lyr.id !== undefined && lyr.parent?.url) {
                url = `${String(lyr.parent.url).replace(/\/+$/, '')}/${lyr.id}`;
            }

            const key = (url || `${lyr.declaredClass || 'layer'}::${lyr.uid || lyr.id || fallbackName}`).toLowerCase();
            if (seenKeys.has(key)) return;
            seenKeys.add(key);

            entries.push({
                name: lyr.title || fallbackName || 'Layer',
                mapLayer: lyr,
                layerUrl: url,
                popupEnabled: lyr.popupEnabled !== false
            });
        };

        // Recursive walk: handles GroupLayers (via `.layers`), MapImageLayer
        // sublayers (via `.sublayers` / `.allSublayers`), and nested group
        // sublayers inside a map service.
        const visit = (lyr: any, depth: number) => {
            if (!lyr || depth > 20) return;

            // Feature-like layers: query them directly.
            tryAdd(lyr, lyr.title || `Layer ${lyr.id ?? ''}`);

            // Descend into GroupLayer children. Try every collection name
            // and access mode — `.items` works for already-materialized
            // Collections but is undefined on JSAPI Collections that haven't
            // been touched yet; `.toArray()` always returns the current
            // contents. Falling back across both shapes catches every case.
            const childCollections = [
                lyr?.layers?.toArray?.(),
                lyr?.layers?.items,
                lyr?.sublayers?.toArray?.(),
                lyr?.sublayers?.items
            ];
            for (const col of childCollections) {
                if (Array.isArray(col)) {
                    for (const child of col) visit(child, depth + 1);
                }
            }

            // Descend into map service sublayers (MapImageLayer, TileLayer,
            // ImageryLayer). Prefer `allSublayers` when available — it
            // pre-flattens any group sublayers within the service. We also
            // call `.toArray()` because some Esri Collections lazy-build
            // `.items` and return `undefined` before first access.
            const subs = lyr?.allSublayers?.toArray?.()
                || lyr?.allSublayers?.items
                || lyr?.sublayers?.toArray?.()
                || lyr?.sublayers?.items
                || [];
            if (Array.isArray(subs)) {
                for (const sub of subs) {
                    // Skip group sublayers — they aren't queryable themselves,
                    // but their children are reachable through this same loop
                    // because allSublayers is flat.
                    tryAdd(sub, sub.title || `Sublayer ${sub.id ?? ''}`);
                }
            }
        };

        // Top-level walk. We feed BOTH the flat `allLayers` collection AND
        // the raw `layers` collection into the visitor. `allLayers` is
        // supposed to be reactive and pre-flattened across all nested
        // GroupLayers, but in practice it occasionally lags behind layers
        // added via direct `groupLayer.layers.add(...)` calls. Visiting both
        // and relying on `seenKeys` dedupe inside tryAdd means a layer
        // that's missing from one collection but present in the other still
        // gets caught.
        const allLayersCol = (mv.map as any).allLayers?.items
            || (mv.map as any).allLayers?.toArray?.()
            || [];
        const topLayersCol = (mv.map as any).layers?.items
            || (mv.map as any).layers?.toArray?.()
            || [];

        for (const layer of allLayersCol) visit(layer, 0);
        for (const layer of topLayersCol) visit(layer, 0);

        return entries;
    }, []);

    // Query a single discovered layer entry at the click point using the
    // layer's native queryFeatures() — works uniformly across FeatureLayer,
    // MapImageLayer sublayer, GeoJSONLayer, CSVLayer, WFSLayer, etc., and
    // automatically reprojects geometry as needed.
    const queryLayerEntryAtPoint = React.useCallback(async (
        entry: { name: string; mapLayer: any; layerUrl: string; popupEnabled: boolean },
        mapPoint: __esri.Point
    ): Promise<{ layerName: string; features: any[]; layerUrl: string; popupEnabled: boolean; mapLayer: any }> => {
        const whatsHereSettings = props.config?.whatsHereSettings || {};
        const maxResults = whatsHereSettings.maxResults || 10;

        const result = {
            layerName: entry.name,
            features: [] as any[],
            layerUrl: entry.layerUrl,
            popupEnabled: entry.popupEnabled,
            mapLayer: entry.mapLayer
        };

        try {
            // Some layers need to be "loaded" before queryFeatures will work
            // (especially sublayers fetched on-demand from a MapServer).
            if (typeof entry.mapLayer.load === 'function' && entry.mapLayer.loadStatus !== 'loaded') {
                try { await entry.mapLayer.load(); } catch (_) { /* keep going */ }
            }

            const q: any = {
                geometry: mapPoint,
                spatialRelationship: 'intersects',
                outFields: ['*'],
                // Always return geometry: needed for the in-popup highlight
                // and the Zoom-to button. Cost is tiny on a per-feature basis
                // and well worth the UX. The legacy includeGeometry flag in
                // whatsHereSettings is ignored here for that reason.
                returnGeometry: true,
                num: maxResults
            };
            // Determine click tolerance. Configured searchRadius always wins.
            // Otherwise: zero for polygons (a click inside intersects natively),
            // and a screen-pixel-relative buffer for points and polylines —
            // those have effectively no clickable area at typical zoom levels
            // and are otherwise nearly impossible to hit precisely.
            //
            // The buffer is computed from the view's current resolution
            // (map units per pixel) so a missed click within ~12px of a point
            // or line still selects it, regardless of zoom level. A small
            // fixed fallback in meters covers the edge case where the view's
            // resolution isn't yet available.
            const POINT_LINE_PIXEL_TOLERANCE = 12;
            const FALLBACK_TOLERANCE_METERS = 10;
            const layerGeomType = String(entry.mapLayer?.geometryType || '').toLowerCase();
            const isPointLayer = layerGeomType.indexOf('point') >= 0;       // 'point', 'multipoint', 'esriGeometryPoint', etc.
            const isLineLayer = layerGeomType.indexOf('line') >= 0;         // 'polyline', 'esriGeometryPolyline'
            const needsDefaultTolerance = isPointLayer || isLineLayer;

            if (whatsHereSettings.searchRadius && whatsHereSettings.searchRadius > 0) {
                q.distance = whatsHereSettings.searchRadius;
                q.units = 'meters';
            } else if (needsDefaultTolerance) {
                const mv = mapViewRef.current;
                const resolution = mv?.resolution || 0; // map units / pixel
                // For Web Mercator (the overwhelming default) resolution is
                // already in meters; for other spatial references Esri's
                // query API auto-converts when we declare units='meters'.
                const dynamicMeters = resolution > 0
                    ? resolution * POINT_LINE_PIXEL_TOLERANCE
                    : FALLBACK_TOLERANCE_METERS;
                q.distance = dynamicMeters;
                q.units = 'meters';
            }
            if (whatsHereSettings.orderBy) {
                q.orderByFields = [whatsHereSettings.orderBy];
            }

            const fs = await entry.mapLayer.queryFeatures(q);
            result.features = (fs?.features || []).map((g: any) => ({
                // Normalize to a plain object so downstream code that does
                // Object.entries(attributes) works regardless of whether the
                // layer returned esri/Graphic instances or POJOs. We DO keep
                // the geometry reference — Graphic.geometry is already a real
                // Esri Geometry instance, so highlighting and zoom-to can
                // pass it straight to new Graphic({geometry, symbol}) and
                // view.goTo(geometry).
                attributes: g?.attributes || {},
                geometry: g?.geometry || null
            }));
        } catch (_e) {
            // Some sublayers (raster, etc.) advertise queryFeatures but fail
            // when actually called — swallow and leave features = [].
        }

        return result;
    }, [props.config?.whatsHereSettings]);

    // ─── What's Here: master/detail popup helpers ───────────────────────────
    // The original implementation rendered every queried feature inline in a
    // single popup. This enhancement instead shows a clickable list of features
    // grouped by layer; clicking a feature opens a detail view (only if the
    // underlying map layer has popups enabled) with a "Back" button that
    // returns to the master list.

    // Escape values for safe interpolation into popup HTML.
    const escapePopupHtml = React.useCallback((s: any): string => {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }, []);

    // Find the live map layer that corresponds to a configured FeatureLayerConfig
    // URL. Handles both standalone FeatureLayers and sublayers inside a
    // MapImageLayer. Returns null when no match is found.
    const findMapLayerByUrl = React.useCallback((layerUrl: string): any | null => {
        const mv = mapViewRef.current;
        if (!mv?.map || !layerUrl) return null;
        const normalize = (u: string) => (u || '').replace(/\/+$/, '').toLowerCase();
        const target = normalize(layerUrl);
        const all = (mv.map as any).allLayers?.items || [];

        for (const layer of all) {
            if (layer?.url && normalize(layer.url) === target) return layer;
            // MapImageLayer / TiledLayer with sublayers: each sublayer is a service layer (.../MapServer/<id>)
            const sublayers = (layer as any)?.sublayers?.items || (layer as any)?.allSublayers?.items || [];
            for (const sub of sublayers) {
                const subUrl = sub?.url ? sub.url : (layer?.url && sub?.id !== undefined ? `${layer.url.replace(/\/+$/, '')}/${sub.id}` : null);
                if (subUrl && normalize(subUrl) === target) return sub;
            }
        }
        return null;
    }, []);

    // Whether the live map layer corresponding to a configured URL has popups
    // enabled. When the layer cannot be found (e.g. it's not in the current
    // webmap) we default to true since the layer was deliberately configured
    // for "What's Here" — the user clearly wants its features inspectable.
    const isPopupEnabledForLayerUrl = React.useCallback((layerUrl: string): boolean => {
        const mapLayer = findMapLayerByUrl(layerUrl);
        if (!mapLayer) return true;
        // popupEnabled is the canonical flag. Some layer types (e.g. sublayers)
        // use the same name; both honored.
        if (mapLayer.popupEnabled === false) return false;
        return true;
    }, [findMapLayerByUrl]);

    // Pick a short, human-readable label for a feature row in the master list.
    // Strategy: prefer the layer's popupTemplate.title (with {field} substitution),
    // then well-known display fields, then the first non-system string value,
    // then the OBJECTID.
    const getFeatureRowLabel = React.useCallback((feature: any, layerUrl: string, mapLayerOverride?: any): string => {
        const attrs = feature?.attributes || {};
        const mapLayer = mapLayerOverride || findMapLayerByUrl(layerUrl);

        // popupTemplate.title with {field} substitution
        const tpl = mapLayer?.popupTemplate?.title;
        if (tpl && typeof tpl === 'string' && tpl.indexOf('{') !== -1) {
            const filled = tpl.replace(/\{([^}]+)\}/g, (_match: string, name: string) => {
                const key = name.trim();
                const v = attrs[key];
                return (v !== undefined && v !== null && v !== '') ? String(v) : '';
            }).trim();
            // Reject if substitution left nothing meaningful behind (e.g. just punctuation)
            if (filled && /[A-Za-z0-9]/.test(filled)) return filled;
        }

        // Preferred display field names
        const preferredKeys = [
            'NAME', 'Name', 'name',
            'FULLNAME', 'FullName', 'Fullname',
            'LABEL', 'Label',
            'TITLE', 'Title',
            'PARCEL', 'PARCEL_NUM', 'PARCEL_NO', 'PARCELNO', 'PARCEL_ID', 'PARCELID',
            'ADDRESS', 'Address', 'FULL_ADDRESS', 'SITE_ADDRESS',
            'BUSINESS_NAME', 'OWNER', 'OWNER_NAME',
            'DESCRIPTION', 'Description', 'DESC',
            'STREET', 'STREET_NAME'
        ];
        for (const k of preferredKeys) {
            const v = attrs[k];
            if (v !== undefined && v !== null && String(v).trim() !== '') return String(v);
        }

        // First non-system string value
        const systemFields = new Set(['OBJECTID', 'ObjectID', 'FID', 'SHAPE', 'Shape', 'GlobalID', 'GLOBALID']);
        for (const [k, v] of Object.entries(attrs)) {
            if (systemFields.has(k)) continue;
            if (typeof v === 'string' && v.trim() !== '') return v;
            if (typeof v === 'number' && !isNaN(v)) return String(v);
        }

        const oid = attrs.OBJECTID ?? attrs.ObjectID ?? attrs.FID;
        return oid !== undefined ? `Feature #${oid}` : 'Feature';
    }, [findMapLayerByUrl]);

    // Build the master ("What's Here?" landing) popup HTML: address banner plus
    // a clickable list grouped by layer. Features on layers with popupEnabled === false
    // render as non-clickable rows with a small "popups disabled" hint.
    const generateMasterWhatsHereContent = React.useCallback((
        addressText: string,
        results: Array<{ layerName: string; features: any[]; layerUrl: string; popupEnabled: boolean; mapLayer?: any }>
    ): string => {
        const uiSettings = props.config?.uiSettings || {};
        const showLayerNames = uiSettings.showLayerNames !== false;

        let content = `<div style="font-family: ${themeFont}; color: #323232; line-height: 1.4; font-size: 13px; padding: 4px 0;">`;

        if (addressText) {
            content += `
                <div style="display:flex;align-items:flex-start;margin-bottom:12px;padding:8px 0;border-bottom:2px solid #0079c1;">
                    <div style="font-weight:600;color:#0079c1;white-space:nowrap;flex-shrink:0;min-width:90px;font-size:13px;">Location:</div>
                    <div style="color:#323232;word-wrap:break-word;flex:1;margin-left:8px;font-size:13px;font-weight:500;">${escapePopupHtml(addressText)}</div>
                </div>
            `;
        }

        const populatedResults = results.filter(r => r.features.length > 0);
        const totalFeatures = populatedResults.reduce((acc, r) => acc + r.features.length, 0);

        if (totalFeatures === 0) {
            if (!addressText) {
                content += `<div style="color:#6e6e6e;font-style:italic;text-align:center;padding:20px;background-color:#f8f9fa;border-radius:4px;margin:10px 0;">No information found at this location.</div>`;
            } else {
                content += `<div style="color:#6e6e6e;font-style:italic;padding:10px 0;font-size:12px;">No features found at this location.</div>`;
            }
        } else {
            content += `<div style="font-size:12px;color:#6e6e6e;margin-bottom:10px;">Found <strong>${totalFeatures}</strong> feature${totalFeatures === 1 ? '' : 's'} across <strong>${populatedResults.length}</strong> layer${populatedResults.length === 1 ? '' : 's'}. Click an item to view details.</div>`;

            populatedResults.forEach(({ layerName, features, layerUrl, popupEnabled, mapLayer }, layerIndex) => {
                // Resolve the original result index so click handlers can look up
                // the right entry (populatedResults may be shorter than results).
                const originalIndex = results.indexOf(populatedResults[layerIndex]);

                if (showLayerNames) {
                    content += `
                        <div style="font-weight:600;color:#323232;margin:${layerIndex > 0 ? '14px' : '0px'} 0 6px 0;padding-bottom:4px;border-bottom:2px solid #0079c1;font-size:14px;text-transform:uppercase;letter-spacing:0.5px;">
                            ${escapePopupHtml(layerName)} <span style="font-weight:400;text-transform:none;letter-spacing:0;color:#6e6e6e;font-size:12px;">(${features.length})</span>
                        </div>
                    `;
                }

                features.forEach((feature, featureIndex) => {
                    const label = getFeatureRowLabel(feature, layerUrl, mapLayer);
                    const safeLabel = escapePopupHtml(label);

                    if (popupEnabled) {
                        // Inline event handlers (onclick, etc.) are stripped by
                        // Esri's popup HTML sanitizer. Instead we mark each row
                        // with data-* attributes and CSS classes; openWhatsHerePopup
                        // attaches real DOM listeners after parsing this HTML.
                        content += `
                            <div class="rc-wh-row rc-wh-row--clickable"
                                 role="button" tabindex="0"
                                 data-rc-action="show-feature"
                                 data-rc-layer-idx="${originalIndex}"
                                 data-rc-feature-idx="${featureIndex}"
                                 title="View details">
                                <span class="rc-wh-row__label">${safeLabel}</span>
                                <span class="rc-wh-row__chevron">›</span>
                            </div>
                        `;
                    } else {
                        content += `
                            <div class="rc-wh-row rc-wh-row--disabled" title="Popups are disabled for this layer">
                                <span class="rc-wh-row__label">${safeLabel}</span>
                                <span class="rc-wh-row__hint">popups disabled</span>
                            </div>
                        `;
                    }
                });
            });
        }

        content += '</div>';
        return content;
    }, [props.config?.uiSettings, themeFont, escapePopupHtml, getFeatureRowLabel]);

    // Build the detail view: Back button + layer header + attribute list for
    // one feature. Reuses the existing getFieldDisplayName / formatFieldValue
    // helpers so formatting matches the rest of the widget.
    const generateFeatureDetailContent = React.useCallback((
        layerName: string,
        layerUrl: string,
        feature: any,
        mapLayerOverride?: any,
        overrideBodyHtml?: string,
        overrideHeaderText?: string
    ): string => {
        const uiSettings = props.config?.uiSettings || {};
        const showFieldAliases = uiSettings.showFieldAliases !== false;
        const attributes = feature?.attributes || {};
        const mapLayer = mapLayerOverride || findMapLayerByUrl(layerUrl);

        let content = `<div style="font-family: ${themeFont}; color: #323232; line-height: 1.4; font-size: 13px; padding: 4px 0;">`;

        // Back button + layer name header + Zoom-to button. Inline event
        // handlers are stripped by Esri's popup sanitizer; wireDetailActions
        // attaches the listeners after parsing this HTML.
        const headerText = (overrideHeaderText && overrideHeaderText.trim()) || layerName;
        content += `
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;padding-bottom:10px;border-bottom:2px solid #0079c1;">
                <button type="button" class="rc-wh-back" data-rc-action="show-master" title="Back to What's Here list">
                    <span style="font-size:14px;line-height:1;">‹</span> Back
                </button>
                <div style="flex:1;min-width:0;font-weight:600;color:#323232;font-size:14px;text-transform:uppercase;letter-spacing:0.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapePopupHtml(headerText)}">${escapePopupHtml(headerText)}</div>
                <button type="button" class="rc-wh-zoom-to" data-rc-action="zoom-to-feature" title="Zoom map to this feature">
                    <span style="font-size:13px;line-height:1;" aria-hidden="true">⊕</span> Zoom to
                </button>
            </div>
        `;

        // When a dev-override body has been pre-rendered (Arcade evaluated and
        // placeholders substituted), use it verbatim instead of trying to
        // render the layer's own popupTemplate. The body is trusted HTML
        // authored by the developer in widget settings, so we don't escape it.
        if (typeof overrideBodyHtml === 'string') {
            content += `<div class="rc-wh-override-body">${overrideBodyHtml}</div>`;
            content += '</div>';
            return content;
        }

        const systemFields = new Set(['OBJECTID', 'ObjectID', 'FID', 'SHAPE', 'Shape', 'GlobalID', 'GLOBALID']);

        // Build a lowercased index over the attribute keys so {field} lookups
        // in popup templates work case-insensitively (Esri service-author casing
        // often differs from popupTemplate-author casing).
        const attrKeyByLower: Record<string, string> = {};
        for (const k of Object.keys(attributes)) attrKeyByLower[k.toLowerCase()] = k;

        const getAttr = (name: string): any => {
            if (name in attributes) return attributes[name];
            const lo = name.toLowerCase();
            const realKey = attrKeyByLower[lo];
            return realKey !== undefined ? attributes[realKey] : undefined;
        };

        // Resolve an alias for a given field name, preferring (in order):
        //   1. an explicit popupTemplate fieldInfo.label
        //   2. the live layer's fields[].alias
        //   3. the cached state.layerFieldMetadata (for configured layers)
        //   4. common-aliases fallback via getFieldDisplayName
        const resolveAlias = (fieldName: string, explicitLabel?: string): string => {
            if (explicitLabel && explicitLabel !== fieldName) return explicitLabel;
            if (showFieldAliases && mapLayer?.fields) {
                const f = (mapLayer.fields as any[]).find?.((x: any) => x?.name?.toLowerCase() === fieldName.toLowerCase());
                if (f?.alias && f.alias !== fieldName) return f.alias;
            }
            return getFieldDisplayName(fieldName, layerUrl, showFieldAliases);
        };

        // Substitute {field} placeholders in popup-template strings. Field
        // values are HTML-escaped (matches Esri's standard convention).
        // {expression/...} placeholders are emptied here — webmap-authored
        // Arcade isn't evaluated by this widget; devs can configure
        // expressionInfos via the Popup Overrides (Arcade) settings instead.
        const substituteTemplateString = (tpl: string): string => {
            if (!tpl) return '';
            return tpl.replace(/\{([^{}]+)\}/g, (_full, raw: string) => {
                const ph = raw.trim();
                if (/^expression\//i.test(ph)) return '';
                const fieldName = ph.split(':')[0].trim();
                const v = getAttr(fieldName);
                if (v === null || v === undefined) return '';
                return escapePopupHtml(String(v));
            });
        };

        // Render one fields-content row table from a fieldInfos array.
        const renderFieldRows = (fieldInfos: any[]): string => {
            const rows = fieldInfos
                .filter((fi: any) => fi && fi.fieldName && fi.visible !== false && !systemFields.has(fi.fieldName))
                .map((fi: any) => {
                    const value = getAttr(fi.fieldName);
                    if (value === null || value === undefined || value === '') return null;
                    const label = resolveAlias(fi.fieldName, fi.label);
                    const formatted = formatFieldValue(value, fi.fieldName);
                    return `
                        <div style="display:flex;align-items:flex-start;margin-bottom:6px;padding:2px 0;min-height:20px;">
                            <div style="font-weight:600;color:#0079c1;white-space:nowrap;flex-shrink:0;min-width:120px;font-size:13px;line-height:1.4;">${escapePopupHtml(label)}:</div>
                            <div style="color:#323232;word-wrap:break-word;flex:1;margin-left:8px;font-size:13px;line-height:1.4;">${escapePopupHtml(formatted)}</div>
                        </div>
                    `;
                })
                .filter((r): r is string => r !== null);
            return rows.join('');
        };

        // Render every non-system attribute as a label/value row — used as
        // the ultimate fallback when neither popupTemplate.content nor
        // popupTemplate.fieldInfos yields anything.
        const renderAllAttributes = (): string => {
            const entries = Object.entries(attributes).filter(([name, v]) => {
                if (systemFields.has(name)) return false;
                return v !== null && v !== undefined && v !== '';
            });
            if (entries.length === 0) return '';
            return entries.map(([name, value]) => {
                const label = resolveAlias(name);
                const formatted = formatFieldValue(value, name);
                return `
                    <div style="display:flex;align-items:flex-start;margin-bottom:6px;padding:2px 0;min-height:20px;">
                        <div style="font-weight:600;color:#0079c1;white-space:nowrap;flex-shrink:0;min-width:120px;font-size:13px;line-height:1.4;">${escapePopupHtml(label)}:</div>
                        <div style="color:#323232;word-wrap:break-word;flex:1;margin-left:8px;font-size:13px;line-height:1.4;">${escapePopupHtml(formatted)}</div>
                    </div>
                `;
            }).join('');
        };

        // Render the layer's own popupTemplate.content if it's a shape we
        // understand. Returns '' if nothing renderable was found so we can
        // fall through to the final all-attributes fallback.
        const renderPopupTemplateBody = (): string => {
            const tpl = mapLayer?.popupTemplate;
            if (!tpl) return '';

            const tplContent = tpl.content;
            // String content — substitute {field} placeholders and render
            // as HTML.
            if (typeof tplContent === 'string') {
                const filled = substituteTemplateString(tplContent);
                return filled.trim() ? filled : '';
            }

            // Array content — webmap-authored popups commonly use an array of
            // content elements (TextContent with `text`, FieldsContent with
            // `fieldInfos`, etc.). Render each known type.
            if (Array.isArray(tplContent)) {
                const parts: string[] = [];
                for (const el of tplContent) {
                    if (!el) continue;
                    const elType = String(el.type || '').toLowerCase();
                    if (elType === 'text' && typeof el.text === 'string') {
                        const filled = substituteTemplateString(el.text);
                        if (filled.trim()) parts.push(`<div class="rc-wh-text">${filled}</div>`);
                    } else if (elType === 'fields' && Array.isArray(el.fieldInfos) && el.fieldInfos.length > 0) {
                        const rows = renderFieldRows(el.fieldInfos);
                        if (rows.trim()) parts.push(rows);
                    } else if (elType === 'media') {
                        // Lightweight support: list out media titles only —
                        // chart/image rendering is beyond this widget's scope.
                        const items: any[] = Array.isArray(el.mediaInfos) ? el.mediaInfos : [];
                        for (const mi of items) {
                            if (mi?.title) parts.push(`<div style="font-style:italic;color:#6e6e6e;font-size:12px;">${escapePopupHtml(mi.title)}</div>`);
                        }
                    }
                    // Unsupported types (attachments, custom) are skipped
                    // silently — the all-attributes fallback below will fire
                    // if nothing else rendered.
                }
                return parts.join('');
            }

            // Function content (sync/async) — we'd need to await it; skipped
            // here in favor of fieldInfos / all-attributes fallback.
            return '';
        };

        // Render order:
        //   1. popupTemplate.content (string/array) — what the webmap author
        //      actually configured for clicks
        //   2. popupTemplate.fieldInfos at top level (older popup style)
        //   3. Every non-system attribute (last-resort fallback)
        let body = renderPopupTemplateBody();

        if (!body.trim()) {
            const topFieldInfos: any[] = mapLayer?.popupTemplate?.fieldInfos || [];
            if (Array.isArray(topFieldInfos) && topFieldInfos.length > 0) {
                body = renderFieldRows(topFieldInfos);
            }
        }

        if (!body.trim()) {
            body = renderAllAttributes();
        }

        if (!body.trim()) {
            content += `<div style="color:#6e6e6e;font-style:italic;text-align:center;padding:20px;">No attributes to display for this feature.</div>`;
        } else {
            content += body;
        }

        content += '</div>';
        return content;
    }, [props.config?.uiSettings, themeFont, escapePopupHtml, findMapLayerByUrl, getFieldDisplayName, formatFieldValue]);

    // ─── Popup override (Arcade) helpers ────────────────────────────────────
    // A developer-supplied override is a {matchUrl, matchTitle, content,
    // expressionInfos} record in config.popupOverrides. At click time we
    // pick the first enabled override whose match fields are substrings of
    // the live layer's URL/title, evaluate its Arcade expressions, then
    // substitute placeholders in the content template.

    // Find the first enabled override whose match fields are substrings of
    // the layer being inspected. If both matchUrl and matchTitle are set,
    // both must match; if only one is set, only that one must match.
    const findMatchingPopupOverride = React.useCallback((
        layerName: string,
        layerUrl: string
    ): PopupOverrideConfig | null => {
        const overrides = props.config?.popupOverrides;
        if (!overrides || overrides.length === 0) return null;
        const urlLower = (layerUrl || '').toLowerCase();
        const titleLower = (layerName || '').toLowerCase();

        // Sort by specificity so more-specific overrides win over global
        // ones. Specificity = number of non-empty matchers (0–2). Stable
        // within the same score so the developer's authored order still
        // breaks ties. Both matchers empty means "apply to every layer" —
        // a useful default but it has to lose to any override that names
        // a URL or title.
        const scored = overrides
            .map((o, i) => {
                const u = (o?.matchUrl || '').trim();
                const t = (o?.matchTitle || '').trim();
                let score = 0;
                if (u) score++;
                if (t) score++;
                return { o, i, score, u: u.toLowerCase(), t: t.toLowerCase() };
            })
            .sort((a, b) => (b.score - a.score) || (a.i - b.i));

        for (const { o, u, t } of scored) {
            if (!o || o.enabled === false) continue;
            if (u && !urlLower.includes(u)) continue;
            if (t && !titleLower.includes(t)) continue;
            return o as PopupOverrideConfig;
        }
        return null;
    }, [props.config?.popupOverrides]);

    // Evaluate each Arcade expressionInfo against the feature, returning a
    // map of name → string value. Errors are caught per-expression and
    // surfaced as "[Arcade error: …]" so the developer can see what failed.
    const evaluateOverrideExpressions = React.useCallback(async (
        expressionInfos: ArcadeExpressionInfo[] | undefined,
        feature: any,
        mapLayer: any
    ): Promise<Record<string, string>> => {
        const out: Record<string, string> = {};
        if (!Array.isArray(expressionInfos) || expressionInfos.length === 0) return out;

        let arcade: any;
        try {
            arcade = await loadArcadeModule();
        } catch (err) {
            for (const e of expressionInfos) {
                if (e?.name) out[e.name] = '[Arcade module unavailable]';
            }
            return out;
        }

        // Build a feature-graphic-like context. Arcade's executor accepts
        // plain objects with `attributes` and (optionally) `geometry`.
        const featureCtx = {
            attributes: feature?.attributes || {},
            geometry: feature?.geometry || null,
            layer: mapLayer || null
        };

        const profile = {
            variables: [
                { name: '$feature', type: 'feature' as const }
            ]
        };

        // Coerce an Arcade return value to a string suitable for substitution
        // into the {expression/<name>} placeholder. Arcade authors commonly
        // return one of several shapes — handle each rather than blindly
        // String()-ing everything (which produces "[object Object]" for any
        // dictionary return).
        const coerceArcadeResult = (value: any): string => {
            if (value === null || value === undefined) return '';
            if (typeof value === 'string') return value;
            if (typeof value === 'number' || typeof value === 'boolean') return String(value);
            if (value instanceof Date) return value.toLocaleString();
            if (Array.isArray(value)) {
                // Arrays of content elements — render each child recursively
                // and concatenate. Useful when an Arcade author returns
                // multiple TextContent blocks.
                return value.map(v => coerceArcadeResult(v)).filter(Boolean).join('');
            }
            if (typeof value === 'object') {
                // Esri popup content-element shapes returned by Arcade. The
                // most common is TextContent: { type: 'text', text: '<html>' }
                // — which is what devs return when they're building up HTML
                // string content inside the Arcade expression itself.
                const t = String(value.type || '').toLowerCase();
                if (t === 'text' && typeof value.text === 'string') {
                    return value.text;
                }
                // FieldsContent — without the live feature attrs here we
                // can't substitute values, but we can list the field names
                // so the dev at least sees something useful.
                if (t === 'fields' && Array.isArray(value.fieldInfos)) {
                    return value.fieldInfos
                        .map((fi: any) => fi?.fieldName)
                        .filter(Boolean)
                        .join(', ');
                }
                // Last-resort: stringify so the dev can see the structure
                // and fix their expression, rather than the opaque
                // "[object Object]".
                try { return JSON.stringify(value); } catch (_) { return '[unsupported Arcade return type]'; }
            }
            return String(value);
        };

        for (const info of expressionInfos) {
            if (!info?.name || !info?.expression) continue;
            try {
                const executor = await arcade.createArcadeExecutor(info.expression, profile);
                const value = await executor.executeAsync({ $feature: featureCtx });
                out[info.name] = coerceArcadeResult(value);
            } catch (err) {
                const msg = (err && (err as any).message) ? (err as any).message : 'unknown';
                out[info.name] = `[Arcade error: ${msg}]`;
            }
        }
        return out;
    }, []);

    // Substitute {field} and {expression/<name>} placeholders in the content
    // template. Field values are HTML-escaped; Arcade results are inserted
    // verbatim (so devs can return HTML when they want to). This mirrors
    // Esri's standard popup-content behavior.
    const substituteOverrideTemplate = React.useCallback((
        template: string,
        attributes: Record<string, any>,
        expressionResults: Record<string, string>
    ): string => {
        if (!template) return '';

        // Pre-build lower-cased lookups for case-insensitive matching.
        const attrKeyByLower: Record<string, string> = {};
        for (const k of Object.keys(attributes || {})) attrKeyByLower[k.toLowerCase()] = k;
        const exprKeyByLower: Record<string, string> = {};
        for (const k of Object.keys(expressionResults || {})) exprKeyByLower[k.toLowerCase()] = k;

        return template.replace(/\{([^{}]+)\}/g, (_full, raw: string) => {
            const placeholder = raw.trim();
            const exprMatch = /^expression\/(.+)$/i.exec(placeholder);
            if (exprMatch) {
                const exprName = exprMatch[1].trim().toLowerCase();
                const realKey = exprKeyByLower[exprName];
                return realKey ? expressionResults[realKey] : '';
            }
            // Strip optional format spec like {field:DateString} — we don't
            // implement format options here, just take the field name.
            const fieldName = placeholder.split(':')[0].trim().toLowerCase();
            const realKey = attrKeyByLower[fieldName];
            if (!realKey) return '';
            const val = attributes[realKey];
            if (val === null || val === undefined) return '';
            return escapePopupHtml(String(val));
        });
    }, [escapePopupHtml]);

    // Orchestrator: opens the "What's Here" popup, wires the master/detail
    // navigation handlers onto window so onclick attributes in the popup HTML
    // can call back into React-managed state.
    const openWhatsHerePopup = React.useCallback((
        mapPoint: __esri.Point,
        addressText: string,
        rawResults: Array<{ layerName: string; features: any[]; layerUrl: string; popupEnabled?: boolean; mapLayer?: any }>
    ) => {
        const mapView = mapViewRef.current;
        if (!mapView) return;

        // Each result already carries popupEnabled when it came from
        // auto-discovery. For results coming from the legacy URL-based path
        // (no mapLayer), fall back to looking up the live layer by URL.
        const results = rawResults.map(r => ({
            ...r,
            popupEnabled: typeof r.popupEnabled === 'boolean'
                ? r.popupEnabled
                : isPopupEnabledForLayerUrl(r.layerUrl)
        }));

        whatsHereSessionRef.current = { mapPoint, addressText, results };

        const popupMaxHeight = props.config?.uiSettings?.popupMaxHeight || 400;

        // ─── Feature highlight & zoom helpers ──────────────────────────────
        // These live inside openWhatsHerePopup so they close over the current
        // mapView reference. They use a component-level ref so renderMaster /
        // renderFeature / the popup-close watcher can share the same handle.

        const clearHighlight = () => {
            const g = whatsHereHighlightRef.current;
            if (!g) return;
            try { (mapView as any).graphics.remove(g); } catch (err) {
                console.warn('[rightclick] Could not remove highlight graphic:', err);
            }
            whatsHereHighlightRef.current = null;
        };

        const highlightFeature = (feature: any) => {
            clearHighlight();
            const geom = feature?.geometry;
            if (!geom || !geom.type) {
                console.warn('[rightclick] No geometry available on feature — highlight skipped. Check that returnGeometry is enabled in the query.');
                return;
            }

            // Read developer-configurable highlight style from settings.
            // Defaults: 2px cyan outline, no fill — Esri's standard
            // selection-symbol colour.
            const hi: WhatsHereHighlightConfig = (props.config?.whatsHereHighlight as any) || {};
            const hexToRgb = (hex: string): [number, number, number] => {
                const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || '').trim());
                if (!m) return [0, 255, 255]; // fallback: Esri default cyan
                const v = parseInt(m[1], 16);
                return [(v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff];
            };
            const fillEnabled = hi.fillEnabled === true;
            const fillRgb = hexToRgb(hi.fillColor || '#00FFFF');
            const outlineRgb = hexToRgb(hi.outlineColor || '#00FFFF');
            const outlineWidth = typeof hi.outlineWidth === 'number' && hi.outlineWidth > 0
                ? hi.outlineWidth
                : 2;
            // [0,0,0,0] is fully transparent; Esri renders it as no fill but
            // still requires a `color` property on simple-fill / simple-marker.
            const transparent: [number, number, number, number] = [0, 0, 0, 0];

            let symbol: any = null;
            const t = String(geom.type).toLowerCase();
            if (t === 'polygon' || t === 'extent') {
                symbol = {
                    type: 'simple-fill',
                    color: fillEnabled ? [...fillRgb, 0.35] : transparent,
                    outline: { color: [...outlineRgb, 1], width: outlineWidth }
                };
            } else if (t === 'polyline') {
                // Polylines have no fill — the outline color/width drive the
                // entire stroke. Bump the min width to 2 so the line is
                // visible regardless of configured outline width.
                symbol = {
                    type: 'simple-line',
                    color: [...outlineRgb, 1],
                    width: Math.max(outlineWidth, 2)
                };
            } else if (t === 'point' || t === 'multipoint') {
                symbol = {
                    type: 'simple-marker',
                    style: 'circle',
                    color: fillEnabled ? [...fillRgb, 0.85] : transparent,
                    outline: { color: [...outlineRgb, 1], width: Math.max(outlineWidth, 1.5) },
                    size: 14
                };
            }
            if (!symbol) {
                console.warn('[rightclick] Unsupported geometry type for highlight:', geom.type);
                return;
            }
            try {
                const g = new Graphic({ geometry: geom, symbol });
                (mapView as any).graphics.add(g);
                whatsHereHighlightRef.current = g;
            } catch (err) {
                console.warn('[rightclick] Could not add highlight graphic:', err);
            }
        };

        const zoomToFeature = (feature: any) => {
            const geom = feature?.geometry;
            if (!geom) {
                console.warn('[rightclick] No geometry available on feature — zoom-to skipped. Check that returnGeometry is enabled in the query.');
                return;
            }
            const t = String(geom.type || '').toLowerCase();
            const opts = { animate: true, duration: 500 };
            try {
                if (t === 'point') {
                    // A point has no extent — use it directly as the target,
                    // with a sensible zoom. Don't pull the user back out if
                    // they were already deeper than 18.
                    const targetZoom = Math.max((mapView as any).zoom || 0, 18);
                    (mapView as any).goTo({ target: geom, zoom: targetZoom }, opts);
                    return;
                }

                const ext: any = (geom as any).extent;
                if (!ext || !ext.center) {
                    // No extent (unusual for a non-point) — let Esri figure
                    // it out from the geometry as a last resort.
                    (mapView as any).goTo(geom, opts);
                    return;
                }

                // We need BOTH: pin the camera to the geometry's centre AND
                // zoom to fit the extent. Passing `target: geom` together
                // with `center: ext.center` to goTo gives centring but
                // *preserves the current scale* — so the camera just pans.
                // Compute the target scale ourselves and feed
                // {center, scale} explicitly so the single animation does
                // both jobs.
                //
                // Algorithm (mirrors what goTo(extent) does internally,
                // minus the view-padding offset that was breaking centring):
                //   1. Pad the extent ~10% for visual breathing room.
                //   2. Convert padded extent dimensions → map units per
                //      pixel (resolution) using the view's pixel width/height.
                //   3. Use the view's current scale/resolution ratio to
                //      convert that target resolution into a scale value
                //      in the same units the view uses.
                const padFactor = 1.1;
                const effWidth = Math.max((ext.width || 0) * padFactor, 0);
                const effHeight = Math.max((ext.height || 0) * padFactor, 0);

                const viewWidth = (mapView as any).width || 1;
                const viewHeight = (mapView as any).height || 1;
                const currentScale = (mapView as any).scale || 0;
                const currentResolution = (mapView as any).resolution || 0;

                if (effWidth <= 0 || effHeight <= 0) {
                    // Degenerate extent (collapsed to a point) — treat the
                    // extent's centre like a point and zoom in.
                    const z = Math.max((mapView as any).zoom || 0, 18);
                    (mapView as any).goTo({ target: ext.center, zoom: z }, opts);
                    return;
                }

                let targetScale = currentScale;
                if (currentResolution > 0 && currentScale > 0) {
                    const targetResolution = Math.max(
                        effWidth / viewWidth,
                        effHeight / viewHeight
                    );
                    targetScale = currentScale * (targetResolution / currentResolution);
                }

                (mapView as any).goTo(
                    { center: ext.center, scale: targetScale },
                    opts
                );
            } catch (err) {
                console.warn('[rightclick] view.goTo failed:', err);
            }
        };

        // Watch popup visibility so we clear the highlight when the user
        // dismisses the popup (X, click elsewhere, right-click again). Tear
        // down any previous watcher first so each session has exactly one.
        if (whatsHerePopupCloseHandleRef.current) {
            try { whatsHerePopupCloseHandleRef.current.remove(); } catch (_) { /* ignore */ }
            whatsHerePopupCloseHandleRef.current = null;
        }
        try {
            // reactiveUtils works on every JS API version EB ships (4.2x and
            // 5.x) and tolerates the popup being created lazily: the getter
            // re-reads mapView.popup on each evaluation.
            whatsHerePopupCloseHandleRef.current = reactiveUtils.watch(
                () => (mapView as any).popup?.visible,
                (visible: boolean) => {
                    if (!visible) {
                        clearHighlight();
                        if (whatsHerePopupCloseHandleRef.current) {
                            try { whatsHerePopupCloseHandleRef.current.remove(); } catch (_) { /* ignore */ }
                            whatsHerePopupCloseHandleRef.current = null;
                        }
                    }
                }
            );
        } catch (_) { /* watcher is best-effort; highlight clears on next open */ }

        // Build the scrolling container as a real DOM element. We pass an
        // HTMLElement (not a string) to popup.content because Esri's popup
        // sanitizes string content and strips inline event handlers — passing
        // a DOM node lets us attach real listeners that survive.
        //
        // The container is user-resizable via the native CSS `resize` corner
        // handle (bottom-right). A ResizeObserver captures the chosen size
        // into whatsHerePopupSizeRef so the size persists across master↔
        // detail navigation and across subsequent right-clicks.
        const buildPopupRoot = (innerHtml: string): HTMLDivElement => {
            const root = document.createElement('div');
            // Marker class so the injected stylesheet can target the
            // surrounding `.esri-popup__main-container` via `:has()`.
            root.className = 'rc-wh-popup-root';
            const saved = whatsHerePopupSizeRef.current;
            const hasSaved = saved.width != null && saved.height != null && saved.width > 0 && saved.height > 0;

            // The inner wrapper just fills its parent slot inside the popup's
            // `.esri-popup__content` flex cell and scrolls if its content
            // overflows. The *popup main container* is what's actually
            // resizable now — see setupChromeResize below. This is the only
            // way to grow the popup horizontally on top of Esri's flex
            // layout: the inner wrapper having `resize: both` only changes
            // its own width and the parent content area clips it.
            root.style.cssText = [
                'width:100%',
                'height:100%',
                'overflow:auto',
                'padding:4px',
                'box-sizing:border-box',
                'min-width:280px'
            ].join(';');
            root.innerHTML = innerHtml;

            // Carry the What's Here content styles WITH the content. In
            // EB 1.21 / JS API 5.x the popup renders content inside a
            // shadow root, where the document.head stylesheet (injected
            // on mount for EB 1.20 and earlier) cannot reach. A <style>
            // element inside the root applies in either world.
            const embeddedStyle = document.createElement('style');
            embeddedStyle.textContent = RC_WH_CONTENT_CSS;
            root.appendChild(embeddedStyle);

            // Belt and suspenders for EB 1.21: also apply the same look as
            // inline styles with JS hover handlers, so the content is
            // styled even if no stylesheet (document-level or embedded)
            // reaches it in the popup's shadow DOM.
            applyRcWhInlineStyles(root);

            // Wire up the popup chrome (the `.esri-popup__main-container`
            // ancestor) as the resizable element. Has to run after Esri has
            // inserted our wrapper into the DOM, which happens during
            // openPopup — a small timeout is enough.
            const setupChromeResize = () => {
                // Find the popup main container ancestor. Use the
                // shadow-crossing walker: in EB 1.21 the content sits in
                // a shadow root and parentElement dead-ends at the
                // boundary before reaching the popup chrome.
                let mainContainer: HTMLElement | null = null;
                let node: HTMLElement | null = rcParentAcrossShadow(root);
                let hops = 0;
                while (node && hops < 15) {
                    if (node.classList.contains('esri-popup__main-container')) {
                        mainContainer = node;
                        break;
                    }
                    node = rcParentAcrossShadow(node);
                    hops++;
                }

                if (mainContainer) {
                    // resize: both requires a non-visible overflow value on
                    // the resizable element; the popup main container is
                    // already overflow:hidden by default (for rounded corner
                    // clipping), but set it explicitly for safety.
                    mainContainer.style.setProperty('resize', 'both', 'important');
                    mainContainer.style.setProperty('overflow', 'hidden', 'important');
                    mainContainer.style.setProperty('min-width', '320px', 'important');
                    mainContainer.style.setProperty('min-height', '200px', 'important');
                    mainContainer.style.setProperty('max-width', '92vw', 'important');
                    mainContainer.style.setProperty('max-height', '88vh', 'important');
                    // Esri's stylesheet sets `width: 100%` on the main
                    // container so it fills its position-container parent
                    // (which has the 350px max-width cap). Switching to
                    // explicit pixel width lets the user grow it freely.
                    if (hasSaved) {
                        mainContainer.style.setProperty('width', `${saved.width}px`, 'important');
                        mainContainer.style.setProperty('height', `${saved.height}px`, 'important');
                    } else {
                        // First-open default: roughly the previous popup size.
                        mainContainer.style.setProperty('width', '460px', 'important');
                        mainContainer.style.setProperty('height', `${popupMaxHeight + 40}px`, 'important');
                    }

                    // Observe the chrome for resize → persist the new size
                    // into whatsHerePopupSizeRef. Skip the first fire (initial
                    // layout) so we don't pin to the default 460×N before the
                    // user has touched anything.
                    if (typeof ResizeObserver !== 'undefined' && !(mainContainer as any).__rcResizeObserver) {
                        let firstFire = true;
                        const ro = new ResizeObserver(() => {
                            if (firstFire) { firstFire = false; return; }
                            const w = (mainContainer as HTMLElement).offsetWidth;
                            const h = (mainContainer as HTMLElement).offsetHeight;
                            if (w > 0 && h > 0) {
                                whatsHerePopupSizeRef.current = { width: w, height: h };
                            }
                        });
                        try { ro.observe(mainContainer); } catch (_) { /* ignore */ }
                        (mainContainer as any).__rcResizeObserver = ro;
                    }
                }

                // Independent of the main-container resize, also lift the
                // size caps on every popup-chrome ancestor inline — covers
                // browsers without :has() support and cases where Esri sets
                // inline styles that beat stylesheet rules.
                let n2: HTMLElement | null = rcParentAcrossShadow(root);
                let h2 = 0;
                while (n2 && h2 < 15) {
                    const cls = n2.classList;
                    if (
                        cls.contains('esri-popup') ||
                        cls.contains('esri-popup__position-container')
                    ) {
                        n2.style.setProperty('max-width', '92vw', 'important');
                        n2.style.setProperty('max-height', '88vh', 'important');
                    }
                    if (cls.contains('esri-popup__content')) {
                        // Remove the content area's own height & width caps
                        // so it expands to fill its (now-resized) parent.
                        n2.style.setProperty('max-height', 'none', 'important');
                        n2.style.setProperty('max-width', 'none', 'important');
                    }
                    if (cls.contains('esri-popup')) break;
                    n2 = rcParentAcrossShadow(n2);
                    h2++;
                }
            };
            // Run twice — Esri sometimes resets inline styles on its own
            // first layout pass; a second tick after that wins.
            setTimeout(setupChromeResize, 0);
            setTimeout(setupChromeResize, 60);

            return root;
        };

        const renderMaster = () => {
            const session = whatsHereSessionRef.current;
            if (!session) return;
            // Returning to the master list clears the feature highlight —
            // the user is no longer looking at any one feature.
            clearHighlight();
            whatsHereMasterIsActiveRef.current = true;
            const root = buildPopupRoot(generateMasterWhatsHereContent(session.addressText, session.results));

            // Helper to resolve the feature for a given row's li/fi pair from
            // the current session. Returns null if the session has been torn
            // down or the indices no longer point at anything.
            const featureForRow = (li: number, fi: number): any | null => {
                const sess = whatsHereSessionRef.current;
                if (!sess) return null;
                const layerResult = sess.results[li];
                if (!layerResult) return null;
                return layerResult.features[fi] || null;
            };

            // Wire up click + keyboard listeners + hover-to-highlight on every
            // clickable row. Hover and focus produce the same map highlight
            // the detail view will use — same configured colour, same
            // Graphic — so the user can preview features by mousing over
            // the list before committing.
            const rows = root.querySelectorAll<HTMLElement>('[data-rc-action="show-feature"]');
            rows.forEach(el => {
                const li = parseInt(el.getAttribute('data-rc-layer-idx') || '-1', 10);
                const fi = parseInt(el.getAttribute('data-rc-feature-idx') || '-1', 10);
                if (li < 0 || fi < 0) return;

                el.addEventListener('click', (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    renderFeature(li, fi);
                });
                el.addEventListener('keydown', (ev: KeyboardEvent) => {
                    if (ev.key === 'Enter' || ev.key === ' ') {
                        ev.preventDefault();
                        ev.stopPropagation();
                        renderFeature(li, fi);
                    }
                });

                // Hover: highlight the feature on the map. The map graphic
                // uses the same configured highlight style as the detail
                // view, so the user gets a consistent visual.
                el.addEventListener('mouseenter', () => {
                    const f = featureForRow(li, fi);
                    if (f) highlightFeature(f);
                });
                el.addEventListener('mouseleave', () => {
                    // Critical guard: a click on this row will fire its click
                    // handler BEFORE mouseleave does, transitioning to the
                    // detail view which calls highlightFeature(f) itself.
                    // If we cleared unconditionally here, that detail-view
                    // highlight would be wiped a moment later. Only clear
                    // when we're still showing the master list.
                    if (whatsHereMasterIsActiveRef.current) clearHighlight();
                });

                // Keyboard parity: tabbing onto a row should produce the
                // same preview highlight a hover would.
                el.addEventListener('focus', () => {
                    const f = featureForRow(li, fi);
                    if (f) highlightFeature(f);
                });
                el.addEventListener('blur', () => {
                    if (whatsHereMasterIsActiveRef.current) clearHighlight();
                });
            });

            (mapView as any).openPopup({
                title: "📍 What's here?",
                content: root,
                location: session.mapPoint
            });
        };

        // Helper to wire up the Back button AND the Zoom-to button on a
        // freshly-built detail-view popup root. The Zoom-to handler needs a
        // reference to the current feature, which is why this can't live in
        // buildPopupRoot itself.
        const wireDetailActions = (root: HTMLElement, feature: any) => {
            const backBtns = root.querySelectorAll<HTMLElement>('[data-rc-action="show-master"]');
            backBtns.forEach(el => {
                el.addEventListener('click', (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    renderMaster();
                });
                el.addEventListener('keydown', (ev: KeyboardEvent) => {
                    if (ev.key === 'Enter' || ev.key === ' ') {
                        ev.preventDefault();
                        ev.stopPropagation();
                        renderMaster();
                    }
                });
            });

            const zoomBtns = root.querySelectorAll<HTMLElement>('[data-rc-action="zoom-to-feature"]');
            zoomBtns.forEach(el => {
                el.addEventListener('click', (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    zoomToFeature(feature);
                });
                el.addEventListener('keydown', (ev: KeyboardEvent) => {
                    if (ev.key === 'Enter' || ev.key === ' ') {
                        ev.preventDefault();
                        ev.stopPropagation();
                        zoomToFeature(feature);
                    }
                });
            });
        };

        // Token guarding against stale async renders. If the user clicks
        // another feature (or right-clicks again) before our Arcade promise
        // resolves, we don't want the old click's content to land on top.
        let featureRenderToken = 0;

        const renderFeature = (layerIndex: number, featureIndex: number) => {
            const session = whatsHereSessionRef.current;
            if (!session) return;
            const layerResult = session.results[layerIndex];
            if (!layerResult) return;
            const feature = layerResult.features[featureIndex];
            if (!feature) return;

            // Leaving the master list. Flip the flag so any pending
            // mouseleave/blur events from master rows don't wipe the
            // detail-view highlight we're about to set.
            whatsHereMasterIsActiveRef.current = false;

            // Highlight on the map as soon as the user picks a feature. This
            // also clears any previous highlight in case the user is hopping
            // between features without going through the master view.
            highlightFeature(feature);

            const myToken = ++featureRenderToken;
            const override = findMatchingPopupOverride(layerResult.layerName, layerResult.layerUrl);

            // Synchronous fast path: no override → just render the standard
            // attribute list immediately. (Most layers will hit this.)
            if (!override) {
                const root = buildPopupRoot(generateFeatureDetailContent(
                    layerResult.layerName,
                    layerResult.layerUrl,
                    feature,
                    layerResult.mapLayer
                ));
                wireDetailActions(root, feature);
                (mapView as any).openPopup({
                    title: "📍 What's here?",
                    content: root,
                    location: session.mapPoint
                });
                return;
            }

            // Override path: evaluate Arcade asynchronously, then render.
            // We open a transitional "Loading…" popup first so the user gets
            // immediate feedback that their click registered. The Back button
            // works in this transitional state too.
            const loadingRoot = buildPopupRoot(generateFeatureDetailContent(
                layerResult.layerName,
                layerResult.layerUrl,
                feature,
                layerResult.mapLayer,
                `<div style="color:#6e6e6e;padding:20px;text-align:center;font-style:italic;">Loading…</div>`,
                override.title || undefined
            ));
            wireDetailActions(loadingRoot, feature);
            (mapView as any).openPopup({
                title: "📍 What's here?",
                content: loadingRoot,
                location: session.mapPoint
            });

            (async () => {
                let body: string;
                try {
                    const exprResults = await evaluateOverrideExpressions(
                        override.expressionInfos,
                        feature,
                        layerResult.mapLayer
                    );
                    body = substituteOverrideTemplate(
                        override.content || '',
                        feature.attributes || {},
                        exprResults
                    );
                } catch (err) {
                    const msg = (err && (err as any).message) ? (err as any).message : 'unknown';
                    body = `<div style="color:#d32f2f;padding:12px;"><strong>Error rendering custom popup:</strong> ${escapePopupHtml(msg)}</div>`;
                }

                // Bail out if a newer renderFeature call has already started.
                if (myToken !== featureRenderToken) return;
                const session2 = whatsHereSessionRef.current;
                if (!session2) return;

                const finalRoot = buildPopupRoot(generateFeatureDetailContent(
                    layerResult.layerName,
                    layerResult.layerUrl,
                    feature,
                    layerResult.mapLayer,
                    body,
                    override.title || undefined
                ));
                wireDetailActions(finalRoot, feature);
                (mapView as any).openPopup({
                    title: "📍 What's here?",
                    content: finalRoot,
                    location: session2.mapPoint
                });
            })();
        };

        renderMaster();
    }, [isPopupEnabledForLayerUrl, generateMasterWhatsHereContent, generateFeatureDetailContent, findMatchingPopupOverride, evaluateOverrideExpressions, substituteOverrideTemplate, escapePopupHtml, props.config?.uiSettings?.popupMaxHeight]);

    // Inject a stylesheet for the What's Here popup rows once on mount.
    // This document.head copy styles the popup in EB 1.20 and earlier
    // (light-DOM popup). In EB 1.21 / JS API 5.x the popup content sits in
    // a shadow root this stylesheet cannot reach, so buildPopupRoot also
    // embeds RC_WH_CONTENT_CSS inside the content element itself. The
    // chrome rules (:has() on .esri-popup*) stay document-level only:
    // the popup chrome remains in the light DOM.
    React.useEffect(() => {
        const STYLE_ID = 'rc-whats-here-styles';
        if (document.getElementById(STYLE_ID)) return;
        const styleEl = document.createElement('style');
        styleEl.id = STYLE_ID;
        styleEl.textContent = RC_WH_CONTENT_CSS + `

/* Make the host popup chrome itself the resizable element when our
 * What's Here wrapper is mounted inside it. The CSS resize property needs
 * a non-visible overflow value to render the corner grip — the popup
 * main container already has overflow:hidden by default for rounded-corner
 * clipping, so this works in concert. Putting the resize affordance here
 * (instead of on the inner wrapper) is the only reliable way to grow the
 * popup horizontally on top of Esri's flex layout: the wrapper-resize
 * approach only changed the wrapper's own width and the parent content
 * area clipped it. */
.esri-popup__main-container:has(.rc-wh-popup-root) {
    resize: both !important;
    overflow: hidden !important;
    min-width: 320px !important;
    min-height: 200px !important;
    max-width: 92vw !important;
    max-height: 88vh !important;
}
.esri-popup:has(.rc-wh-popup-root),
.esri-popup__position-container:has(.rc-wh-popup-root) {
    max-width: 92vw !important;
    max-height: 88vh !important;
}
.esri-popup__content:has(.rc-wh-popup-root) {
    max-height: none !important;
    max-width: none !important;
}
        `.replace(/\s+$/, '');
        document.head.appendChild(styleEl);
        // Don't remove on unmount — the stylesheet is idempotent and inexpensive,
        // and another widget instance may still be using it.
    }, []);

    const handleContextMenuAction = React.useCallback((action: string) => {
        const { mapPoint, projectedLatLon } = state.contextMenu;
        const mapView = mapViewRef.current;

        if (!mapView || !mapPoint) {
            hideContextMenu();
            return;
        }

        switch (action) {
            case 'zoom-in':
                mapView.goTo({ target: mapPoint, zoom: mapView.zoom + 1 }).catch(() => { });
                break;
            case 'zoom-out':
                mapView.goTo({ target: mapPoint, zoom: mapView.zoom - 1 }).catch(() => { });
                break;
            case 'center-here':
                mapView.goTo({ target: mapPoint }).catch(() => { });
                break;
            case 'get-coordinates':
                copyCoordinates();
                break;
            case 'plot-coordinates':
                plotCoordinate();
                break;
            case 'plot-marker':
                plotSimpleMarker();
                break;
            // NEW: Add text action
            case 'add-text':
                showTextInputDialog();
                break;
            case 'clear-coordinates':
                clearCoordinateMarkers();
                break;
            case 'clear-markers':
                clearSimpleMarkers();
                break;
            case 'clear-text':
                clearTextGraphics();
                break;
            // UPDATED: Renamed from clear-all-markers to clear-all-graphics
            case 'clear-all-graphics':
                clearAllGraphics();
                break;
            case 'undo-last-graphic':
                undoLastGraphic();
                break;
            case 'google-maps':
                openGoogleMaps();
                break;
            case 'copy-address': {
                const addr = state.contextMenu.addressText;
                if (addr) {
                    copyWithPrompt(addr);
                    announce(`Address copied: ${addr}`);
                }
                break;
            }
            case 'copy-formats-toggle':
                // Expand or collapse the alternate-format submenu. Keep the
                // menu open; the focused index stays on the toggle row.
                setState(prev => ({
                    ...prev,
                    contextMenu: { ...prev.contextMenu, copyFormatsExpanded: !prev.contextMenu.copyFormatsExpanded }
                }));
                return;
            case 'copy-dd':
            case 'copy-dms':
            case 'copy-native':
            case 'copy-utm':
            case 'copy-custom':
            case 'copy-geojson': {
                const key = action.replace('copy-', '') as keyof NonNullable<State['contextMenu']['coordAlternates']>;
                const value = state.contextMenu.coordAlternates?.[key];
                if (value) {
                    copyWithPrompt(value);
                    announce(`Copied: ${value}`);
                }
                break;
            }
            case 'street-view':
                openStreetView();
                break;
            case 'pictometry':
                openPictometryView();
                break;
            case 'measure-distance':
                startMeasurement();
                break;
            case 'measure-area':
                startAreaMeasurement();
                break;
            case 'whats-here': {
                const handleWhatsHere = async () => {
                    hideContextMenu(); // hide menu immediately before async work begins
                    try {
                        type ResultRow = { layerName: string; features: any[]; layerUrl: string; popupEnabled?: boolean; mapLayer?: any };
                        let allResults: ResultRow[] = [];

                        let addressText = '';
                        if (props.config?.reverseGeocodeUrl) {
                            // Build a WGS84 point for the locator using pre-computed projectedLatLon
                            // (already accurate from right-click). Avoids projectToSpatialReference
                            // which calls projectOperator.load() — that can hang in local dev (WASM
                            // blocked by CSP) and never reject, stalling the entire async function.
                            const { lat, lon } = projectedLatLon ?? manualProjectToLatLon(mapPoint);

                            try {
                                // Build a plain object point — avoids needing esri/geometry/Point constructor
                                const geoPoint = { x: lon, y: lat, spatialReference: { wkid: 4326 } };

                                const response: any = await (locator as any).locationToAddress(
                                    props.config.reverseGeocodeUrl,
                                    { location: geoPoint, distance: 1000, outSR: { wkid: 4326 } }
                                );

                                const raw = response?.address ||
                                    response?.attributes?.Match_addr ||
                                    response?.attributes?.Address ||
                                    response?.attributes?.StAddr ||
                                    response?.attributes?.Street || '';
                                addressText = typeof raw === 'string' ? raw : '';

                            } catch (error) {
                                // Geocode failed — fall back to showing coordinates
                                addressText = `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
                            }
                        }

                        const normalizeUrl = (u: string) => (u || '').replace(/\/+$/, '').toLowerCase();
                        const seenUrls = new Set<string>();

                        // ── 1) Auto-discovery from the map ─────────────────
                        // Walk every queryable layer in the live map (FeatureLayers
                        // and MapImageLayer/TileLayer sublayers, including those
                        // nested arbitrarily deep in GroupLayers / map service
                        // group sublayers) and query each at the click point. This
                        // makes "What's Here" work out of the box with any webmap
                        // — no per-layer configuration required.
                        const discovered = collectQueryableLayersFromMap();
                        if (discovered.length > 0) {
                            const settled = await Promise.allSettled(
                                discovered.map(entry => queryLayerEntryAtPoint(entry, mapPoint))
                            );
                            for (const r of settled) {
                                if (r.status !== 'fulfilled') continue;
                                if (!r.value.features.length) continue;
                                const key = normalizeUrl(r.value.layerUrl);
                                if (key) {
                                    if (seenUrls.has(key)) continue;
                                    seenUrls.add(key);
                                }
                                allResults.push(r.value);
                            }
                        }

                        // ── 2) Manually configured feature layers ──────────
                        // Anything the user explicitly added in widget settings
                        // is still queried via the REST path. Deduped by URL
                        // against auto-discovered results so we don't double up.
                        if (props.config?.featureLayers?.length) {
                            const configToQuery = props.config.featureLayers.filter(l => {
                                const key = normalizeUrl(l.url || '');
                                return key ? !seenUrls.has(key) : true;
                            });
                            if (configToQuery.length > 0) {
                                const cfgSettled = await Promise.allSettled(
                                    configToQuery.map(async (layer) => {
                                        try { return await queryFeatureLayer(layer, mapPoint); }
                                        catch { return { layerName: layer.name, features: [], layerUrl: layer.url }; }
                                    })
                                );
                                for (const r of cfgSettled) {
                                    if (r.status !== 'fulfilled') continue;
                                    if (!r.value.features.length) continue;
                                    const key = normalizeUrl(r.value.layerUrl);
                                    if (key) {
                                        if (seenUrls.has(key)) continue;
                                        seenUrls.add(key);
                                    }
                                    allResults.push(r.value);
                                }
                            }
                        }

                        // Hand off to the master/detail orchestrator. It renders the
                        // address + clickable feature list and wires up the back/forward
                        // navigation handlers on `window` for use by onclick attributes
                        // in the popup HTML.
                        openWhatsHerePopup(mapPoint, addressText, allResults);

                    } catch (error) {
                        (mapView as any).openPopup({
                            title: "📍 What's here?",
                            content: '<div style="color:#d32f2f;padding:16px;text-align:center;"><strong>Error querying location information.</strong></div>',
                            location: mapPoint
                        });
                    }
                };

                // Auto-discovery means we no longer need configured layers OR a
                // geocode URL to be useful — any webmap with queryable layers
                // will produce a result. Only bail when literally nothing is
                // available (no geocode AND no map layers loaded yet).
                const mv = mapViewRef.current;
                const hasAnyLayers = !!mv?.map && (((mv.map as any).allLayers?.items?.length || 0) > 0);
                if (!props.config?.reverseGeocodeUrl && !hasAnyLayers && (!props.config?.featureLayers || props.config.featureLayers.length === 0)) {
                    alert("What's Here functionality requires the map to have layers loaded, or a geocoding service URL, or feature layers configured in widget settings.");
                    break;
                }

                handleWhatsHere();
                return; // skip the hideContextMenu() at the bottom — openPopup handles its own state
            }
            case 'property-report': {
                const targetWidgetId = props.config?.propertyReportSettings?.targetWidgetId;

                if (targetWidgetId) {
                    try {
                        const pointData = {
                            x: mapPoint.x,
                            y: mapPoint.y,
                            spatialReference: mapPoint.spatialReference?.toJSON?.() || mapPoint.spatialReference || { wkid: 4326 }
                        };

                        const containerType = props.config?.propertyReportSettings?.parentContainerType;
                        openContainerAndTarget(targetWidgetId, containerType);

                        const sendPoint = (delay: number) => {
                            setTimeout(() => {
                                try {
                                    MutableStoreManager.getInstance().updateStateValue(targetWidgetId, 'actionPoint', {
                                        point: pointData,
                                        address: null,
                                        autoOpenSection: null,
                                        timestamp: Date.now()
                                    });
                                    getAppStore().dispatch(
                                        appActions.widgetStatePropChange(targetWidgetId, 'actionTriggered', true)
                                    );
                                } catch { /* silent */ }
                            }, delay);
                        };

                        sendPoint(350);
                        sendPoint(1000);
                        sendPoint(1800);
                    } catch (err) {
                        console.error('Right-Click: Error triggering Property Report widget', err);
                    }
                }
                break;
            }
            case 'mailing-labels': {
                // Defer launch — first ask the user whether to apply a buffer.
                // launchMailingLabels (invoked by the dialog buttons) does the
                // actual controller open + MutableStoreManager update.
                if (props.config?.mailingLabelsSettings?.targetWidgetId) {
                    showMailingLabelsBufferDialog();
                }
                break;
            }
        }

        hideContextMenu();
    }, [state.contextMenu, hideContextMenu, copyCoordinates, plotCoordinate, plotSimpleMarker, showTextInputDialog, clearCoordinateMarkers, clearSimpleMarkers, clearTextGraphics, clearAllGraphics, undoLastGraphic, openGoogleMaps, copyWithPrompt, announce, openStreetView, openPictometryView, startMeasurement, startAreaMeasurement, projectToSpatialReference, queryFeatureLayer, collectQueryableLayersFromMap, queryLayerEntryAtPoint, openWhatsHerePopup, showMailingLabelsBufferDialog, openContainerAndTarget, props.config, getFieldDisplayName]);

    // Long-press (mobile) refs. Mobile touch devices have no right-click,
    // so the user presses and holds on the map to open the same context
    // menu. The pointer-down handler starts a timer; if the user holds
    // without moving more than moveThresholdPx, the timer fires and opens
    // the menu. pointer-move, pointer-up, pointer-cancel, and drag all
    // cancel the timer cleanly.
    const longPressTimerRef = React.useRef<number | null>(null);
    const longPressPointerIdRef = React.useRef<number | null>(null);
    const longPressStartXRef = React.useRef<number>(0);
    const longPressStartYRef = React.useRef<number>(0);
    const longPressMoveThresholdRef = React.useRef<number>(10);
    // True for a short window after a long-press successfully fires. The
    // OS / browser fires a trailing tap-click when the finger lifts; this
    // flag tells the click handler to ignore that one click so it doesn't
    // immediately dismiss the menu we just opened.
    const longPressJustFiredRef = React.useRef<boolean>(false);

    const clearLongPressTimer = React.useCallback(() => {
        if (longPressTimerRef.current !== null) {
            window.clearTimeout(longPressTimerRef.current);
            longPressTimerRef.current = null;
        }
        longPressPointerIdRef.current = null;
    }, []);

    // Shared menu-opening logic. Used by both the desktop right-click path
    // and the mobile long-press path so both produce identical menu
    // positioning, coordinate labels, and lat/lon refinement. screenX and
    // screenY are MapView container coordinates (same as event.x / event.y
    // on Esri pointer events).
    const openContextMenuAtPoint = React.useCallback((
        mapPoint: __esri.Point,
        screenX: number,
        screenY: number
    ) => {
        const mapView = mapViewRef.current;
        if (!mapView || !mapPoint) return;
        const container = mapView.container;
        if (!container) return;

        const copySettings = props.config?.copySettings || {
            coordinateSystem: 'map',
            customWkid: undefined,
            coordinateFormat: 'decimal',
            decimalPlaces: 2
        };

        // Synchronous coordinate label, refined async below if needed.
        let coordinateLabel: string;
        if (copySettings.coordinateSystem === 'webMercator') {
            const manualLatLon = manualProjectToLatLon(mapPoint);
            if (copySettings.coordinateFormat === 'dms') {
                coordinateLabel = `${convertToDMS(manualLatLon.lat, 'lat')}, ${convertToDMS(manualLatLon.lon, 'lon')}`;
            } else {
                coordinateLabel = `${manualLatLon.lat.toFixed(copySettings.decimalPlaces || 6)}, ${manualLatLon.lon.toFixed(copySettings.decimalPlaces || 6)}`;
            }
        } else {
            coordinateLabel = `${mapPoint.x.toFixed(copySettings.decimalPlaces || 2)}, ${mapPoint.y.toFixed(copySettings.decimalPlaces || 2)}`;
        }

        // Store the raw anchor (the pointer position in viewport pixels). The
        // menu is rendered in a portal on document.body and placed by the
        // layout effect below, which measures the menu's real size after it
        // renders and flips or clamps it so it always stays fully on screen.
        // The old code guessed a fixed 200 x 450 size here, which is why the
        // menu ran off the bottom of the page.
        const rect = container.getBoundingClientRect();
        const x = screenX + rect.left;
        const y = screenY + rect.top;

        const initialLatLon = manualProjectToLatLon(mapPoint);

        const menuSettings = props.config?.menuSettings || {};
        const wantAddress = menuSettings.showAddress !== false && !!props.config?.reverseGeocodeUrl;
        const wantFormats = menuSettings.showCoordinateFormats !== false;

        // Synchronous alternates available immediately from the manual math.
        const buildSyncAlternates = (lat: number, lon: number) => ({
            dd: `${lat.toFixed(6)}, ${lon.toFixed(6)}`,
            dms: `${convertToDMS(lat, 'lat')}, ${convertToDMS(lon, 'lon')}`,
            native: `${mapPoint.x.toFixed(2)}, ${mapPoint.y.toFixed(2)}${mapPoint.spatialReference?.wkid ? ` (WKID ${mapPoint.spatialReference.wkid})` : ''}`,
            geojson: `{"type":"Point","coordinates":[${lon.toFixed(7)},${lat.toFixed(7)}]}`
        });

        setState(prevState => ({
            ...prevState,
            showingContextMenu: true,
            contextMenu: {
                visible: true,
                x,
                y,
                mapPoint,
                coordinateLabel,
                projectedLatLon: initialLatLon,
                addressText: wantAddress ? null : undefined,
                copyFormatsExpanded: false,
                coordAlternates: wantFormats ? buildSyncAlternates(initialLatLon.lat, initialLatLon.lon) : undefined
            }
        }));

        // Token guards every async update below so a fast second right-click
        // never gets stale results from the first.
        const openToken = Date.now() + Math.random();
        menuOpenTokenRef.current = openToken;
        const stillCurrent = () => menuOpenTokenRef.current === openToken;

        // Address for the menu header (only when configured).
        if (wantAddress) {
            (async () => {
                let addressText = '';
                try {
                    const { lat, lon } = initialLatLon;
                    const geoPoint = { x: lon, y: lat, spatialReference: { wkid: 4326 } };
                    const response: any = await (locator as any).locationToAddress(
                        props.config!.reverseGeocodeUrl,
                        { location: geoPoint, distance: 1000, outSR: { wkid: 4326 } }
                    );
                    const raw = response?.address ||
                        response?.attributes?.Match_addr ||
                        response?.attributes?.Address ||
                        response?.attributes?.StAddr ||
                        response?.attributes?.Street || '';
                    addressText = typeof raw === 'string' ? raw : '';
                } catch (e) { addressText = ''; }
                if (!stillCurrent()) return;
                setState(prev => ({
                    ...prev,
                    contextMenu: { ...prev.contextMenu, addressText }
                }));
            })();
        }

        // UTM (auto zone from longitude) and configured custom WKID, both
        // async projections, filled in when they resolve.
        if (wantFormats) {
            (async () => {
                const { lat, lon } = initialLatLon;
                const updates: any = {};
                try {
                    const zone = Math.max(1, Math.min(60, Math.floor((lon + 180) / 6) + 1));
                    const utmWkid = (lat >= 0 ? 32600 : 32700) + zone;
                    const p = await projectToSpatialReference(mapPoint, utmWkid);
                    if (p && isFinite(p.x) && isFinite(p.y)) {
                        updates.utm = `${zone}${lat >= 0 ? 'N' : 'S'} ${p.x.toFixed(2)}E ${p.y.toFixed(2)}N`;
                    }
                } catch (e) { /* UTM unavailable */ }
                const customWkid = props.config?.copySettings?.customWkid;
                if (customWkid && customWkid !== mapPoint.spatialReference?.wkid) {
                    try {
                        const p = await projectToSpatialReference(mapPoint, customWkid);
                        if (p && isFinite(p.x) && isFinite(p.y)) {
                            updates.custom = `${p.x.toFixed(2)}, ${p.y.toFixed(2)} (WKID ${customWkid})`;
                        }
                    } catch (e) { /* custom unavailable */ }
                }
                if (!stillCurrent() || Object.keys(updates).length === 0) return;
                setState(prev => ({
                    ...prev,
                    contextMenu: {
                        ...prev.contextMenu,
                        coordAlternates: { ...(prev.contextMenu.coordAlternates || {}), ...updates }
                    }
                }));
            })();
        }

        // Refine projectedLatLon with accurate async projection. Street
        // View and Pictometry consume this, so accuracy matters.
        projectToLatLon(mapPoint).then(latLonPoint => {
            if (latLonPoint?.x !== undefined && latLonPoint?.y !== undefined &&
                Math.abs(latLonPoint.y) <= 90 && Math.abs(latLonPoint.x) <= 180) {
                if (!stillCurrent()) return;
                setState(prev => ({
                    ...prev,
                    contextMenu: {
                        ...prev.contextMenu,
                        projectedLatLon: { lat: latLonPoint.y, lon: latLonPoint.x },
                        // Refresh the sync alternates with the accurate values.
                        coordAlternates: prev.contextMenu.coordAlternates
                            ? { ...prev.contextMenu.coordAlternates, ...buildSyncAlternates(latLonPoint.y, latLonPoint.x) }
                            : prev.contextMenu.coordAlternates
                    }
                }));
            }
        }).catch(() => { });

        if (copySettings.coordinateSystem === 'webMercator') {
            projectToLatLon(mapPoint).then(latLonPoint => {
                if (latLonPoint?.x !== undefined && latLonPoint?.y !== undefined &&
                    Math.abs(latLonPoint.y) <= 90 && Math.abs(latLonPoint.x) <= 180) {
                    const newLabel = copySettings.coordinateFormat === 'dms'
                        ? `${convertToDMS(latLonPoint.y, 'lat')}, ${convertToDMS(latLonPoint.x, 'lon')}`
                        : `${latLonPoint.y.toFixed(copySettings.decimalPlaces || 6)}, ${latLonPoint.x.toFixed(copySettings.decimalPlaces || 6)}`;
                    setState(prev => ({
                        ...prev,
                        contextMenu: { ...prev.contextMenu, coordinateLabel: newLabel }
                    }));
                }
            }).catch(() => { });
        } else if (copySettings.coordinateSystem === 'custom' && copySettings.customWkid) {
            projectToSpatialReference(mapPoint, copySettings.customWkid).then(projectedPoint => {
                const newLabel = `${projectedPoint.x.toFixed(copySettings.decimalPlaces || 2)}, ${projectedPoint.y.toFixed(copySettings.decimalPlaces || 2)}`;
                setState(prev => ({
                    ...prev,
                    contextMenu: { ...prev.contextMenu, coordinateLabel: newLabel }
                }));
            }).catch(() => { });
        }
    }, [projectToLatLon, manualProjectToLatLon, projectToSpatialReference, convertToDMS, props.config?.copySettings, props.config?.menuSettings, props.config?.reverseGeocodeUrl]);

    const onActiveViewChange = React.useCallback((jmv: JimuMapView) => {
        if (jmv?.view) {
            const mapView = jmv.view as __esri.MapView;
            mapViewRef.current = mapView;

            // Only attach handlers once per map view instance
            if (handlersAttachedRef.current && lastMapViewRef.current === mapView) {
                return;
            }

            lastMapViewRef.current = mapView;
            handlersAttachedRef.current = true;

            mapView.when(() => {
                const container = mapView.container;

                mapView.on('pointer-down', (event) => {
                    if (event.button === 2) {
                        // Desktop right-click.
                        if (event.native) {
                            event.native.preventDefault?.();
                            event.native.stopImmediatePropagation?.();
                        }
                        event.stopPropagation();
                        const mapPoint = mapView.toMap({ x: event.x, y: event.y });
                        openContextMenuAtPoint(mapPoint, event.x, event.y);
                        return;
                    }

                    // Mobile long-press path. Touch input only; mouse and
                    // pen are handled by their native flows.
                    const lp = props.config?.longPressSettings || {};
                    const longPressEnabled = lp.enabled !== false;
                    const isTouch = (event as any).pointerType === 'touch'
                        || event.native?.pointerType === 'touch';
                    if (!longPressEnabled || !isTouch) return;

                    // If a long-press is already pending and a second
                    // pointer touches (pinch zoom), cancel and bail.
                    if (longPressPointerIdRef.current !== null) {
                        clearLongPressTimer();
                        return;
                    }

                    const duration = typeof lp.durationMs === 'number' && lp.durationMs > 0
                        ? lp.durationMs : 500;
                    const moveThreshold = typeof lp.moveThresholdPx === 'number' && lp.moveThresholdPx > 0
                        ? lp.moveThresholdPx : 10;

                    const pid = (event as any).pointerId
                        ?? event.native?.pointerId
                        ?? -1;
                    longPressPointerIdRef.current = pid;
                    longPressStartXRef.current = event.x;
                    longPressStartYRef.current = event.y;
                    longPressMoveThresholdRef.current = moveThreshold;

                    if (longPressTimerRef.current !== null) {
                        window.clearTimeout(longPressTimerRef.current);
                    }
                    longPressTimerRef.current = window.setTimeout(() => {
                        longPressTimerRef.current = null;
                        // Re-check the active pointer matches. If the
                        // gesture was cancelled, the pointer-up handler
                        // already cleared the id.
                        if (longPressPointerIdRef.current !== pid) return;

                        longPressJustFiredRef.current = true;
                        // Best-effort haptic on Android. iOS Safari ignores
                        // navigator.vibrate, which is fine. The user gets
                        // the menu either way.
                        try { navigator.vibrate?.(10); } catch { /* ignore */ }

                        const startX = longPressStartXRef.current;
                        const startY = longPressStartYRef.current;
                        const mp = mapView.toMap({ x: startX, y: startY });
                        if (mp) openContextMenuAtPoint(mp, startX, startY);

                        // Clear the just-fired flag after a short window.
                        // Long enough to swallow the trailing click,
                        // short enough that a genuine subsequent tap still
                        // dismisses the menu.
                        window.setTimeout(() => {
                            longPressJustFiredRef.current = false;
                        }, 400);
                    }, duration);
                });

                // Cancel if the finger moves more than the threshold from
                // its starting point. A small displacement is allowed since
                // a finger never sits perfectly still during a press.
                mapView.on('pointer-move', (event) => {
                    if (longPressTimerRef.current === null) return;
                    const pid = (event as any).pointerId
                        ?? event.native?.pointerId
                        ?? -1;
                    if (pid !== longPressPointerIdRef.current) return;
                    const dx = event.x - longPressStartXRef.current;
                    const dy = event.y - longPressStartYRef.current;
                    const threshold = longPressMoveThresholdRef.current;
                    if (dx * dx + dy * dy > threshold * threshold) {
                        clearLongPressTimer();
                    }
                });

                mapView.on('pointer-up', (event) => {
                    const pid = (event as any).pointerId
                        ?? event.native?.pointerId
                        ?? -1;
                    if (pid === longPressPointerIdRef.current) {
                        clearLongPressTimer();
                    }
                });

                // pointer-leave covers fingers dragged off the canvas
                // without lifting (rare, but it happens at the edges).
                (mapView as any).on?.('pointer-leave', () => {
                    clearLongPressTimer();
                });

                mapView.on('click', (event) => {
                    // After a successful long-press, swallow the trailing
                    // synthetic tap so it doesn't dismiss the menu we just
                    // opened.
                    if (longPressJustFiredRef.current) return;
                    if (event.button !== 2) {
                        hideContextMenu();
                    }
                });

                mapView.on('drag', () => {
                    // A confirmed pan also cancels any in-flight long-press.
                    // Defense in depth: the move threshold should have
                    // caught it already.
                    clearLongPressTimer();
                    hideContextMenu();
                });

                // Suppress iOS Safari's native "touch callout" (the copy /
                // look-up popover that appears on long-press of any
                // element) so it doesn't fight our own long-press menu.
                // Same for text selection during a press.
                //
                // IMPORTANT: apply this to the canvas surface
                // (.esri-view-surface) only, NOT the whole MapView
                // container. The popup (.esri-ui > .esri-popup) is a
                // sibling of the surface inside the container; setting
                // user-select:none on the container is inherited by the
                // popup and makes all popup text unselectable/uncopyable
                // app-wide. Scoping to the surface keeps long-press
                // suppression on the map canvas while popup text stays
                // selectable (matches Portal Map Viewer behavior).
                try {
                    const c = container as HTMLElement;
                    const surface = c.querySelector('.esri-view-surface') as HTMLElement | null;
                    const target = surface ?? c;
                    (target.style as any).webkitTouchCallout = 'none';
                    (target.style as any).webkitUserSelect = 'none';
                    target.style.userSelect = 'none';
                    // Defensive: clear any container-level suppression a
                    // previous build of this widget may have stamped.
                    if (surface) {
                        (c.style as any).webkitTouchCallout = '';
                        (c.style as any).webkitUserSelect = '';
                        c.style.userSelect = '';
                    }
                } catch { /* ignore */ }
            }).catch(() => { });
        }
    }, [projectToLatLon, manualProjectToLatLon, projectToSpatialReference, convertToDMS, hideContextMenu, openContextMenuAtPoint, clearLongPressTimer, props.config?.copySettings, props.config?.longPressSettings]);

    // Build menu items array for keyboard navigation and rendering. Each
    // item carries a `group` so the renderer can draw a separator when the
    // group changes, and an optional `sub` flag for indented submenu rows.
    type MenuItem = { action: string; icon: string; text: string; enabled: boolean; group: string; sub?: boolean; hint?: string };
    const getMenuItems = React.useCallback(() => {
        const items: MenuItem[] = [];
        const ea = props.config?.enabledActions || {};
        const ms = props.config?.menuSettings || {};
        const cm = state.contextMenu;

        // Navigation
        if (ea.zoomIn !== false) items.push({ action: 'zoom-in', icon: 'zoom-in-fixed', text: 'Zoom In', enabled: true, group: 'nav' });
        if (ea.zoomOut !== false) items.push({ action: 'zoom-out', icon: 'zoom-out-fixed', text: 'Zoom Out', enabled: true, group: 'nav' });
        if (ea.centerHere !== false) items.push({ action: 'center-here', icon: 'gps-on', text: 'Center Here', enabled: true, group: 'nav' });

        // Coordinates
        if (ea.copyCoordinates !== false && cm.coordinateLabel) {
            items.push({ action: 'get-coordinates', icon: 'copy-to-clipboard', text: 'Copy Coordinates', enabled: true, group: 'coords', hint: cm.coordinateLabel });
            if (ms.showCoordinateFormats !== false && cm.coordAlternates) {
                const expanded = !!cm.copyFormatsExpanded;
                items.push({ action: 'copy-formats-toggle', icon: expanded ? 'chevron-down' : 'chevron-right', text: expanded ? 'Fewer formats' : 'More coordinate formats', enabled: true, group: 'coords' });
                if (expanded) {
                    const alt = cm.coordAlternates;
                    if (alt.dd) items.push({ action: 'copy-dd', icon: 'globe', text: 'Lat / Lon (decimal)', enabled: true, group: 'coords', sub: true, hint: alt.dd });
                    if (alt.dms) items.push({ action: 'copy-dms', icon: 'compass', text: 'Lat / Lon (DMS)', enabled: true, group: 'coords', sub: true, hint: alt.dms });
                    if (alt.utm) items.push({ action: 'copy-utm', icon: 'grid', text: 'UTM', enabled: true, group: 'coords', sub: true, hint: alt.utm });
                    if (alt.custom) items.push({ action: 'copy-custom', icon: 'coordinate-system', text: 'Custom projection', enabled: true, group: 'coords', sub: true, hint: alt.custom });
                    if (alt.native) items.push({ action: 'copy-native', icon: 'map', text: 'Map native X / Y', enabled: true, group: 'coords', sub: true, hint: alt.native });
                    if (alt.geojson) items.push({ action: 'copy-geojson', icon: 'code', text: 'GeoJSON point', enabled: true, group: 'coords', sub: true, hint: alt.geojson });
                }
            }
        }
        if (typeof cm.addressText === 'string' && cm.addressText) {
            items.push({ action: 'copy-address', icon: 'home', text: 'Copy Address', enabled: true, group: 'coords', hint: cm.addressText });
        }

        // Graphics
        if (ea.plotMarker !== false) items.push({ action: 'plot-marker', icon: 'pin', text: 'Plot Marker', enabled: true, group: 'graphics' });
        if (ea.plotCoordinates !== false) items.push({ action: 'plot-coordinates', icon: 'point', text: 'Plot Coordinate', enabled: true, group: 'graphics' });
        if (ea.addText !== false) items.push({ action: 'add-text', icon: 'text', text: 'Add Text', enabled: true, group: 'graphics' });
        const graphicCount = state.coordinateMarkers.length + state.simpleMarkers.length + state.textGraphics.length;
        const anyGraphicAction = ea.plotCoordinates !== false || ea.plotMarker !== false || ea.addText !== false;
        if (graphicCount > 0 && anyGraphicAction) {
            items.push({ action: 'undo-last-graphic', icon: 'undo', text: 'Undo Last Graphic', enabled: true, group: 'graphics' });
            items.push({ action: 'clear-all-graphics', icon: 'trash', text: `Clear All Graphics (${graphicCount})`, enabled: true, group: 'graphics' });
        }

        // External
        if (ea.streetView !== false) items.push({ action: 'street-view', icon: 'walking', text: 'Open in Google Street View', enabled: true, group: 'external' });
        if (ea.googleMaps !== false) items.push({ action: 'google-maps', icon: 'map-pin', text: 'Open in Google Maps', enabled: true, group: 'external' });
        if (ea.pictometry !== false && props.config?.pictometryUrl) items.push({ action: 'pictometry', icon: 'camera', text: 'Open in Pictometry', enabled: true, group: 'external' });

        // Tools
        if (ea.measureDistance !== false) items.push({ action: 'measure-distance', icon: 'measure', text: 'Measure Distance', enabled: true, group: 'tools' });
        if (ea.measureArea !== false) items.push({ action: 'measure-area', icon: 'measure-area', text: 'Measure Area', enabled: true, group: 'tools' });

        // Information
        if (ea.whatsHere !== false) items.push({ action: 'whats-here', icon: 'question', text: "What's here?", enabled: true, group: 'info' });
        if (ea.propertyReport && props.config?.propertyReportSettings?.targetWidgetId) {
            items.push({ action: 'property-report', icon: 'information', text: props.config.propertyReportSettings.menuLabel || 'Property Information', enabled: true, group: 'info' });
        }
        if (ea.mailingLabels && props.config?.mailingLabelsSettings?.targetWidgetId) {
            items.push({ action: 'mailing-labels', icon: 'envelope', text: props.config.mailingLabelsSettings.menuLabel || 'Mailing Labels', enabled: true, group: 'info' });
        }

        return items;
    }, [props.config?.enabledActions, props.config?.menuSettings, props.config?.pictometryUrl, props.config?.propertyReportSettings?.targetWidgetId, props.config?.propertyReportSettings?.menuLabel, props.config?.mailingLabelsSettings?.targetWidgetId, props.config?.mailingLabelsSettings?.menuLabel, state.contextMenu, state.coordinateMarkers.length, state.simpleMarkers.length, state.textGraphics.length]);


    const menuItems = getMenuItems();

    // Feature flags for the help guide, computed from the same checks
    // getMenuItems() uses so the guide never describes a row the menu hides.
    const helpFeatures: HelpFeatures = (() => {
        const ea = props.config?.enabledActions || {};
        const ms = props.config?.menuSettings || {};
        return {
            zoomIn: ea.zoomIn !== false,
            zoomOut: ea.zoomOut !== false,
            centerHere: ea.centerHere !== false,
            copyCoordinates: ea.copyCoordinates !== false,
            coordinateFormats: ms.showCoordinateFormats !== false,
            address: ms.showAddress !== false && !!props.config?.reverseGeocodeUrl,
            plotMarker: ea.plotMarker !== false,
            plotCoordinates: ea.plotCoordinates !== false,
            addText: ea.addText !== false,
            streetView: ea.streetView !== false,
            googleMaps: ea.googleMaps !== false,
            pictometry: ea.pictometry !== false && !!props.config?.pictometryUrl,
            measureDistance: ea.measureDistance !== false,
            measureArea: ea.measureArea !== false,
            whatsHere: ea.whatsHere !== false,
            propertyReport: !!ea.propertyReport && !!props.config?.propertyReportSettings?.targetWidgetId,
            mailingLabels: !!ea.mailingLabels && !!props.config?.mailingLabelsSettings?.targetWidgetId,
            hotkeys: ms.showHotkeys !== false,
            longPress: props.config?.longPressSettings?.enabled !== false,
            propertyReportLabel: props.config?.propertyReportSettings?.menuLabel || 'Property Information',
            mailingLabelsLabel: props.config?.mailingLabelsSettings?.menuLabel || 'Mailing Labels',
            measureUnits: props.config?.measurementSettings?.defaultUnits || 'feet'
        };
    })();

    const openHelp = React.useCallback(() => {
        hideContextMenu();
        setHelpOpen(true);
    }, [hideContextMenu]);

    // Handle keyboard navigation in context menu
    const handleMenuKeyDown = React.useCallback((e: React.KeyboardEvent) => {
        const items = menuItems;
        const currentIndex = state.focusedMenuIndex;

        // Number hotkeys: 1-9 trigger the corresponding visible row.
        if (props.config?.menuSettings?.showHotkeys !== false && /^[1-9]$/.test(e.key)) {
            const idx = parseInt(e.key, 10) - 1;
            if (idx < items.length) {
                e.preventDefault();
                handleContextMenuAction(items[idx].action);
                return;
            }
        }

        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                const nextIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
                setState(prev => ({ ...prev, focusedMenuIndex: nextIndex }));
                break;
            case 'ArrowUp':
                e.preventDefault();
                const prevIndex = currentIndex > 0 ? currentIndex - 1 : items.length - 1;
                setState(prev => ({ ...prev, focusedMenuIndex: prevIndex }));
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                if (currentIndex >= 0 && currentIndex < items.length) {
                    handleContextMenuAction(items[currentIndex].action);
                }
                break;
            case 'Escape':
                e.preventDefault();
                hideContextMenu();
                break;
            case '?':
            case 'F1':
                e.preventDefault();
                openHelp();
                break;
            case 'Tab':
                e.preventDefault();
                hideContextMenu();
                break;
            case 'Home':
                e.preventDefault();
                setState(prev => ({ ...prev, focusedMenuIndex: 0 }));
                break;
            case 'End':
                e.preventDefault();
                setState(prev => ({ ...prev, focusedMenuIndex: items.length - 1 }));
                break;
        }
    }, [menuItems, state.focusedMenuIndex, handleContextMenuAction, hideContextMenu, openHelp, props.config?.menuSettings?.showHotkeys]);

    // Focus menu when it becomes visible
    React.useEffect(() => {
        if (state.contextMenu.visible && menuRef.current) {
            setState(prev => ({ ...prev, focusedMenuIndex: 0 }));
            menuRef.current.focus();
        }
    }, [state.contextMenu.visible]);

    // Menu placement. Runs after every render while the menu is open, before
    // the browser paints, so the user never sees the unplaced position.
    //   1. Put the menu at the pointer with its height capped to the viewport.
    //   2. Measure the real rendered size (content varies: address header,
    //      expanded coordinate formats, undo/clear rows).
    //   3. If it would run off the right edge, open it to the left of the
    //      pointer; if it would run off the bottom, open it above the pointer.
    //   4. Clamp whatever is left inside the viewport with a small margin.
    // The result is written straight to the element and remembered in a ref
    // so re-renders (hover, address arriving) reuse it instead of resetting
    // to the raw anchor.
    const MENU_VIEWPORT_MARGIN = 8;
    const menuPlacementRef = React.useRef<{ left: number; top: number; maxHeight: number } | null>(null);
    React.useLayoutEffect(() => {
        const el = menuRef.current;
        if (!el || !state.contextMenu.visible) {
            menuPlacementRef.current = null;
            return;
        }
        const vw = document.documentElement.clientWidth || window.innerWidth;
        const vh = document.documentElement.clientHeight || window.innerHeight;
        const m = MENU_VIEWPORT_MARGIN;
        const ax = state.contextMenu.x;
        const ay = state.contextMenu.y;
        const maxHeight = Math.max(120, vh - 2 * m);

        el.style.maxHeight = `${maxHeight}px`;
        el.style.left = `${ax}px`;
        el.style.top = `${ay}px`;
        const { width, height } = el.getBoundingClientRect();

        let left = ax;
        if (left + width + m > vw) left = ax - width;
        left = Math.min(Math.max(left, m), Math.max(m, vw - width - m));

        let top = ay;
        if (top + height + m > vh) top = ay - height;
        top = Math.min(Math.max(top, m), Math.max(m, vh - height - m));

        el.style.left = `${left}px`;
        el.style.top = `${top}px`;
        menuPlacementRef.current = { left, top, maxHeight };
    });

    // The anchor is only valid for the layout it was measured in: a window
    // resize or a page scroll moves the map under the menu, so close it.
    React.useEffect(() => {
        if (!state.contextMenu.visible) return;
        const close = () => { hideContextMenu(); };
        window.addEventListener('resize', close);
        window.addEventListener('scroll', close, true);
        return () => {
            window.removeEventListener('resize', close);
            window.removeEventListener('scroll', close, true);
        };
    }, [state.contextMenu.visible, hideContextMenu]);

    // Focus trap for text dialog
    React.useEffect(() => {
        if (state.showTextDialog && textInputRef.current) {
            textInputRef.current.focus();
        }
    }, [state.showTextDialog]);

    // Focus the "Apply buffer" checkbox when the Mailing Labels dialog opens
    // so keyboard / screen-reader users land on the first interactive element.
    // From there they can Tab to the distance input and unit dropdown, or just
    // press Enter on the input field to submit.
    React.useEffect(() => {
        if (state.showMailingLabelsBufferDialog && mailingLabelsApplyBufferBtnRef.current) {
            mailingLabelsApplyBufferBtnRef.current.focus();
        }
    }, [state.showMailingLabelsBufferDialog]);

    const placement = menuPlacementRef.current;
    const contextMenuStyle: React.CSSProperties = {
        position: 'fixed',
        top: placement ? placement.top : state.contextMenu.y,
        left: placement ? placement.left : state.contextMenu.x,
        maxHeight: placement ? `${placement.maxHeight}px` : undefined,
        overflowY: 'auto',
        overflowX: 'hidden',
        boxSizing: 'border-box',
        backgroundColor: tokens.surface,
        color: tokens.text,
        border: `1px solid ${tokens.divider}`,
        borderRadius: tokens.radiusLg,
        boxShadow: tokens.shadowHover,
        zIndex: 2147483647,
        minWidth: '260px',
        maxWidth: '340px',
        padding: '4px 0',
        fontFamily: themeFont,
        fontSize: '14px',
        lineHeight: 1.3,
        outline: 'none'
    };

    const MONO_FONT = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

    const getMenuItemStyle = (index: number, sub?: boolean): React.CSSProperties => {
        const focused = state.focusedMenuIndex === index;
        return {
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            padding: sub ? '6px 12px 6px 30px' : '7px 12px',
            margin: '0 4px',
            borderRadius: tokens.radius,
            cursor: 'pointer',
            fontSize: sub ? '13px' : '14px',
            lineHeight: 1.3,
            color: tokens.text,
            backgroundColor: focused ? tokens.infoBg : 'transparent',
            outline: focused ? `2px solid ${tokens.primary}` : 'none',
            outlineOffset: '-2px',
            userSelect: 'none'
        };
    };

    const showHotkeys = props.config?.menuSettings?.showHotkeys !== false;

    // Accessible MenuItem render function - NOT memoized to avoid stale closure issues.
    // Rows show a Calcite icon, the label, an optional muted hint (the value that
    // will be copied) and, for the first nine rows, a number badge matching the hotkey.
    const renderMenuItem = (item: { action: string; icon: string; text: string; sub?: boolean; hint?: string }, index: number) => (
        <div
            key={item.action}
            role="menuitem"
            tabIndex={state.focusedMenuIndex === index ? 0 : -1}
            style={getMenuItemStyle(index, item.sub)}
            onMouseDown={(e) => {
                // Stop propagation AND prevent default to avoid document handler closing menu
                e.stopPropagation();
                e.preventDefault();
            }}
            onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                handleContextMenuAction(item.action);
            }}
            onMouseEnter={() => setState(prev => ({ ...prev, focusedMenuIndex: index }))}
            onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    e.stopPropagation();
                    handleContextMenuAction(item.action);
                }
            }}
            aria-label={item.hint ? `${item.text}: ${item.hint}` : item.text}
            title={item.hint || undefined}
        >
            <span aria-hidden="true" style={{ width: '20px', display: 'flex', justifyContent: 'center', flexShrink: 0, color: item.sub ? tokens.textSecondary : tokens.primary }}>
                <CalciteIcon icon={item.icon} scale="s" />
            </span>
            <span style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
                <span>{item.text}</span>
                {item.hint && (
                    <span style={{ fontSize: '11px', color: tokens.textSecondary, fontFamily: MONO_FONT, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {item.hint}
                    </span>
                )}
            </span>
            {showHotkeys && index < 9 && (
                <span aria-hidden="true" style={{
                    fontSize: '10px', color: tokens.textSecondary, border: `1px solid ${tokens.divider}`, borderRadius: '3px',
                    padding: '0 5px', lineHeight: '16px', minWidth: '16px', textAlign: 'center', flexShrink: 0,
                    fontFamily: MONO_FONT
                }}>{index + 1}</span>
            )}
        </div>
    );

    // Header block: where the user right-clicked. Coordinates always; address
    // when reverse geocoding is configured (shows a subtle loading state while
    // the lookup is in flight). Clicking the address copies it.
    const renderMenuHeader = () => {
        const cm = state.contextMenu;
        const addrState = cm.addressText;
        return (
            <div style={{ padding: '8px 16px 8px', borderBottom: `1px solid ${tokens.divider}`, marginBottom: '4px' }} role="presentation">
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ flex: 1, minWidth: 0, fontSize: '10px', letterSpacing: '0.06em', textTransform: 'uppercase', color: tokens.textSecondary, fontWeight: 600 }}>Location</div>
                    <Button
                        size="sm"
                        type="tertiary"
                        icon
                        title={t('helpTitle')}
                        aria-label={t('helpTitle')}
                        style={{ flexShrink: 0, marginRight: '-8px' }}
                        onMouseDown={(e: React.MouseEvent) => { e.stopPropagation(); e.preventDefault(); }}
                        onClick={(e: React.MouseEvent) => { e.stopPropagation(); e.preventDefault(); openHelp(); }}
                    >
                        <CalciteIcon icon="question" scale="s" />
                    </Button>
                </div>
                {addrState === null && (
                    <div style={{ fontSize: '13px', color: tokens.textSecondary, fontStyle: 'italic', marginTop: '2px' }}>Looking up address...</div>
                )}
                {typeof addrState === 'string' && addrState && (
                    <div
                        style={{ fontSize: '13px', fontWeight: 600, color: tokens.text, marginTop: '2px', cursor: 'copy', wordBreak: 'break-word' }}
                        title="Click to copy address"
                        onMouseDown={(e) => { e.stopPropagation(); e.preventDefault(); }}
                        onClick={(e) => { e.stopPropagation(); e.preventDefault(); handleContextMenuAction('copy-address'); }}
                    >{addrState}</div>
                )}
                {cm.coordinateLabel && (
                    <div style={{ fontSize: '11px', color: tokens.textSecondary, marginTop: '2px', fontFamily: MONO_FONT }}>{cm.coordinateLabel}</div>
                )}
            </div>
        );
    };

    // The menu is rendered in a portal on document.body so `position: fixed`
    // is measured against the viewport regardless of how the widget's own
    // container is transformed or clipped by the Experience layout.
    const renderContextMenu = () => {
        if (!state.contextMenu.visible) return null;
        const menu = (
            <div
                id="context-menu"
                ref={menuRef}
                role="menu"
                aria-label="Map context menu"
                tabIndex={-1}
                style={contextMenuStyle}
                onKeyDown={handleMenuKeyDown}
                onMouseDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                onContextMenu={(e) => { e.preventDefault(); e.stopPropagation(); }}
            >
                {renderMenuHeader()}
                {menuItems.map((item, index) => {
                    const prev = index > 0 ? menuItems[index - 1] : null;
                    const separator = prev && prev.group !== item.group
                        ? <div key={`sep-${index}`} role="separator" style={{ height: '1px', background: tokens.divider, margin: '4px 10px' }} />
                        : null;
                    return (
                        <React.Fragment key={item.action}>
                            {separator}
                            {renderMenuItem(item, index)}
                        </React.Fragment>
                    );
                })}
            </div>
        );
        return typeof document !== 'undefined' && document.body
            ? ReactDOM.createPortal(menu, document.body)
            : menu;
    };

    // CSS styles using theme - this ensures proper font inheritance
    const getWidgetStyles = () => {
        return css`
            width: 100%;
            height: 100%;
            position: relative;
            font-family: ${themeFont};

            *, *::before, *::after {
                font-family: inherit;
            }
        `;
    };

    return (
        <div className="widget-right-click-map jimu-widget" css={getWidgetStyles()}>
            {mapWidgetIds?.length > 0 ? (
                <JimuMapViewComponent
                    useMapWidgetId={mapWidgetIds[0]}
                    onActiveViewChange={onActiveViewChange}
                />
            ) : (
                <div style={{ padding: '20px', textAlign: 'center' }}>
                    <p>Please configure this widget to use a Map widget.</p>
                    <p>Go to widget settings and select a map to connect to.</p>
                </div>
            )}

            {/* Accessible context menu (portaled to document.body) */}
            {renderContextMenu()}

            {/* Help guide (shared pattern, handoff Section 10) */}
            <HelpPopup
                open={helpOpen}
                onClose={() => { setHelpOpen(false); }}
                sections={buildHelpSections(t, helpFeatures)}
                title={t('helpTitle')}
                intro={t('helpIntro')}
                searchPlaceholder={t('helpSearchPlaceholder')}
                noMatches={t('helpNoMatches')}
                closeLabel={t('close')}
            />

            {/* Live region for screen reader announcements */}
            <div
                role="status"
                aria-live="polite"
                aria-atomic="true"
                style={{
                    position: 'absolute',
                    width: '1px',
                    height: '1px',
                    padding: 0,
                    margin: '-1px',
                    overflow: 'hidden',
                    clip: 'rect(0, 0, 0, 0)',
                    whiteSpace: 'nowrap',
                    border: 0
                }}
            >
                {state.announceMessage}
            </div>

            {/* Accessible text input dialog */}
            {state.showTextDialog && (
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 2000,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                    onClick={(e) => {
                        // Close on backdrop click
                        if (e.target === e.currentTarget) {
                            cancelTextInput();
                        }
                    }}
                    role="presentation"
                >
                    <div
                        ref={dialogRef}
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="text-dialog-title"
                        aria-describedby="text-dialog-description"
                        style={{
                            backgroundColor: 'white',
                            borderRadius: '8px',
                            padding: '24px',
                            minWidth: '400px',
                            maxWidth: '500px',
                            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
                            fontFamily: themeFont
                        }}
                        onKeyDown={(e) => {
                            // Focus trap - prevent Tab from leaving dialog
                            if (e.key === 'Tab') {
                                const focusableElements = dialogRef.current?.querySelectorAll(
                                    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
                                );
                                if (focusableElements && focusableElements.length > 0) {
                                    const firstElement = focusableElements[0] as HTMLElement;
                                    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

                                    if (e.shiftKey && document.activeElement === firstElement) {
                                        e.preventDefault();
                                        lastElement.focus();
                                    } else if (!e.shiftKey && document.activeElement === lastElement) {
                                        e.preventDefault();
                                        firstElement.focus();
                                    }
                                }
                            }
                            if (e.key === 'Escape') {
                                cancelTextInput();
                            }
                        }}
                    >
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginBottom: '16px',
                            paddingBottom: '12px',
                            borderBottom: '1px solid #e0e0e0'
                        }}>
                            <h2
                                id="text-dialog-title"
                                style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}
                            >
                                <span aria-hidden="true">🅰️ </span>Enter Your Text
                            </h2>
                            <button
                                onClick={cancelTextInput}
                                aria-label="Close dialog"
                                style={{
                                    background: 'none',
                                    border: '2px solid transparent',
                                    fontSize: '24px',
                                    cursor: 'pointer',
                                    color: '#555',
                                    padding: '4px',
                                    width: '36px',
                                    height: '36px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    borderRadius: '4px'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = 'transparent'; }}
                            >
                                <span aria-hidden="true">✕</span>
                            </button>
                        </div>
                        <p
                            id="text-dialog-description"
                            style={{
                                margin: '0 0 8px 0',
                                color: '#555',
                                fontSize: '14px',
                                fontFamily: themeFont,
                                lineHeight: '1.4'
                            }}
                        >
                            Type the text you want to add at this location on the map.
                        </p>
                        <label
                            htmlFor="map-text-input"
                            style={{
                                display: 'block',
                                marginBottom: '4px',
                                fontSize: '14px',
                                fontWeight: '500',
                                color: '#333'
                            }}
                        >
                            Text label
                        </label>
                        <input
                            ref={textInputRef}
                            id="map-text-input"
                            type="text"
                            placeholder="Enter text here"
                            aria-describedby="text-dialog-description"
                            style={{
                                width: '100%',
                                padding: '12px',
                                border: '2px solid #ccc',
                                borderRadius: '4px',
                                fontSize: '14px',
                                fontFamily: themeFont,
                                marginBottom: '20px',
                                boxSizing: 'border-box'
                            }}
                            onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                            onBlur={(e) => { e.currentTarget.style.borderColor = '#ccc'; }}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    const target = e.target as HTMLInputElement;
                                    if (target.value.trim()) {
                                        addTextToMap(target.value);
                                    }
                                }
                            }}
                        />
                        <div style={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            gap: '12px'
                        }}>
                            <button
                                onClick={cancelTextInput}
                                style={{
                                    padding: '10px 20px',
                                    border: '2px solid #555',
                                    borderRadius: '4px',
                                    backgroundColor: 'white',
                                    color: '#333',
                                    cursor: 'pointer',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    fontWeight: '500'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#555'; }}
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => {
                                    if (textInputRef.current && textInputRef.current.value.trim()) {
                                        addTextToMap(textInputRef.current.value);
                                    }
                                }}
                                style={{
                                    padding: '10px 20px',
                                    border: '2px solid #0066cc',
                                    borderRadius: '4px',
                                    backgroundColor: '#0066cc',
                                    color: 'white',
                                    cursor: 'pointer',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    fontWeight: '500'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#004499'; e.currentTarget.style.backgroundColor = '#004499'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#0066cc'; e.currentTarget.style.backgroundColor = '#0066cc'; }}
                            >
                                Add Text
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Mailing Labels buffer-choice dialog. Mirrors the text-input dialog
                for visual consistency; user picks "Yes" or "No" (or cancels) and
                launchMailingLabels handles the actual widget open. */}
            {state.showMailingLabelsBufferDialog && (
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 2000,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                    onClick={(e) => {
                        if (e.target === e.currentTarget) {
                            cancelMailingLabelsBufferDialog();
                        }
                    }}
                    role="presentation"
                >
                    <div
                        ref={mailingLabelsDialogRef}
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="mailing-labels-dialog-title"
                        aria-describedby="mailing-labels-dialog-description"
                        style={{
                            backgroundColor: 'white',
                            borderRadius: '8px',
                            padding: '24px',
                            minWidth: '400px',
                            maxWidth: '500px',
                            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
                            fontFamily: themeFont
                        }}
                        onKeyDown={(e) => {
                            // Focus trap — keep Tab inside the dialog.
                            if (e.key === 'Tab') {
                                const focusableElements = mailingLabelsDialogRef.current?.querySelectorAll(
                                    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
                                );
                                if (focusableElements && focusableElements.length > 0) {
                                    const firstElement = focusableElements[0] as HTMLElement;
                                    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

                                    if (e.shiftKey && document.activeElement === firstElement) {
                                        e.preventDefault();
                                        lastElement.focus();
                                    } else if (!e.shiftKey && document.activeElement === lastElement) {
                                        e.preventDefault();
                                        firstElement.focus();
                                    }
                                }
                            }
                            if (e.key === 'Escape') {
                                cancelMailingLabelsBufferDialog();
                            }
                        }}
                    >
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginBottom: '16px',
                            paddingBottom: '12px',
                            borderBottom: '1px solid #e0e0e0'
                        }}>
                            <h2
                                id="mailing-labels-dialog-title"
                                style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}
                            >
                                <span aria-hidden="true">✉️ </span>Mailing Labels
                            </h2>
                            <button
                                onClick={cancelMailingLabelsBufferDialog}
                                aria-label="Close dialog"
                                style={{
                                    background: 'none',
                                    border: '2px solid transparent',
                                    fontSize: '24px',
                                    cursor: 'pointer',
                                    color: '#555',
                                    padding: '4px',
                                    width: '36px',
                                    height: '36px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    borderRadius: '4px'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = 'transparent'; }}
                            >
                                <span aria-hidden="true">✕</span>
                            </button>
                        </div>
                        <p
                            id="mailing-labels-dialog-description"
                            style={{
                                margin: '0 0 16px 0',
                                color: '#333',
                                fontSize: '14px',
                                fontFamily: themeFont,
                                lineHeight: '1.5'
                            }}
                        >
                            Would you like to apply a buffer to your selection? Tick the
                            box below and enter a distance to include all features within
                            that range of the right-clicked location.
                        </p>

                        {/* Apply-buffer toggle */}
                        <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            marginBottom: '12px'
                        }}>
                            <input
                                ref={mailingLabelsApplyBufferBtnRef}
                                id="mailing-labels-apply-buffer"
                                type="checkbox"
                                checked={state.mailingLabelsBufferEnabled}
                                onChange={(e) => {
                                    const checked = e.target.checked;
                                    setState(prev => ({
                                        ...prev,
                                        mailingLabelsBufferEnabled: checked,
                                        // Clear any prior validation error when the checkbox is toggled
                                        mailingLabelsBufferError: ''
                                    }));
                                }}
                                style={{
                                    width: '18px',
                                    height: '18px',
                                    cursor: 'pointer',
                                    margin: 0
                                }}
                            />
                            <label
                                htmlFor="mailing-labels-apply-buffer"
                                style={{
                                    fontSize: '14px',
                                    fontWeight: '500',
                                    color: '#333',
                                    cursor: 'pointer',
                                    userSelect: 'none'
                                }}
                            >
                                Apply a buffer to the selection
                            </label>
                        </div>

                        {/* Distance + unit inputs. Disabled (greyed out) when the
                            checkbox above is off, so the relationship between the
                            toggle and the inputs is visually obvious. */}
                        <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            marginBottom: '8px',
                            opacity: state.mailingLabelsBufferEnabled ? 1 : 0.5
                        }}>
                            <label
                                htmlFor="mailing-labels-buffer-distance"
                                style={{
                                    fontSize: '14px',
                                    color: '#333',
                                    minWidth: '70px'
                                }}
                            >
                                Distance
                            </label>
                            <input
                                id="mailing-labels-buffer-distance"
                                type="number"
                                min={0}
                                step="any"
                                value={state.mailingLabelsBufferDistance}
                                disabled={!state.mailingLabelsBufferEnabled}
                                onChange={(e) => {
                                    const v = e.target.value;
                                    setState(prev => ({
                                        ...prev,
                                        mailingLabelsBufferDistance: v,
                                        // Clear stale error message once the user edits the value
                                        mailingLabelsBufferError: ''
                                    }));
                                }}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        launchMailingLabels();
                                    }
                                }}
                                style={{
                                    flex: '0 0 100px',
                                    padding: '8px 10px',
                                    border: '2px solid #ccc',
                                    borderRadius: '4px',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    boxSizing: 'border-box'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#ccc'; }}
                                aria-describedby={state.mailingLabelsBufferError ? 'mailing-labels-buffer-error' : undefined}
                            />
                            <label
                                htmlFor="mailing-labels-buffer-unit"
                                style={{
                                    position: 'absolute',
                                    width: '1px',
                                    height: '1px',
                                    padding: 0,
                                    margin: '-1px',
                                    overflow: 'hidden',
                                    clip: 'rect(0,0,0,0)',
                                    border: 0
                                }}
                            >
                                Buffer unit
                            </label>
                            <select
                                id="mailing-labels-buffer-unit"
                                value={state.mailingLabelsBufferUnit}
                                disabled={!state.mailingLabelsBufferEnabled}
                                onChange={(e) => {
                                    const v = e.target.value as 'feet' | 'meters' | 'kilometers' | 'miles';
                                    setState(prev => ({
                                        ...prev,
                                        mailingLabelsBufferUnit: v
                                    }));
                                }}
                                style={{
                                    flex: 1,
                                    padding: '8px 10px',
                                    border: '2px solid #ccc',
                                    borderRadius: '4px',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    backgroundColor: 'white',
                                    boxSizing: 'border-box'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#ccc'; }}
                            >
                                <option value="feet">feet</option>
                                <option value="meters">meters</option>
                                <option value="kilometers">kilometers</option>
                                <option value="miles">miles</option>
                            </select>
                        </div>

                        {/* Inline validation error. Only rendered when something
                            is wrong, so the dialog stays compact otherwise. */}
                        {state.mailingLabelsBufferError && (
                            <div
                                id="mailing-labels-buffer-error"
                                role="alert"
                                style={{
                                    color: '#b00020',
                                    fontSize: '13px',
                                    margin: '0 0 16px 0',
                                    lineHeight: '1.4'
                                }}
                            >
                                {state.mailingLabelsBufferError}
                            </div>
                        )}

                        <div style={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            gap: '12px',
                            marginTop: state.mailingLabelsBufferError ? '4px' : '20px',
                            flexWrap: 'wrap'
                        }}>
                            <button
                                onClick={cancelMailingLabelsBufferDialog}
                                style={{
                                    padding: '10px 20px',
                                    border: '2px solid #555',
                                    borderRadius: '4px',
                                    backgroundColor: 'white',
                                    color: '#333',
                                    cursor: 'pointer',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    fontWeight: '500'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#1976d2'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#555'; }}
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => launchMailingLabels()}
                                style={{
                                    padding: '10px 20px',
                                    border: '2px solid #0066cc',
                                    borderRadius: '4px',
                                    backgroundColor: '#0066cc',
                                    color: 'white',
                                    cursor: 'pointer',
                                    fontSize: '14px',
                                    fontFamily: themeFont,
                                    fontWeight: '500'
                                }}
                                onFocus={(e) => { e.currentTarget.style.borderColor = '#004499'; e.currentTarget.style.backgroundColor = '#004499'; e.currentTarget.style.outline = 'none'; }}
                                onBlur={(e) => { e.currentTarget.style.borderColor = '#0066cc'; e.currentTarget.style.backgroundColor = '#0066cc'; }}
                            >
                                Apply
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};

export default Widget;